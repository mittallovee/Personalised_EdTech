# System Architecture (Proposed)

## Approach
Start with a modular monolith for the API plus separate background worker processes. Keep module boundaries clear so services can be split later based on measured scaling needs.

## Logical flow
Faculty UI → FastAPI → validation and job creation → object storage + PostgreSQL → queue → worker → extraction/OCR → segmentation → structured parsing → optional AI suggestions/duplicate candidates → staging/review UI → question bank/versioning → test builder.

## Modules
- organizations: tenant records and membership
- auth/access: identity, sessions/tokens, roles, permissions
- files: upload validation, object-storage adapter, checksums
- ingestion: jobs, retry, status, idempotency
- extraction: PDF/DOCX extraction and OCR
- segmentation: question boundary candidates
- parsing: options, answer, solution, tables/equations/assets
- taxonomy: classes, subjects, chapters, topics, concepts
- question_bank: master questions and versions
- relationships: variants, translations, duplicates
- review: reviewer queues, decisions, QC status
- ai_orchestrator: model catalogue, routing, provenance, usage controls
- test_builder: filters, test composition, pinned question versions
- audit/observability: audit events, logs, metrics

## Suggested repository layout
```text
question-platform/
  apps/
    faculty-web/
  services/
    api/
      app/
        modules/
        workers/
        core/
        main.py
      tests/
  infrastructure/
    docker/
  migrations/
  docs/
  docker-compose.yml
  README.md
```

## API design principles
- Version APIs (e.g. `/api/v1/...`).
- Use explicit schemas and validation.
- Long-running work returns a job ID; clients poll or subscribe for status.
- Use idempotency keys/checksums to prevent accidental duplicate jobs.
- Do not expose unauthenticated development endpoints outside local development.
- Keep file storage behind an adapter and use signed URLs where appropriate.

## Operational principles
- Keep original file immutable.
- Store processing outputs and errors by stage.
- Retry transient failures; do not endlessly retry malformed inputs.
- Keep worker tasks idempotent.
- Add tracing/correlation IDs across API, queue, and worker.
- Do not adopt full microservices until operational need is demonstrated.
