# Question Lifecycle, Review and QC

## Lifecycle
Proposed lifecycle: `DRAFT → CONTENT_QC → APPROVED → PUBLISHED`. Define rejection/changes-requested states explicitly during implementation.

## Review roles
- Creator: create/import candidate questions and edit drafts.
- Reviewer/validator: check extracted content, answers, diagrams, options, and metadata.
- Approver/admin: approve and publish according to organization policy.
- Roles are scoped to organization membership and may be refined into permissions.

## Publishing
- Publishing is a controlled action with authorization and audit event.
- Published version content must be immutable for historical reproducibility.
- Corrections create a new version; do not rewrite the version referenced by an existing test.
- Keep actor, timestamp, source, and change reason.

## QC checks
- Question text and options complete.
- Answer/key and solution consistency reviewed as appropriate.
- Equations, units, figures, tables, and passage links preserved.
- Taxonomy and question type plausible.
- Source and PYQ metadata traceable.
- Duplicate/variant suggestion reviewed.
- Translation linked to the correct master and checked by a qualified reviewer.
- AI-verified status must be governed by explicit checks; AI-generated alone does not mean verified.

## Duplicate handling
- Exact checksum/normalized-text matching as a first pass.
- Fuzzy/semantic candidate generation as a second pass.
- Human confirmation before merging or declaring canonical relationships.
- Keep original source provenance even when linked to an existing master.
