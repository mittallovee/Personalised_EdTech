# Project Master Context

## Project
Build a multi-tenant, multi-SaaS Question Bank and Test Creation Platform for coaching organizations, initially focused on IIT-JEE/NEET and Physics teaching, but designed to support other subjects, curricula, and exams later.

## Product direction
- Faculty/admin-facing question management and test authoring is the first implementation focus.
- Student-facing test delivery, attempt tracking, analytics, and personalized suggestions are later phases.
- Questions belong to the organization/tenant, not to an individual creator.
- A question has a stable master identity, immutable version history, and explicit relationships to variants, translations, and duplicates.
- A human-readable permanent question code should be 7–8 alphanumeric characters, generated securely and protected by a unique constraint. Keep this distinct from internal UUIDs and version IDs.
- The system must support PDF/Word ingestion and manual question entry through the same downstream question-processing pipeline.
- AI may suggest metadata, translations, diagrams, and duplicate/variation matches; human QC remains authoritative where required.
- Faculty should be able to choose from a fixed supported list of AI models, with sensible defaults and per-operation selection where supported. The system should record model/prompt provenance.
- Published question versions must remain historically stable for tests already assembled against them. Changes should create a new version under controlled permissions rather than silently altering old content.

## Proposed technology stack
- Faculty frontend: Next.js, React, TypeScript
- Backend: Python, FastAPI
- ORM/migrations: SQLAlchemy 2.x, Alembic
- Database: PostgreSQL with JSONB and tenant isolation/RLS
- Object storage: S3-compatible storage for originals and extracted assets
- Background processing: Celery + Redis (or revisit if deployment requirements justify another queue)
- PDF extraction: PyMuPDF
- DOCX extraction: python-docx
- OCR: Tesseract as an initial self-hostable option; benchmark on real files
- AI gateway: LiteLLM plus a project-owned AI orchestration layer, subject to validation
- Local development: Docker Compose
- Testing: pytest and integration tests

These are proposed implementation choices from the conversation, not proof that the stack has been installed or deployed.

## Product metadata previously discussed
- Question type: Single Option Correct, Multiple Option Correct, Numerical, Integer, Single Digit, Match the Column, Assertion–Reason, Multiple Statement, Passage-based variants
- Class, subject, chapter, topic
- Concept 1 and optional Concept 2; taxonomy should be extensible
- Difficulty level 1–10
- Bloom's taxonomy level
- Exam, PYQ year/date/code/slot/batch and source name
- Optional video-solution metadata
- Language/translation metadata (Hindi, Bengali, Gujarati were examples)
- AI-verified indicator, only when verification criteria are actually met

## Roles and workflow
- Creator
- Reviewer/validator
- Approver/admin
- States discussed: Draft → Content QC/Review → Approved → Published
- Published content is locked against casual editing; admin-authorized change should create a new version and preserve audit history.

## Current known status from the conversation
- Product requirements and broad architecture have been discussed.
- A starter ZIP was previously said to have been prepared, but the current handover context does not contain its actual source files, and its real availability cannot be verified here.
- The prior assistant explicitly said syntax checks passed for a scaffold but PostgreSQL migration and tenant-isolation integration tests had not been verified. Treat even that statement as historical conversation context, not a fresh test result.
- No verified evidence is available here that PostgreSQL migrations, RLS policies, authentication, upload API, OCR, question segmentation, or AI tagging are working end-to-end.
- Next step: locate/open the actual repository if it exists, audit it, run tests and migrations in a safe local environment, then proceed to upload and extraction.

## Continuity instructions
Read this package before proposing changes. Do not re-open settled product decisions without explaining the reason. Clearly label facts as confirmed, proposed, or unverified. Avoid claiming tests pass unless actually executed and report the command and output.
