# Database Schema — Conceptual Draft

This is a design draft, not a verified migration or final SQL specification.

## Core entities
- `organizations`: tenant identity, slug/name, lifecycle timestamps.
- `organization_memberships`: user ↔ organization relationship, role and status.
- `users` or external identity mapping: identity provider subject; avoid storing unnecessary identity data.
- `ingestion_jobs`: organization, requester, status, idempotency key, source count, progress, error summary, timestamps.
- `source_files`: organization, job, storage key, original filename, MIME type, byte size, checksum, upload metadata.
- `extracted_questions`: organization, job, source file, page range, raw text, structured candidate JSON, confidence, processing status, review status.
- `questions`: internal UUID, organization, stable 7–8-character alphanumeric question code, lifecycle status, created/updated metadata.
- `question_versions`: immutable version rows with version number, structured content, language, answer/solution, metadata snapshot, created-by, created-at, publication fields.
- `question_relationships`: typed links such as variant-of, translation-of, duplicate-of, related-to.
- `taxonomy_nodes`: extensible hierarchy for class/subject/chapter/topic/concept; alternatively use normalized tables if query needs justify it.
- `question_taxonomy_assignments`: version-scoped taxonomy assignments and provenance/confidence.
- `ai_runs`: provider/model, operation, prompt version, input/output references, status, token/cost metadata if available, timestamps.
- `audit_logs`: tenant, actor, action, entity type/ID, before/after references or safe diff, correlation ID, timestamp.
- Future: tests, test versions, test-question links, student attempts and analytics.

## Important integrity requirements
- Separate internal UUID, human-readable question code, and question version ID.
- Unique constraint on `(organization_id, question_code)` unless product explicitly requires global uniqueness.
- Generate codes using a cryptographically secure random source; handle collisions by retrying after unique-constraint conflict.
- Use immutable version rows; published content should not be silently overwritten.
- A test must reference a specific question version, not just the master question.
- Use tenant-aware foreign keys where practical to prevent cross-tenant links.
- Ensure source file, ingestion job, and extracted question organization IDs are consistent.
- Index common filters: organization, status, question type, language, taxonomy assignments, exam/year, and creation time.
- JSONB is suitable for flexible structured question content, but normalize fields needed for frequent filtering and constraints.
- Define deletion/retention rules before production; consider soft-delete and legal retention needs.

## RLS and tenant safety
- Enable RLS on tenant-owned tables.
- Use a trusted server-side transaction/session to set tenant context.
- Policies must fail closed when tenant context is absent.
- Never trust a tenant ID supplied by an untrusted client without verifying membership.
- Add integration tests proving tenant A cannot read/write tenant B rows.
- Test worker jobs and background connections too; RLS can be bypassed accidentally by privileged roles.
- Keep migration/owner credentials separate from application runtime credentials.

## Versioning
- Draft edits can update a draft version under permission rules.
- Approved/published changes should create a new version, with explicit supersedes relationship.
- Preserve the exact version used in every published test.
