# Decisions and Open Questions

## Decisions previously stated as agreed
- Product is a multi-SaaS/multi-tenant question bank and test creation platform.
- Organization owns questions; not individual creators.
- Manual entry and file ingestion converge on one processing pipeline.
- Stable 7–8 character alphanumeric question code, distinct from database UUID and version ID.
- Master question and immutable versions are separate concepts.
- Published content should not be silently mutated; preserve old versions for tests.
- Variants, translations, and duplicates are explicit relationships.
- Faculty can choose from a fixed supported AI model list; defaults also exist.
- AI model/prompt provenance should be recorded.
- Start with modular monolith + background workers rather than premature microservices.
- Initial ingestion prototype focuses on PDF/DOCX, staging, and review.

## Proposed but not yet verified in code
- Next.js/React/TypeScript frontend.
- FastAPI + SQLAlchemy 2.x + Alembic backend.
- PostgreSQL/JSONB and RLS.
- S3-compatible object storage.
- Celery + Redis.
- PyMuPDF, python-docx, Tesseract.
- LiteLLM plus project-owned AI orchestration.
- Docker Compose local development.

## Open questions to resolve from the actual repository/product decisions
- What authentication provider and session strategy?
- Exact roles/permissions and whether custom roles are needed?
- Tenant-wide or global uniqueness for public question code? Current preference: tenant-scoped unique code.
- Exact question content JSON schema for passages, match-the-column, assertion-reason, multiple statements, equations, and diagrams.
- Taxonomy schema: normalized tables vs flexible hierarchy.
- Object storage provider and file retention policy.
- Supported file limits and upload formats.
- OCR language packs and benchmark corpus.
- Exact model catalogue, providers, budget controls, and per-operation permissions.
- Review rejection/changes-requested states and who can publish.
- Duplicate thresholds and human confirmation policy.
- Required export formats and initial test builder scope.
- Student data/privacy requirements before analytics.
- Deployment target, monitoring, backup, and recovery requirements.

## Guardrails
Do not silently change a prior decision. If a requirement conflicts with security, feasibility, or maintainability, explain the trade-off and ask before changing product direction.
