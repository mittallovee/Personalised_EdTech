# Question Bank Multi-SaaS — Project Handover

This package transfers the project context into another ChatGPT account. Upload this ZIP there, then ask the assistant to read `PROJECT_MASTER_CONTEXT.md` first and continue from the verified current state.

## Important status note
This package documents the project decisions and plans recoverable from the conversation context. It does **not** contain or verify the previously mentioned `question-platform-foundation-v2.zip` source code. No claim is made that migrations, database policies, or ingestion endpoints have been run successfully.

## Suggested use
1. Upload this ZIP to the other ChatGPT account.
2. Ask it to read `PROJECT_MASTER_CONTEXT.md`, `DECISIONS_AND_OPEN_QUESTIONS.md`, and `IMPLEMENTATION_ROADMAP.md`.
3. If the existing code repository is on your Mac, open that real repository in Codex as well. Documentation is not a replacement for source code.
4. Use `CODEX_HANDOVER_PROMPT.md` as the initial audit prompt.

## Document index
- `PROJECT_MASTER_CONTEXT.md` — goals, context, and known progress
- `PRD.md` — product requirements
- `SYSTEM_ARCHITECTURE.md` — proposed system architecture
- `DATABASE_SCHEMA.md` — initial conceptual data model
- `QUESTION_INGESTION_PIPELINE.md` — file-to-question workflow
- `AI_MODEL_ORCHESTRATION.md` — selectable AI models and AI workflows
- `QUESTION_LIFECYCLE_AND_QC.md` — review, publishing, versioning, and QC
- `TEST_BUILDER_AND_ANALYTICS.md` — tests and future learning analytics
- `SECURITY_AND_MULTI_TENANCY.md` — security and tenant boundaries
- `IMPLEMENTATION_ROADMAP.md` — recommended order of work
- `DECISIONS_AND_OPEN_QUESTIONS.md` — confirmed decisions vs unresolved details
- `CODEX_HANDOVER_PROMPT.md` — prompt for Codex repository audit
