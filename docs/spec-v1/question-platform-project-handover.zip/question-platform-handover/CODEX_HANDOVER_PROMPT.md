# Codex Handover Prompt

You are working on a multi-tenant SaaS Question Bank and Test Creation Platform. Read the entire handover documentation, especially `PROJECT_MASTER_CONTEXT.md`, `DECISIONS_AND_OPEN_QUESTIONS.md`, and `IMPLEMENTATION_ROADMAP.md`, before making changes.

## First task: audit only
1. Inspect the actual repository and report the current directory and top-level files.
2. Read the existing README, dependency manifests, application modules, SQLAlchemy models, Alembic migrations, Docker Compose, and tests.
3. Compare implementation against the handover documents.
4. Run only safe, non-destructive checks first (syntax/lint/unit tests if available).
5. If Docker/PostgreSQL are available, inspect configuration first. Do not run migrations against any production or unknown database.
6. Report commands actually executed and their exact pass/fail outcomes.
7. Identify security gaps, especially tenant isolation, unauthenticated dev endpoints, secret handling, and published-version immutability.
8. Propose a small prioritized fix plan; do not perform large rewrites yet.

## Product constraints
- Organization owns questions.
- Manual entry and file ingestion share one downstream pipeline.
- Keep internal UUID, permanent 7–8-character alphanumeric question code, and question version ID separate.
- Preserve immutable published versions and pin tests to exact versions.
- Track variants, translations, and duplicate relationships explicitly.
- Users select supported AI models from a controlled catalogue, with defaults; record model and prompt provenance.
- Start with modular monolith + background workers; avoid premature microservices.
- Human QC remains authoritative for publication-critical data.
- Strong tenant isolation is mandatory.

## Safety rules
- Do not access production systems or use production credentials.
- Do not delete data or run destructive commands.
- Do not reset databases, force-push, or overwrite files without explicit approval.
- Do not expose unauthenticated development endpoints publicly.
- Do not claim tests or migrations passed unless they were executed and output inspected.
- Before a migration or command that could alter data, explain its target and impact and ask for approval.
- Make small, reviewable changes and update documentation/tests with implementation.

After the audit, provide:
A. Current implementation status
B. Actual test results
C. Critical defects and security risks
D. Recommended next small task
E. Any user decision required
