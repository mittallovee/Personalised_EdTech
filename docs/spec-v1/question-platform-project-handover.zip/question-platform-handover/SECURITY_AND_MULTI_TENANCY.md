# Security and Multi-Tenancy

## Core requirements
- Every tenant-owned record must have an organization/tenant relationship.
- Enforce tenant membership and role permissions on every API operation.
- Use PostgreSQL RLS as defense in depth, not as a substitute for application authorization.
- Fail closed when tenant context is missing.
- Ensure background workers establish the correct tenant context for every job.
- Private object storage; validate files and use short-lived signed access where needed.
- Store secrets outside source control; use separate dev/test/prod credentials.
- Do not expose development endpoints without authentication outside local-only development.
- Audit sensitive operations: publishing, permission changes, question edits, exports, and data deletion.
- Rate-limit uploads and AI endpoints; set file size/page limits.
- Use safe logging; avoid logging credentials, full sensitive content, or signed URLs.
- Define backups, restoration tests, retention, and deletion policy before production.

## Verification tests
- Tenant A cannot read, update, or delete tenant B's records.
- Tenant A cannot link a question to tenant B's source or version.
- Background jobs cannot cross tenant boundaries.
- Missing tenant context denies access.
- Application DB role cannot bypass RLS; migration owner role is separate.
- Published versions cannot be updated/deleted through normal application paths.
- Authorization tests cover creator/reviewer/approver/admin actions.
