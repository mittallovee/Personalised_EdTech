# Question Ingestion Pipeline

## Inputs
First milestone: PDF and DOCX. Later candidates: XLSX, images, bulk CSV, manual entry. Manual entry and file-based ingestion must converge on the same candidate-question pipeline.

## Stages
1. Upload request and authentication/authorization.
2. Validate extension, MIME, size, file signature, and file integrity; scan where feasible.
3. Compute checksum; store original in private object storage.
4. Create `ingestion_job` and source-file record transactionally where possible.
5. Enqueue background job.
6. Extract text directly from text PDFs; OCR scanned pages only when needed.
7. Extract DOCX paragraphs, tables, and embedded assets where feasible.
8. Preserve source page/paragraph references and extraction warnings.
9. Segment candidate question boundaries using deterministic heuristics first, AI fallback only when appropriate.
10. Parse question stem, options, answer/key, solution, diagrams/tables/equations into structured candidate content.
11. Calculate extraction/segmentation confidence; uncertain items go to manual review.
12. Store candidates in staging; do not auto-publish.
13. Run configurable metadata suggestions and duplicate candidate detection.
14. Human reviewer corrects and confirms.
15. Link to existing master/variant/translation or create a new master and version.
16. Record audit trail and final job summary.

## Job states
`QUEUED → PROCESSING → COMPLETED`
Also support `PARTIALLY_COMPLETED`, `FAILED`, and `CANCELLED` if cancellation semantics are implemented.

## Reliability
- Idempotency key plus checksum handling.
- Per-stage status, retry count, timestamps, and structured errors.
- Retry transient infrastructure errors; route malformed/unsupported content to actionable failure.
- Reprocessing should not create duplicate master questions.
- Store source references and raw extraction output for troubleshooting.
- Never silently drop a candidate because segmentation confidence is low.

## Prototype acceptance criteria
- PDF and DOCX upload works.
- Status and failures are observable.
- Extracted candidate questions retain source file and page location.
- Candidates can be reviewed in staging.
- Failed jobs can be retried without re-uploading.
- Tenant boundaries are tested.
- Re-upload/reprocessing does not silently create duplicate master questions.
- A representative evaluation corpus is used to measure quality rather than claiming accuracy without evidence.
