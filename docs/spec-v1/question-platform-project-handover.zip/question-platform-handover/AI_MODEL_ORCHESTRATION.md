# AI Model Orchestration

## Product requirement
Users can select a model from a fixed, supported model catalogue. Provide sensible defaults for quick use, while allowing per-operation model selection when supported by the chosen provider and task.

## Architecture
- `model_catalogue`: model ID, provider, display name, capabilities, status, context limits where known, cost metadata where available, and last-verified date.
- `ai_orchestrator`: central interface for classification, tagging, translation, duplicate candidates, structured parsing assistance, and other approved operations.
- Provider adapters behind a stable interface; do not scatter provider-specific API calls across business modules.
- LiteLLM was proposed as a gateway option; validate provider support, operational needs, and licensing before committing.
- Admin-controlled defaults at platform/organization level, plus user choice where permitted.
- Feature flags and controlled model catalogue updates.
- Record provider/model, operation, prompt-template version, schema version, timestamps, status, and output provenance.

## Safety and quality
- Validate model output against strict JSON/schema.
- Treat model output as a suggestion, not truth.
- Human QC required for publication-critical fields as defined by policy.
- Do not let model output directly execute SQL or alter permissions.
- Redact secrets and minimize personal/student data in prompts.
- Add rate limits, retries, timeouts, budget controls, and per-tenant usage accounting.
- Benchmark models against a representative question set before changing defaults.
- Maintain regression tests when prompts/models change.

## Catalogue maintenance
- Model availability changes over time. Refresh provider catalogue and verify current API identifiers before implementation/deployment.
- Do not promise every provider/model is supported unless tested.
