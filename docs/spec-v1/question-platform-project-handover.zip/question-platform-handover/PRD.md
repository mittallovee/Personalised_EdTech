# Product Requirements Document (Draft)

## 1. Vision
Provide coaching organizations with a reliable, searchable, versioned question bank and a workflow for creating high-quality tests from curated questions.

## 2. Users
- Organization owner/admin
- Faculty/question creator
- Reviewer/validator
- Approver/publisher
- Future: students and academic analysts

## 3. Goals
- Reduce manual work in ingesting and tagging questions.
- Maintain high-quality structured questions with review history.
- Prevent duplicate/near-duplicate questions in a test or configured batch.
- Support multiple organizations with strong tenant isolation.
- Make question versions reproducible for historical tests.
- Allow configurable AI assistance without hard-coding a single provider.

## 4. Core functional requirements
1. Organizations/tenants and membership.
2. Authentication and role-based authorization.
3. Upload PDF/DOCX initially; later consider XLSX and additional formats.
4. Validate uploads and store originals securely.
5. Create asynchronous ingestion jobs with progress, errors, retry, and idempotency.
6. Extract text and OCR scanned pages as needed.
7. Segment source documents into candidate questions and options, preserving page/source references.
8. Stage extracted candidates for human review before publishing.
9. Support manual entry through the same processing and review pipeline.
10. Maintain master questions, immutable versions, and stable public question codes.
11. Store structured content: stem, options, answer/key, solution, figures/assets, and format-specific fields.
12. Suggest taxonomy, difficulty, question type, language, and exam metadata with AI.
13. Record AI model, prompt/version, timestamp, and output provenance.
14. Detect exact and semantic duplicates/variants, with reviewer confirmation.
15. Support translations and explicit relationships between language versions.
16. Review, approve, publish, and preserve audit logs.
17. Build tests with filters and available-question counts.
18. Prevent configured duplicate question use within the same test/batch.
19. Future: student test delivery, time tracking, response analytics, and personalized recommendations.

## 5. Non-functional requirements
- Tenant isolation enforced server-side and, where appropriate, by PostgreSQL RLS.
- Secure file validation and storage; no public access to uploaded source files by default.
- Auditability and reproducibility.
- Idempotent retries and recoverable background jobs.
- Good observability: structured logs, job errors, processing timings.
- Automated unit, integration, and migration tests.
- Accessibility and responsive faculty UI.
- Scalable module boundaries without premature microservices.
- Secrets in environment/secret management, never committed.
- Backups, retention, and recovery policy before production.

## 6. Success measures to define
- Question extraction accuracy by source type/layout
- Percentage of candidate questions accepted without structural correction
- Metadata suggestion acceptance rate
- Duplicate detection precision/recall
- Processing time per page/question
- Ingestion job success and retry rates
- Reviewer time per question
- Tenant-isolation test coverage
- Test assembly time and duplicate-prevention effectiveness

Set numerical targets only after building a representative evaluation corpus.

## 7. Out of scope for first ingestion prototype
Billing, full student app, advanced analytics, and production deployment unless explicitly prioritized later.
