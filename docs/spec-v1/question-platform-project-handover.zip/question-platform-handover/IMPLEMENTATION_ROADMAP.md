# Implementation Roadmap

## Phase 0 — Recover and audit actual repository
- Find the actual project directory/ZIP on the developer machine.
- Open it in Codex using the correct local folder.
- Inspect README, dependency manifests, models, migrations, Docker config, and tests.
- Report actual files and executed test outcomes.
- Do not overwrite the repository based on this handover alone.

## Phase 1 — Local executable foundation
- Docker Compose for PostgreSQL and API.
- SQLAlchemy models and Alembic migration.
- Health endpoint and database readiness check.
- CI/lint/type checks and pytest.
- Migration up/down or documented forward-only policy.
- Tenant isolation integration tests.

## Phase 2 — Identity and authorization
- Authentication integration.
- Organizations, memberships, roles, permissions.
- Tenant context middleware and RLS policies.
- Audit log framework.

## Phase 3 — File and job management
- Private object storage adapter.
- Upload API, file validation, checksums.
- Ingestion job state machine, progress, retries, idempotency.
- Authenticated faculty UI for upload/status.

## Phase 4 — Extraction and staging
- PDF text extraction, OCR fallback, DOCX extraction.
- Source location preservation.
- Segmentation and parsing.
- Staging/review UI and representative fixture corpus.

## Phase 5 — Question bank and QC
- Master question + immutable versions.
- Stable 7–8 character question code.
- Variants/translations/duplicate relations.
- Review and publish flow with audit history.

## Phase 6 — AI assistance
- Model catalogue and orchestrator.
- Metadata suggestions, translation, duplicate candidates.
- Prompt/model provenance and structured output validation.
- Human approval and benchmark suite.

## Phase 7 — Test builder
- Search/filter, counts, test assembly, pinned versions.
- Duplicate avoidance within test/batch.
- Test export/delivery needs.

## Phase 8 — Student app and analytics
- Test-taking, time tracking, attempts, analytics, recommendations.

## Definition of done per phase
- Requirements and API contracts updated.
- Migrations run against disposable test DB.
- Unit/integration tests actually executed and results recorded.
- Security/tenant isolation tests pass.
- No unreviewed destructive commands or production credential usage.
- Documentation reflects the real implementation, not intended behavior.
