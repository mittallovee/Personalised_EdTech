# Test Builder and Future Analytics

## Test builder requirements
- Filter questions by subject, chapter, topic, concepts, difficulty, question type, exam/year, language, source, video solution availability, and status as permissions allow.
- Show counts for the current filter and selected criteria.
- Assemble tests from specific immutable question versions.
- Prevent duplicate/near-duplicate questions in the same test or configured batch.
- Preserve test version/history and a snapshot of selection criteria.
- Enforce that only eligible approved/published questions can be selected according to policy.

## Future student app
- Secure test access and submission.
- Attempt state, timing, and answer capture.
- Preserve question-version references used during attempt.
- Analytics for time per question, accuracy, wrong options, concept-level performance, and recurring misconceptions.
- Personalized recommendations should be explainable, privacy-aware, and validated for educational usefulness.

## Data design caution
Do not build analytics tables before defining event semantics, retention, and consent/privacy requirements. Keep raw events and derived aggregates distinguishable.
