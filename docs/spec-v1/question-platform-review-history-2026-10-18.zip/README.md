# Question Bank and Test Creation Platform

**Current stage: requirements and design review. Application implementation has not started.**

This project will provide coaching organizations with a multi-tenant question bank, human quality review, immutable published question versions, and test creation. Faculty/admin workflows are the initial focus; student delivery and analytics follow later.

The user confirmed on 17 October 2026 that no earlier source code exists and requested complete requirements and documentation before implementation.

Start with [the documentation index](docs/README.md). For a guided product discussion in Hindi, use [requirements review](docs/REQUIREMENTS_REVIEW_HI.md).

The original `question-platform-project-handover.zip` remains the historical source. Documents under `docs/` expand that handover and distinguish agreed requirements, proposals, and unresolved decisions. A written proposal is not an approved product decision or an implemented capability.

There are no application services, migrations, installed project dependencies, or application test results in this repository yet.

Confirmed review scope: one initial institute with multi-tenant architecture; admin-defined approval/publication; question-bank entry/upload/review/database saving first, test creation/export later. All nine formats, PDF/Word/images, 50 MB/document and 10 MB/image limits, and detailed AI-managed taxonomy/tagging are included. See docs for unresolved policies and schemas.
