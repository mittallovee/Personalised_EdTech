# Implementation Roadmap

## Updated entry point — documentation before implementation

The user confirmed on 17 October 2026 that no code exists. The former source-recovery assumption is superseded by this sequence:

### Phase D0 — Requirements review (current)

Confirmed rollout: one initial coaching institute with multi-organization support from the foundation. Tenant-isolation checks must use multiple test organizations regardless of initial customer count. Review questions are asked one at a time.

- Review the existing product requirements with the user using [the Hindi guide](REQUIREMENTS_REVIEW_HI.md).
- Separate agreed requirements from proposals and open questions.
- Define workflows, permissions, content examples, acceptance criteria, and phased scope.
- Record answers in [the decision register](PRODUCT_DECISION_REGISTER.md).

### Phase D1 — Design and readiness review

- Reconcile question-content schema, data integrity, tenant context, API contracts, and job behavior.
- Confirm the stack, authentication strategy, code-uniqueness scope, and deployment assumptions before building the corresponding components.
- Agree the first implementation slice and acceptance checks.
- Review [documentation readiness](DOCUMENTATION_READINESS.md) with the user. Later-phase questions can remain open only when explicitly deferred with their dependency recorded.

### Phase D2 — First executable slice (after documentation review)

Proposed scope: local PostgreSQL and API, organization-scoped question master/version records, health/readiness, a disposable migration workflow, and meaningful tenant-isolation/immutability tests. Authentication approach must be resolved before exposing business operations. Exact scope is awaiting review; this entry does not authorize coding now.

The phases below remain the broad delivery sequence. Foundation, identity, file management, extraction/review, question bank, AI, tests, and student analytics are dependencies rather than promises of delivery dates. No schedule or estimate is committed.

### Milestone exit evidence

| Milestone | Evidence required |
| --- | --- |
| Documentation review | Decisions affecting the next slice answered, linked criteria reviewed, deferred items listed |
| Foundation and identity | Disposable migration result, role and tenant tests, runtime credentials restricted |
| Ingestion prototype | PDF/DOCX examples, source references, retry/idempotency evidence, staging review |
| Question publishing | Authorized transition tests, version lock, exact-version test selection |
| AI assistance | Verified model identifiers, output validation, provenance, quality/cost evaluation |
| Test builder | Filter/count consistency, pinned versions, agreed duplicate policy |
| Student workflows | Separate privacy and attempt/event requirements approved |

## Phase 0 — Requirements and design review

Use Phases D0/D1 above as the current Phase 0. No source recovery is required: the user confirmed there is no prior implementation. Application work begins after documentation affecting the next slice has been reviewed.

## Phase 1 — Local executable foundation
- Docker Compose for PostgreSQL and API.
- SQLAlchemy models and Alembic migration.
- Health endpoint and database readiness check.
- CI/lint/type checks and pytest.
- Migration up/down or documented forward-only policy.
- Tenant isolation integration tests.

## Phase 2 — Identity and authorization
- Authentication integration.
- Organizations, memberships, roles, permissions.
- Tenant context middleware and RLS policies.
- Audit log framework.

## Phase 3 — File and job management
- Private object storage adapter.
- Upload API, file validation, checksums.
- Ingestion job state machine, progress, retries, idempotency.
- Authenticated faculty UI for upload/status.

## Phase 4 — Extraction and staging
- PDF text extraction, OCR fallback, DOCX extraction.
- Source location preservation.
- AI discovery of unfamiliar layouts, versioned pattern saving/selection and automatic compatible-layout reuse; drift/coverage validation, AI fallback and quality/token/time evidence.
- Segmentation and parsing, including handwritten questions and solutions.
- Staging/review UI and representative fixture corpus.

## Phase 5 — Question bank and QC
- Master question + immutable versions.
- Stable 8 character question code.
- Variants/translations/duplicate relations.
- Review and publish flow with audit history.

## Phase 6 — AI assistance
- Model catalogue and orchestrator.
- Metadata suggestions, translation, duplicate candidates.
- Prompt/model provenance and structured output validation.
- Human approval and benchmark suite.

## Phase 7 — Test builder
- Search/filter, counts, test assembly, pinned versions.
- Duplicate avoidance within test/batch.
- Test export/delivery needs.

## Phase 8 — Student app and analytics
- Test-taking, time tracking, attempts, analytics, recommendations.

## Definition of done per phase
- Requirements and API contracts updated.
- Migrations run against disposable test DB.
- Unit/integration tests actually executed and results recorded.
- Security/tenant isolation tests pass.
- No unreviewed destructive commands or production credential usage.
- Documentation reflects the real implementation, not intended behavior.

## Confirmed release-one review updates

One initial institute, multi-organization architecture. Admin-defined approval/publication grants. First release: question-bank entry/upload/review and database saving, all nine formats, PDF/Word/images with accepted size limits, and AI-driven detailed taxonomy/tagging. Test assembly/test-paper export and student delivery are later. Catalogue implementation, content-schema details, provider/identity choices and other open decisions must be reviewed before the affected implementation. AI tagging must be integrated with the first usable release rather than silently postponed beyond it; the internal build sequence may still develop foundations first.

## AI variants in first release — confirmed

User-confirmed: AI generation of practice variants is included in the first release. Generated variants receive separate masters/new global eight-character codes and variant-of/source-version provenance; they follow normal question QC and authorized approval/publication. Original content remains unchanged. Faculty request is the confirmed trigger; no automatic per-question generation. Source eligibility, generation count/controls and operation permissions remain open. See [AI variant generation](AI_VARIANT_GENERATION.md).

## First-release AI diagram creation/editing — confirmed

User-confirmed: first release includes AI generation of question diagrams and modification of existing diagrams when needed. Keep reviewable asset output, provenance, same-tenant attachment, preserved originals and version-safe references. Human QC checks diagram/question/answer consistency; no automatic verification or publication. Invocation controls, supported representation/providers/models and evaluation remain open. See [AI diagram assistance](AI_DIAGRAM_ASSISTANCE.md).

## First-release AI prerequisite relationships — confirmed

AI creates concept-to-concept prerequisite links in release one: which concept should be understood before another. Keep directed stable concept IDs, same-coaching/same-subject endpoints, relationship provenance and graph change history, separate from question tags and taxonomy hierarchy. Cross-subject prerequisite links are not allowed, including AI creation and admin corrections. Cross-class links within the same subject/coaching are allowed, including Class 11 prerequisite → Class 12 dependent; different classes alone must not block such links. Personalized student suggestions/mastery analytics remain later. AI links are immediately usable with AI-added/admin-review-pending status and admin notification; admin can later approve, correct or revoke them. Detailed cycle disposition and educational validation remain design work. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Faculty knowledge graph navigation in release one — confirmed

Faculty can view their coaching's knowledge tree as a graph and click a concept to open linked questions. Query by stable concept ID against primary/secondary question assignments, preserving existing bank access and tenant scope for graph nodes, edges, counts and question navigation. Viewing grants no graph-write, question-edit or QC/approve/publish authority. Show provisional AI/admin-review-pending status and current active links accurately. This is faculty bank navigation; student recommendations/mastery analytics remain later. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Platform onboarding requirement for foundation

Include platform-admin creation of a coaching and its first Owner in the identity/tenant foundation; no public coaching self-signup. Preserve separate platform/tenant authority, organization/owner audit and retry-safe provisioning. Platform admin has full cross-coaching application authority through explicit authorized paths with normal validation/versioning/audit, including QC/approve/publish, original-source/storage, user/Owner/role, AI credentials/configuration/jobs and analytics; first platform-admin and first-owner activation mechanics remain design work. No account has been created.

## Per-coaching branding in the initial app

Include coaching display name/logo settings and tenant-safe rendering in the initial app shell. Reuse valid organization-owned asset references; ensure missing-logo fallback and correct coaching context in platform views. Branding writes are platform-admin-only, including tenant-setting APIs and logo replacement; all coachings use one shared app entry link; separate coaching domains/subdomains are not needed, while theme/export branding remain separate scope. No frontend has been implemented.

## Coaching subscription/payment collection — later phase

Coaching subscription and payment collection are explicitly deferred beyond the first release. Initial coaching onboarding and question-bank workflows do not depend on creating a subscription, plan or payment record. Future pricing, commercial plans, invoicing, payment gateway, renewal/expiry and subscription enforcement need their own approved specification before implementation; this is not a commitment to permanent free access.

First-release AI usage/cost reporting, coaching-owned provider credentials and monthly faculty spending controls remain required. Provider charges associated with a coaching's own API keys and application AI-budget accounting are separate from the platform collecting subscription payments. Keep 80% warning/100% new-AI-work stop and monthly reset/history under the existing policy. No payment system, plan or billing integration has been created.

## Initial faculty workload expectation

User expects very few faculty at launch. Record qualitative low initial user volume without inventing a numeric cap or reducing agreed feature scope. Retain multi-organization readiness and background processing; establish corpus/upload/concurrency measurements before selecting operational capacity targets.

## Corpus-scale validation requirement

Use the expected lakh-scale bank, not a tiny user count, to plan database/search/duplicate access and later performance evaluation. Keep implementation milestones modular and measurements separate from provider/OCR throughput. Workload, environment and numerical targets must be documented before claiming capacity. See [capacity and performance](CAPACITY_AND_PERFORMANCE.md).

## Later learning milestones — confirmed capabilities, sequence to refine

After the current adaptive-ingestion/question-bank release, add faculty courses/live/recorded delivery and student-need/level-aware AI teaching/generated concept videos as separately specified milestones. Relative ordering with tests/student analytics is a proposal, not a fixed schedule. Reuse tenant/concept identities, jobs, media access and AI provenance. See [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).

Samples will be provided later. Continue requirements/schema/contracts now; sample-based engine/quality/token/time validation remains a later evidence dependency, not a blocker to current documentation.

## Platform-managed complete dataset sharing

Include separate coaching pattern libraries and platform-only complete dataset sharing in the current bank/pattern design. Use one-time independent initial copies without ongoing synchronization; define manifests/dependencies, destination-owned IDs/new global question codes, target conflicts/import states, retries/partial results and audit before implementation. Large operations use background processing; this does not authorize raw multi-tenant database restore. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## Current notification delivery scope

Implement in-app taxonomy review alerts for all active coaching admins including Owner. The user revoked notification emails; no notification SMTP/outbox/digest or notification-only mandatory email field is part of this scope. Existing authentication/identity requirements remain separate.


## Local development hosting - confirmed 18 October 2026

User-confirmed (18 October 2026): the development app will be hosted on this PC. Production hosting is deferred; do not infer public PC hosting, remote faculty access, a purchased cloud account or a production deployment. The assistant should propose a local development setup with persistent data/assets, background jobs and configuration boundaries compatible with later hosting. Stack/runtime/resource compatibility and representative performance are not verified. No dependencies have been installed and no server or application has been started.

The monthly hosted-server/storage budget question is deferred with production hosting; this is a planning consequence, not an approved zero-cost or unlimited budget. Coaching-owned AI APIs and their usage/budget controls remain separate. The current interview has no further required user questions; design consolidation and document review must precede code.
