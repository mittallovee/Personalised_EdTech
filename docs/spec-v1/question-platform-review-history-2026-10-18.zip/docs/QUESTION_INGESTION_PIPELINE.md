# Question Ingestion Pipeline

## Workflow contract additions — draft

Manual entry is part of the faculty requirement, although it does not run file extraction. It joins after source-specific extraction/parsing at shared candidate validation/staging. It must not skip review, identity rules, relationship checks or provenance.

### Distinct state dimensions

| Dimension | Purpose | Proposed examples |
| --- | --- | --- |
| Job processing | Overall machine work | Queued, processing, completed, partially completed, failed |
| Stage/attempt | Retry and diagnostics | Pending, running, succeeded, failed; attempt/time/error |
| Candidate parsing | Structural uncertainty | Parsed, needs structural correction, unsupported structure |
| Candidate review | Human disposition | Draft, submitted, changes requested, accepted, excluded |
| Question publication | Authoritative bank state | Draft, content QC, approved, published |

Only the forward publication flow and core job states come from the handover; detailed review transitions and cancellation remain open. A completed job must not imply approved candidates or published questions.

### Stage outputs and preservation

- File validation records safe type/size/checksum metadata and rejects unsupported/encrypted/corrupt input according to D-10/D-11.
- Extraction records source units: PDF page numbers and appropriate paragraph/table anchors for DOCX. DOCX page numbering is not assumed stable without a defined rendering method.
- OCR stores selected language/configuration and marks uncertain outputs; source image references remain available for review.
- Segmentation preserves uncertain fragments, numbering and grouping, rather than silently discarding them.
- Parsing retains equations, diagrams, options, passage links and separate answer/solution references where supported; failures are visible per candidate.
- Candidate disposition records reviewer/action and links to created or existing masters. Reprocessing preserves prior human decisions according to a reviewed policy rather than silently overwriting them.

### Failure and retry invariants

The original file is immutable. Each stage has a reproducible input/output identity and safe failure summary. A repeat delivery or retry may reuse completed outputs under the same processing configuration; a changed parser/prompt/configuration is a separately traceable run. Original checksum and API idempotency solve different problems.

Treat infrastructure timeouts as potentially retryable; malformed inputs, unsupported encryption and forbidden access are actionable failures. Limits/backoff, manual retry authority, stage-resume behavior and cancellation are D-12. Store partial successes and disclose failure scope. Do not mark malformed content correct merely to complete a job.

### Evaluation and release evidence

The first prototype must demonstrate representative PDF and DOCX processing, manual candidate entry, source-linked correction, failure recovery without re-upload, tenant-safe file/job access and no silent master duplication. Measure extraction quality using [the corpus plan](ACCEPTANCE_TEST_PLAN.md), not job completion count alone.

## Inputs
First release: PDF, Word (.doc and .docx), images and manual entry. XLSX/bulk CSV remain later candidates. Manual entry and file-based ingestion converge on the same candidate-question pipeline. Exact image extensions and legacy Word conversion implementation still require design review; support for .doc is confirmed.

## Stages
1. Upload request and authentication/authorization.
2. Validate extension, MIME, size, file signature, and file integrity; scan where feasible.
3. Compute checksum; store original in private object storage.
4. Create `ingestion_job` and source-file record transactionally where possible.
5. Enqueue background job.
6. Inspect source/layout features and look up saved patterns. For unknown layouts use AI extraction/structure discovery and save reusable versioned rules; matching layouts reuse validated rules with AI fallback for unknown/drifting regions. Extract text/recognize images or handwriting as required, preserving source coverage.
7. Extract DOCX paragraphs, tables, and embedded assets where feasible.
8. Preserve source page/paragraph references and extraction warnings.
9. Segment with selected reusable layout rules; unfamiliar layouts use AI bootstrap and validation, while known layouts aim to reduce repeated AI calls/tokens. Never force a mismatched pattern or silently drop uncertain content.
10. Parse question stem, options, answer/key, solution, diagrams/tables/equations into structured candidate content.
11. Calculate extraction/segmentation confidence; uncertain items go to manual review.
12. Store candidates in staging; do not auto-publish.
13. Run configured direct AI metadata filling and duplicate candidate detection; create missing provisional concepts under the confirmed admin-notification/revocation policy.
14. Human reviewer corrects and confirms.
15. Link to existing master/variant/translation or create a new master and version.
16. Record audit trail and final job summary.

## Job states
`QUEUED → PROCESSING → COMPLETED`
Also support `PARTIALLY_COMPLETED`, `FAILED`, and `CANCELLED` if cancellation semantics are implemented.

## Reliability
- Idempotency key plus checksum handling.
- Per-stage status, retry count, timestamps, and structured errors.
- Retry transient infrastructure errors; route malformed/unsupported content to actionable failure.
- Reprocessing should not create duplicate master questions.
- Store source references and raw extraction output for troubleshooting.
- Never silently drop a candidate because segmentation confidence is low.

## Prototype acceptance criteria
- PDF and DOCX upload works.
- Status and failures are observable.
- Extracted candidate questions retain source file and page location.
- Candidates can be reviewed in staging.
- Failed jobs can be retried without re-uploading.
- Tenant boundaries are tested.
- Re-upload/reprocessing does not silently create duplicate master questions.
- A representative evaluation corpus is used to measure quality rather than claiming accuracy without evidence.

## Expanded release-one source scope

The user included images alongside PDF and Word in the first release. Standalone image OCR and embedded question assets need explicit provenance, decoding limits and reviewed file support. Document limit: 50 MB/file; image limit: 10 MB/file. See [upload policy](UPLOAD_AND_ASSET_POLICY.md). All nine formats must be representable in staging/manual entry; parser uncertainty must remain visible. Metadata is primarily AI-tagged using the managed catalogue; unresolved taxonomy activation must not silently publish content.

## Confirmed AI and original-source lifecycle update

AI directly fills validated editable metadata without a per-field approval gate. New concepts may be added and used immediately with AI-added/admin-review-pending status. Notify admin for later approve/edit/merge/revoke; revocation stops new automatic use and preserves published snapshots. This supersedes the earlier approval-first rule; question approve/publish permissions remain separate.

Retain original source files until admin chooses deletion. Only admin can see storage analytics and delete originals; faculty can view their organization's originals. Original deletion must preserve saved questions and independently retained required diagrams/assets, show source-unavailable status honestly and record the deletion. No automatic expiry has been selected. See [source lifecycle](SOURCE_STORAGE_AND_RETENTION.md).

## Language catalogue and metadata display review update

English, Hindi and Gujarati were explicitly requested, plus three or four widely used regional languages. Initial four regional defaults are Bengali, Marathi, Telugu and Tamil, selected under that criterion. Admin may add more languages. See [language support](LANGUAGE_SUPPORT.md) for source basis and capability verification. Display one language at a time; each translation has a new master/code linked to the source; detailed QC remains open and generation is faculty-requested after source review.

The normal question view shows final/current metadata. Internal audit and AI provenance remain required; a per-field change timeline is not a required normal-screen feature.

## Bulk mixed-source upload — confirmed

User-confirmed: first release supports bulk upload of multiple PDF, Word and image files in one submission. Preserve per-file validation, source identity/checksum, tenant scope and observable progress/errors; existing 50 MB/document and 10 MB/image limits remain per file. Bulk upload does not bypass staging/QC or imply automatic publication. Exact maximum file count, aggregate bytes, resumable transport and handling of separate paper/answer-key associations remain design work.

## Link separate paper, answer key and solution sources — confirmed

User-confirmed: question papers and their answer keys/solutions may be separate files and must be linkable for joint processing in the first release. Preserve group identity and independent question/answer/solution source locations; candidates may reference multiple files. Ambiguous/missing/conflicting matches remain reviewable, not fabricated or silently dropped. Manual versus AI pairing and detailed matching policy remain open. See [linked multi-file ingestion](MULTI_FILE_INGESTION.md).

## AI file pairing with faculty correction — confirmed

User-confirmed: AI identifies and directly links related paper/key/solution files; faculty may correct the pairing afterward. Do not require manual group selection or confirmation before AI pairing runs. Retain model/matching/source provenance, distinguish file grouping from answer alignment and re-evaluate affected candidate associations when pairing is corrected. Ambiguities remain visible for review; protected question edits and published history still follow existing permissions/version rules.

## Faculty-requested solving of missing answers — confirmed

User-confirmed: when an imported question has no answer, faculty can request AI to solve it and fill the answer. On-demand only; no automatic solving for every upload. Preserve model/prompt/source-revision provenance and distinguish AI output from an extracted key. Validate answer format and retain normal QC; generation alone grants neither verified status nor publication. Solutions remain optional. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Automatic own-coaching duplicate checks — confirmed

User-confirmed: every new question is automatically checked against its own coaching's existing question bank for duplicates. Shared downstream rules cover manual/import/generated candidates. Preserve tenant-safe candidate evidence and sources; human QC confirms duplicate/variant/translation disposition before canonical/merge decisions. Do not silently reject/delete uncertain candidates or collapse distinct variants/translations. Exact matching policy/thresholds and final confirmed-duplicate treatment remain open. See [duplicate policy](DUPLICATE_AND_VARIANT_POLICY.md).

## Exact duplicate attaches source without new code — confirmed

User-confirmed: after human review confirms an intake candidate is exactly an existing question, link the new source/provenance to the existing question instead of creating a new master/code. Keep the existing permanent code and matching-version evidence; preserve source/candidate records and review audit. Appending source evidence must not silently overwrite content, answer, solution or published metadata. Conflicting keys or non-identical content require visible review rather than forced duplicate treatment. Existing published duplicate masters/canonical merge policy remains separate; variants/translations retain their confirmed distinct codes.

## Legacy DOC and DOCX inputs — confirmed

User-confirmed: first release supports both legacy .doc and modern .docx Word inputs. Apply the accepted 50 MB/document per-file limit and shared bulk/staging workflow. Keep uploaded original bytes; any conversion/extraction artifact needs source/tool/version provenance and visible warnings. Choose and verify an appropriate legacy parser/converter rather than assuming the proposed DOCX extractor covers legacy files. Preserve equations, tables, figures and source anchors where possible; uncertain/lost structure must remain visible for correction. No converter has been selected, installed or tested.

## Handwritten question photos/scans — first release

User-confirmed: handwritten question photos/scans are included in the first release. Use shared extraction/staging/QC with original/source preservation; flag uncertain text, equations, units and diagrams instead of inventing or silently dropping content. OCR/vision engines, per-language quality, corpus and targets must be evaluated; no accuracy is claimed. Source-figure extraction is distinct from faculty-requested diagram generation/editing. See [OCR and handwriting](OCR_AND_HANDWRITING.md).

## Background jobs, concurrent app use and own-job cancel — confirmed

User-confirmed: faculty may cancel their own running file-processing job. Jobs run in the background; faculty can upload new files and perform other app work while earlier processing continues. Use durable independently traceable job/stage state with resource/budget limits, not a blocking UI request. Cancellation is not source deletion or silent removal of published/reviewed content. Partial-output retention, in-flight acknowledgement and completion races need detailed semantics. See [background jobs/cancellation](BACKGROUND_JOBS_AND_CANCELLATION.md).

## Cancelled jobs retain extracted drafts — confirmed

User-confirmed: cancelling a processing job keeps questions already extracted as draft work. Preserve source/candidate identity, progress, warnings and audit; do not discard completed output or alter already reviewed/published states. Cancellation stops further work according to the acknowledged stage contract, not deletion of originals or saved questions. Retry/resume behavior must not duplicate retained candidates/masters; exact cancelled-job restart UX remains open.

## Visual, LaTeX and MathML equation editing — confirmed

User-confirmed: manual equation entry/editing supports visual controls, LaTeX code and MathML code in the first release. Apply shared rich content to relevant stem/options/solution/passage/statements/matching fields, preserving original expression source, preview meaning, multilingual text and version history. Canonical storage, supported syntax/conversion and editor/renderer libraries remain design work; do not claim lossless interchange or silently discard unsupported markup. See [question content editor](QUESTION_CONTENT_EDITOR.md).

## Existing source material available — confirmed, 18 October 2026

User reports the intended question bank has existing source files in PDF/Word/image form. This supports planning ingestion from real source material, not treating all questions as new manual/AI authoring. It does not confirm that every supported format is present, that the full lakh-scale corpus has been uploaded here, or that actual question counts/quality have been verified.

Both selectable/text material and scanned PDFs/photos are confirmed in the existing sources. Next corpus discovery should measure their proportions and per-page quality, handwriting prevalence, layouts, equations/diagrams, languages and separate answer-key/solution associations using representative files. Retain the agreed shared extraction/staging/QC flow, 50 MB/document and 10 MB/image limits, background processing and source preservation. Initial bulk-load schedule, file/asset distribution, extraction/OCR quality and throughput remain to be evaluated. No question-source extraction or corpus benchmark has run.

## Mixed selectable and scanned input — confirmed, 18 October 2026

The existing material includes both text/selectable sources and scanned PDFs/photos. Retain both extraction paths in the initial release and evaluate both against actual examples. Design direction: use available text with source/layout validation and appropriate OCR for scanned/image or unusable-text regions, preserving the original and actual page/image anchors. A document may need page/region-level handling; do not assume every PDF has usable text or force the entire corpus into one mode.

No source-format ratios, resolution/quality baseline, OCR engine, guaranteed accuracy or throughput follow from this answer. Faculty review/correction, equations/diagrams and uncertainty flags remain part of the shared staging/QC workflow. Representative source inspection is still needed before the ingestion examples/engine evaluation can be finalized.

## Adaptive pattern learning/reuse — confirmed first release

Many files share layout A, others B, and more families must be supported. AI initially understands/extracts an unknown layout and saves a versioned reusable pattern. Later compatible files reuse the pattern automatically with coverage/type validation and AI fallback for drift/uncertainty. Patterns describe layout/numbering/key/solution structure, not fixed answers or extensions. Include handwritten questions and solutions; fresh handwriting still needs recognition. Metadata/other AI work is accounted separately. See [adaptive extraction](ADAPTIVE_EXTRACTION_PATTERNS.md).

The user will supply samples later; continue requirements/design now and keep engine/threshold/quality/token/time evaluation pending. Patterns remain separate per coaching; platform admin may explicitly share the complete dataset with another coaching. A platform share creates an independent initial copy; future source changes are not synchronized. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).
