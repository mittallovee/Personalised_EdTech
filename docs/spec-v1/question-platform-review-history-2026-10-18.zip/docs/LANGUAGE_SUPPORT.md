# Question Language Support

Status: first-release language direction confirmed on 17 October 2026; four regional defaults selected from the user's requested prevalence criterion. Actual OCR, rendering and AI quality have not been verified.

## Initial catalogue

| Language | Proposed stable code | Basis |
| --- | --- | --- |
| English | en | Explicitly requested |
| Hindi | hi | Explicitly requested |
| Gujarati | gu | Explicitly requested |
| Bengali | bn | Regional default selected under the user's request |
| Marathi | mr | Regional default selected under the user's request |
| Telugu | te | Regional default selected under the user's request |
| Tamil | ta | Regional default selected under the user's request |

The user requested English, Hindi, Gujarati and three or four widely used regional languages, with admin able to add more. Four are selected here: Bengali, Marathi, Telugu and Tamil. They follow Hindi in the descending mother-tongue speaker table reproduced in the [Government of India language statement, annexure, 16 March 2021](https://mha.gov.in/MHA1/Par2017/pdfs/par2021-pdfs/LS-16032021/292.pdf), using **Census 2011** data. This is a transparent historical selection basis, not a claim to a measured 2026 ranking or language preference of coaching students.

## Admin extension

Admin can add languages to the catalogue using a stable identity/code and display/native label, with audit. Exact platform-versus-organization management scope remains open; do not infer cross-tenant configuration rights. New language registration must not overwrite existing question identities or change the language of an old published version.

Track capabilities separately: storing/manual entry, rendering/search, source OCR and particular AI operations. Adding a catalogue entry is not proof that every OCR/translation provider handles it. The first-release language scope requires actual representative rendering/extraction/tagging evidence before claiming support complete.

## Content and taxonomy

Store original Unicode content and language metadata without losing equations, figures, options or source context. Taxonomy concepts need stable IDs distinct from translated labels/aliases so that different spellings/languages do not create unrelated knowledge concepts automatically.

The user confirmed one question language displayed at a time; simultaneous side-by-side bilingual display is not required. Each translation has a distinct master and new permanent question code, explicitly linked to the reviewed source version (D-15). Translation generation is faculty-requested, not automatic for every language. Language support does not by itself finalize translation workflow or user-interface localization.

## Acceptance

Verify representative question entry, rendering, source extraction/OCR where applicable, direct metadata population and search/filter behavior for the initial seven languages. Test admin language creation, non-admin denial of catalogue administration, Unicode preservation, source-language provenance and historical-version stability. Any unavailable capability must be explicitly recorded rather than represented as tested because the language appears in a dropdown.

## ## Metadata language — user-confirmed

AI-populated user-facing metadata uses the question language. English metadata is not additionally mandatory. Taxonomy/concept identity remains language-independent through stable IDs, with localized labels/aliases. The same concept label in Hindi/English should not automatically become unrelated concepts. Internal controlled codes are implementation identifiers, not a requirement to show duplicate English fields. Fallback for an unavailable localized label remains to be designed; do not silently force English as a mandatory second metadata set.

## On-demand question translation — confirmed

Faculty requests generation in a supported target language only after the source question has completed review. Requests before review completion are not permitted. Review completion is the confirmed gate; do not silently replace it with a requirement for prior publication. Do not automatically translate every uploaded question into all languages. Keep the source-version link, output language and model/prompt provenance; translation generation does not itself publish the result. Translation gets a distinct master/new permanent code and its own versions; detailed permission/QC semantics remain under review.

## Translated question identity — confirmed

A translated question has a distinct master/new permanent question code and its own version history. Store explicit translation-of and reviewed source-version provenance; enforce same-organization relationships. Correction of a published translation creates another version under that translation's stable code. Retry/replay must not create duplicate masters/codes. Original source content/code remain unchanged.

## Independent source/translation updates — confirmed

The user confirmed that original and translated questions may be updated independently. Do not require simultaneous edits or automatically overwrite a translation when its source changes. Each master keeps its own stable code and version history; preserve the translation-of link and exact originating source version. Published corrections create a new version for the affected master. This does not authorize silent mutation of either published version.
