# Platform, Coaching Admin and Faculty Access — Confirmed Policy

Status: consolidated requirements as of 17 October 2026. No authorization implementation exists. Separate admin-granted review/QC is confirmed; shared pending-review access without mandatory assignment is confirmed; exact role labels and UI configuration remain design work.

All faculty accounts are admin-invited/created and belong to one coaching only. Coaching roles need active membership and remain isolated from other coachings. **Platform admin has full application access across all coachings**, including every capability below; Owner-only/admin-only wording describes coaching-role restrictions, not a restriction on platform administration. See [platform full access](PLATFORM_ADMIN_ACCESS.md).

| Capability | Confirmed access policy |
| --- | --- |
| View own coaching's complete question bank | Available to faculty across creators/uploaders |
| View knowledge graph and open a concept's linked questions | Faculty within own coaching in release one; includes primary/secondary concept links under existing bank access; no graph-write or question-edit permission inferred |
| View original sources within the coaching | Available to faculty, subject to source availability and tenant access |
| Upload PDF/Word/images | Available to all faculty by default; no separate per-user enable permission |
| Cancel own file-processing job | Faculty may request cancellation of their own jobs; this does not grant original deletion or cancellation of other faculty jobs |
| Manual question entry | Available to all faculty by default; no separate per-user enable permission |
| AI metadata/tagging tools | Available to all faculty by default; validation/provenance and protected-edit rules still apply |
| Request AI practice variants | Available to all faculty by default; on request only, no source-review prerequisite; count/type/difficulty/instructions supported |
| Request AI diagram generation/editing | Available to all faculty by default; on request only; preserve originals and published versions |
| Request AI solving/filling of a missing answer | Available to faculty by default as an on-demand AI tool; type validation, source provenance and normal QC still apply |
| Request AI translations | Available to all faculty by default; on request only after source review completes |
| Edit another faculty's question | Requires permission granted by admin; viewing does not grant editing |
| Formally review/QC and return for correction | Requires separate admin-granted review/QC permission; any such faculty may review own-coaching pending work without mandatory assignment; bank viewing/AI access is not review authority |
| Approve a question | Requires its own permission granted by admin; creation/upload or AI use grants neither approval nor publication |
| Publish a question | Requires its own permission granted by admin plus valid workflow/content/metadata; approval permission alone is insufficient |
| Faculty's own approval/publication | Allowed when that faculty has the corresponding grants; a different reviewer is not universally mandatory |
| Change coaching display name/logo | Platform admin only; coaching Owner/admin/faculty cannot change branding, including indirect organization-profile or logo-asset writes |
| Share complete coaching dataset/patterns with another coaching | Platform admin only, explicit source/target; data/patterns remain separate otherwise; independent educational-content/pattern copy, destination use/edit under its roles, no synchronization; users and API keys configured separately |
| Full platform administration | Platform admin across all coachings and supported app capabilities, including QC/approve/publish, users/Owners/roles, originals/storage, taxonomy, AI credentials/configuration/jobs and analytics; validation, versions and audit apply |
| Edit questions across all coachings | Platform admin; target coaching, revision/type validation and audit; published edits create a new editable version |
| View all coaching question banks | Platform admin through explicit platform-read scope with coaching context/audit; tenant roles cannot inherit it; full platform role also includes edits, original-source access and protected credential administration |
| Create coaching and its first Owner | Platform admin only; no public coaching self-signup or tenant-role self-promotion; full cross-coaching application authority is confirmed |
| Invite/create faculty | Coaching admin only |
| Remove ordinary faculty from coaching app | Any admin, including Owner, within own coaching; validate target is currently ordinary faculty, revoke access and preserve organization data/history; no removal of admin/Owner through this route |
| Transfer coaching ownership | Current principal Owner/Admin to another active admin in the same coaching; former Owner remains a regular admin and loses owner-only rights; transfer mechanics remain under review |
| Admin notifications/contact | In-app only for all active coaching admins including Owner; no separate required notification email; existing login/identity requirements remain |
| Appoint/remove other coaching admins | Principal Owner/Admin within own coaching; Owner explicitly chooses normal faculty or removal from coaching app with no coaching access; ordinary admin/faculty status alone does not grant this capability |
| Number of coaching admins | Multiple admins allowed within one coaching; individual memberships and actor audit; principal coaching Owner/Admin appoints/removes other admins; owner-initiated transfer to another same-coaching admin confirmed; former Owner remains regular admin after transfer; platform-admin creation of first Owner confirmed; invitation/identity, recovery and transfer mechanics remain open |
| Enabled AI models and coaching default | Coaching admin chooses from the supported catalogue; faculty may select enabled compatible models |
| Coaching-owned provider credentials | Coaching-scoped administration; exact management UX/secret manager remains design work, never expose keys through faculty AI tool access |
| Faculty-wise AI usage/cost management dashboard | Admin management visibility within own coaching; faculty self-usage UI is not decided |
| Storage usage dashboard | Admin only |
| Archive question from active bank | Admin within own coaching, or the question's creator for their own question; preserve content/history; cross-author edit grant alone does not grant archive |
| Restore archived question | Admin within own coaching, or creator for own question; retain code/history and valid lifecycle state |
| Delete original ingestion files | Admin only; preserve saved questions and required assets |
| Administer AI-added prerequisite links | Admin approves, corrects or revokes after immediate provisional activation/notification; no faculty graph-edit grant inferred |
| Create class/subject/chapter/topic/subtopic entries | Admin or authorized AI taxonomy workflow only; faculty may select existing entries under question-edit permissions, without manual/implicit catalogue creation |
| Create new concept identities | Admin manually or authorized AI taxonomy workflow only; faculty cannot manually create concepts, but may select existing concepts within question-edit permissions |
| Review AI-added taxonomy concepts | Admin may approve/edit/merge/revoke after immediate AI activation |
| Add supported languages to catalogue | Admin may add languages; capability verification remains required |

## Boundaries of default tools

Default tool access does not bypass tenant isolation, available supported models, configured resource/budget limits, valid source eligibility, required QC or immutable published versions. It does not authorize protected changes to another creator's question. An AI operation that creates a separate variant/translation differs from applying changes to an existing protected question; enforce the existing edit/approve/publish policy on actual writes.

No separate admin-managed per-user enable flags are required for upload, manual entry or AI tools. Provider configuration and shared usage controls remain technical/operational design topics rather than a reversed access-policy decision.

## Remaining permission questions

Shared pending-review access is confirmed without mandatory assignment. Own-draft defaults, administration delegation/custom roles and exact permission-management UI remain to be finalized. Review/QC and its correction-return workflow require the confirmed separate admin grant. Do not infer that ordinary faculty tool access grants these unreviewed capabilities.

## Monthly per-faculty AI budgets — confirmed

User-confirmed: admin can configure a monthly AI spending limit for each faculty member. Keep tenant/faculty attribution, budget amount/currency/period and auditable admin changes. This is spending control, not a reversal of default faculty AI tool access. Whether exceeding the limit only warns or blocks new AI work, exact monthly reset semantics, concurrency reservations and cost-reconciliation policy remain open; do not assume a numerical default or threshold behavior.

## Opt-in AI corrections with visible changes — confirmed

AI must flag suspected errors and show corrected answer/solution suggestions. Faculty may opt in to direct application, and the interface must still show the old/new values and reason. Without opt-in, the operation leaves existing answers/solutions unchanged. Enforce current same-tenant edit permissions and revision conflict/type-validation checks on actual writes, including background completion; never silently overwrite a concurrent edit. Keep source values and actor/model/input/application provenance. Correcting published content creates an editable new version under the same master/code, retaining the existing published snapshot and normal revision-bound QC/approval/publication controls. Direct-correction opt-in applies to one question at a time, selected separately for that question; no batch-wide or carried-over opt-in. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).
