# Database Schema — Conceptual Draft

## Schema review notes

This remains a conceptual design, not executable SQL. D-06/D-07/D-08/D-09/D-15 affect the final schema. In particular, draft mutation versus append-only revision storage must be reconciled before migrations; published immutability is agreed.

### Tenant and identity integrity

Every tenant-owned row has a non-null organization reference. Child relationships should use composite tenant-aware foreign keys or equivalently enforced constraints, not rely solely on application filtering. This applies to files/jobs/candidates, master/versions, assets, taxonomy assignments, AI runs, question links and future test/version links.

Master uniqueness and version numbering require database constraints. A proposed `(organization_id, question_id, version_number)` uniqueness rule prevents concurrent duplicate version numbers. Public question codes must be unique across the whole platform, as confirmed by the user. Use a global unique constraint on question_code; organization-scoped uniqueness alone is insufficient. Codes must not be silently recycled after deletion; the exact lifecycle policy is D-06/D-19.

### Candidate, version and provenance separation

- Candidates retain raw/extracted content, confidence, warnings, source positions and reviewer corrections; their processing status differs from review status.
- A master represents identity and organization ownership, not a mutable substitute for a published content snapshot.
- A version stores the content/schema version, answer/solution, language, metadata and asset references needed to reconstruct it. It must not depend on mutable external answer/asset content.
- Assets need tenant-scoped ownership, media metadata, checksum/storage identity, source references and version attachment rules. Changing referenced bytes must not change old published rendering.
- AI suggestions and human-accepted values need separate provenance; overwriting an accepted field must retain required decision history.
- Lifecycle/audit events record actions. They are not a replacement for enforceable version locking or foreign keys.

### Jobs and idempotency

Represent attempts and stages explicitly enough to recover from failures: state, stage key, attempt count, timestamps, retryability, safe error and output references. Use unique stage/candidate identities so replay cannot create duplicate outputs. Define idempotency-key namespace, payload fingerprint and replay response. A checksum match alone does not establish that two users intended the same processing operation.

### Relationships and translations

Typed links must constrain allowed source/target scope and reject invalid self-links where relevant. Duplicate/canonical direction, whether cycles are allowed and link approval rules depend on D-14. D-15 is resolved for identity: each translation is a distinct question master with a new permanent question code, linked to the source master and reviewed source version. A translated output must retain the originating source version so later corrections can be reviewed.

### Historical preservation and deletion

Published version protection must include normal runtime database writes, not only API checks. Choose enforceable DB constraints/triggers/permissions after finalizing draft semantics. Taxonomy label edits, asset replacement, master archival and user removal must not alter historical test rendering. Deletion/retention must prevent cascading away versions referenced by tests; production policies remain open.

### Additional conceptual entities to evaluate

Job attempts/stage outputs, review decisions, asset references, prompt templates, model catalogue/configuration and usage ledgers may need dedicated tables rather than overloaded JSON. Tests/test versions/test items and batch constraints belong to the later test milestone. Final normalization depends on query, audit and integrity needs; no new table list is an approved migration.

This is a design draft, not a verified migration or final SQL specification.

## Core entities
- `organizations`: tenant identity, slug/name, lifecycle timestamps.
- `organization_memberships`: user ↔ organization relationship, role and status.
- `users` or external identity mapping: identity provider subject; avoid storing unnecessary identity data.
- `ingestion_jobs`: organization, requester, status, idempotency key, source count, progress, error summary, timestamps.
- `source_files`: organization, job, storage key, original filename, MIME type, byte size, checksum, upload metadata.
- `extracted_questions`: organization, job, source file, page range, raw text, structured candidate JSON, confidence, processing status, review status.
- `questions`: internal UUID, organization, stable 8-character alphanumeric question code, lifecycle status, created/updated metadata.
- `question_versions`: immutable version rows with version number, structured content, language, answer/solution, metadata snapshot, created-by, created-at, publication fields.
- `question_relationships`: typed links such as variant-of, translation-of, duplicate-of, related-to.
- `taxonomy_nodes`: extensible hierarchy for class/subject/chapter/topic/concept; alternatively use normalized tables if query needs justify it.
- `question_taxonomy_assignments`: version-scoped taxonomy assignments and provenance/confidence.
- `ai_runs`: provider/model, operation, prompt version, input/output references, status, token/cost metadata if available, timestamps.
- `audit_logs`: tenant, actor, action, entity type/ID, before/after references or safe diff, correlation ID, timestamp.
- Future: tests, test versions, test-question links, student attempts and analytics.

## Important integrity requirements
- Separate internal UUID, human-readable question code, and question version ID.
- Enforce global uniqueness on `question_code` across all question masters/organizations. Keep organization ownership and tenant-safe foreign keys independently.
- Generate codes using a cryptographically secure random source; handle collisions by retrying after unique-constraint conflict.
- Use immutable version rows; published content should not be silently overwritten.
- A test must reference a specific question version, not just the master question.
- Use tenant-aware foreign keys where practical to prevent cross-tenant links.
- Ensure source file, ingestion job, and extracted question organization IDs are consistent.
- Index common filters: organization, status, question type, language, taxonomy assignments, exam/year, and creation time.
- JSONB is suitable for flexible structured question content, but normalize fields needed for frequent filtering and constraints.
- Define deletion/retention rules before production; consider soft-delete and legal retention needs.

## RLS and tenant safety
- Enable RLS on tenant-owned tables.
- Use a trusted server-side transaction/session to set tenant context.
- Policies must fail closed when tenant context is absent.
- Never trust a tenant ID supplied by an untrusted client without verifying membership.
- Add integration tests proving tenant A cannot read/write tenant B rows.
- Test worker jobs and background connections too; RLS can be bypassed accidentally by privileged roles.
- Keep migration/owner credentials separate from application runtime credentials.

## Versioning
- Draft edits can update a draft version under permission rules.
- Approved/published changes should create a new version, with explicit supersedes relationship.
- Preserve the exact version used in every published test.

## Detailed taxonomy direction from review

Class/subject/chapter/topic/subtopic hierarchy and primary/multiple secondary concept assignments are required. Preserve stable concept identities, catalogue version/provenance, aliases and admin corrections. AI creates/extends the catalogue and primarily tags from it. The user confirmed provisional immediate activation for tagging, admin notification and later approve/edit/merge/revoke; prior admin approval is not required to continue. See [taxonomy design](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Confirmed AI and original-source lifecycle update

AI directly fills validated editable metadata without a per-field approval gate. New concepts may be added and used immediately with AI-added/admin-review-pending status. Notify admin for later approve/edit/merge/revoke; revocation stops new automatic use and preserves published snapshots. This supersedes the earlier approval-first rule; question approve/publish permissions remain separate.

Retain original source files until admin chooses deletion. Only admin can see storage analytics and delete originals; faculty can view their organization's originals. Original deletion must preserve saved questions and independently retained required diagrams/assets, show source-unavailable status honestly and record the deletion. No automatic expiry has been selected. See [source lifecycle](SOURCE_STORAGE_AND_RETENTION.md).

## Language catalogue and metadata display review update

English, Hindi and Gujarati were explicitly requested, plus three or four widely used regional languages. Initial four regional defaults are Bengali, Marathi, Telugu and Tamil, selected under that criterion. Admin may add more languages. See [language support](LANGUAGE_SUPPORT.md) for source basis and capability verification. Display one language at a time; each translation has a new master/code linked to the source; detailed QC remains open and generation is faculty-requested after source review.

The normal question view shows final/current metadata. Internal audit and AI provenance remain required; a per-field change timeline is not a required normal-screen feature.

## Localized taxonomy metadata

User-confirmed: user-facing metadata follows question language; no mandatory English duplicate. Store stable taxonomy/concept identities independently from localized labels/aliases, with language-tagged values and version-scoped assignments. Exact fallback behavior remains open.

## Independent source/translation updates — confirmed

The user confirmed that original and translated questions may be updated independently. Do not require simultaneous edits or automatically overwrite a translation when its source changes. Each master keeps its own stable code and version history; preserve the translation-of link and exact originating source version. Published corrections create a new version for the affected master. This does not authorize silent mutation of either published version.

## Passage child identity — confirmed

Each passage child is a separate question master with its own permanent code and versions, linked to shared passage context. Preserve the exact passage content needed by a published child version; modifying a shared current passage must not silently change historical published rendering. Passage storage/version-link schema remains design work; no human-readable parent-passage code has been required.

## Distinct identity for practice variants — confirmed

User-confirmed: a new practice variant made by changing values or conditions receives its own permanent, globally unique eight-character alphanumeric question code. It is a distinct question master with its own version history, explicitly linked as variant-of to the original. Preserve source-version and creation/AI provenance where applicable. This does not change the correction policy: correcting an existing question creates a new version under that existing master/code. Automatic variant generation, inheritance of review status and generation permissions are not established by this answer.

## Admin-only faculty onboarding — confirmed

User-confirmed: faculty accounts are created/invited only by admin; public self-signup is not the faculty onboarding route. Authentication alone cannot enroll an uninvited user or grant organization permissions. Preserve organization-scoped invitation/membership and audit. Owner/platform bootstrap, invitation delivery and verified account linking remain separate design questions.

## Single-coaching faculty account — confirmed

User-confirmed: each faculty account belongs to only one coaching organization and cannot switch between multiple coaching memberships. The platform remains multi-tenant, with separate faculty accounts/data for different organizations and runtime isolation. Enforce the single-coaching account scope server-side; hiding a switcher is not sufficient. This faculty rule does not define platform-owner/admin scope or whether the same human may hold separately provisioned accounts; do not silently infer identity-provider/account-merging behavior.

## Link separate paper, answer key and solution sources — confirmed

User-confirmed: question papers and their answer keys/solutions may be separate files and must be linkable for joint processing in the first release. Preserve group identity and independent question/answer/solution source locations; candidates may reference multiple files. Ambiguous/missing/conflicting matches remain reviewable, not fabricated or silently dropped. Manual versus AI pairing and detailed matching policy remain open. See [linked multi-file ingestion](MULTI_FILE_INGESTION.md).

## Faculty-wise AI usage/cost for admin — confirmed

User-confirmed: admin needs faculty-wise AI usage and cost reporting. Record tenant, faculty/requester, operation, model/provider and available usage/cost evidence. Separate provider-reported actual cost, calculated estimates and unavailable values; do not show unknown as zero. Dashboard visibility does not itself define budgets or per-user feature gates. See [AI usage/cost dashboard](AI_USAGE_AND_COST.md).

## Monthly per-faculty AI budgets — confirmed

User-confirmed: admin can configure a monthly AI spending limit for each faculty member. Keep tenant/faculty attribution, budget amount/currency/period and auditable admin changes. This is spending control, not a reversal of default faculty AI tool access. Whether exceeding the limit only warns or blocks new AI work, exact monthly reset semantics, concurrency reservations and cost-reconciliation policy remain open; do not assume a numerical default or threshold behavior.

## Calendar-month usage reset — confirmed

User-confirmed: monthly budget usage starts afresh on the first day of every calendar month. Preserve prior-month usage/cost and audit history; reset the current-period counter, not historical records. Apply the configured faculty limit to the new period. This is not a rolling 30-day window. Exact organization timezone, in-flight request attribution at month boundaries and cost-reconciliation rules remain implementation design work.

## Coaching-owned AI API keys — confirmed

User-confirmed: each coaching supplies its own AI provider API keys instead of using centrally shared platform keys. Resolve secrets per organization for all API/worker operations, preserve credential-reference provenance without secret exposure, and never fall back to another coaching's/shared key. Provider billing belongs to the configured coaching account; application usage/budgets cover recorded app calls. Provider catalogue, secret manager, rotation/validation UX and fallback ordering/attempt limits remain design work; automatic fallback uses only the same coaching's configured keys. See [coaching-owned credentials](TENANT_AI_CREDENTIALS.md).

## Coaching-admin enabled models and default — confirmed

User-confirmed: each coaching admin can enable/select which models from the platform-supported catalogue are available in that coaching and set its default model. Faculty choose from that coaching's enabled, supported, operation-compatible models; default is available for quick use. Resolve only that coaching's provider keys. Tenant configuration cannot introduce arbitrary untested models or bypass capabilities/resource budgets. Automatic fallback with a visible error is confirmed; per-operation default details, fallback order/attempt limits, catalogue updates and UI remain design work.

## Exact duplicate attaches source without new code — confirmed

User-confirmed: after human review confirms an intake candidate is exactly an existing question, link the new source/provenance to the existing question instead of creating a new master/code. Keep the existing permanent code and matching-version evidence; preserve source/candidate records and review audit. Appending source evidence must not silently overwrite content, answer, solution or published metadata. Conflicting keys or non-identical content require visible review rather than forced duplicate treatment. Existing published duplicate masters/canonical merge policy remains separate; variants/translations retain their confirmed distinct codes.

## Admin and creator question archival — confirmed

User-confirmed: archive removes a question from the active bank while retaining content/history. Admin may archive questions in their own coaching, and creator faculty may archive their own question. Complete-bank view or cross-author edit permission alone does not grant archive authority over other creators' questions. Preserve code, immutable published versions, assets, sources/audit and historical references; archival is not physical deletion or admin-only original-file deletion. Restore behavior remains open. See [question archival](QUESTION_ARCHIVAL.md).

## Admin and creator may restore archived questions — confirmed

User-confirmed: both admin and creator may restore archived questions. Admin acts within their coaching; creator acts on their own question. Keep the existing code, content/versions/provenance and archive/restore audit. Restoring availability is not automatic approval/publication of an unreviewed draft or authority to overwrite published content. Detailed state/eligibility and concurrency handling remain design work.

## Video solution link only — confirmed

User-confirmed: video solutions use a stored external video link; video-file upload/hosting is not required for the first release. Video solution metadata remains optional under the handover. Validate safe URL structure and preserve the link in version-scoped metadata; do not fabricate a video URL or claim external content is hosted/archived by this platform. Existing edit permissions and published-version rules apply to link changes. Link/player UI details remain design work; no streaming service or provider has been selected.

## Visual, LaTeX and MathML equation editing — confirmed

User-confirmed: manual equation entry/editing supports visual controls, LaTeX code and MathML code in the first release. Apply shared rich content to relevant stem/options/solution/passage/statements/matching fields, preserving original expression source, preview meaning, multilingual text and version history. Canonical storage, supported syntax/conversion and editor/renderer libraries remain design work; do not claim lossless interchange or silently discard unsupported markup. See [question content editor](QUESTION_CONTENT_EDITOR.md).

## One chapter and one topic per question — confirmed

User-confirmed: a question has only one chapter tag and one topic tag, not multiple chapters/topics. Required chapter/topic classification at publication means one valid selected value of each; incomplete drafts can still omit required values until ready. Preserve optional subtopic and the separately confirmed primary plus multiple secondary concept associations. Multiple concepts do not authorize hidden extra chapter/topic tags. Cross-branch concept association rules remain design work; do not silently remove the multiple-concept requirement.

## Faculty-requested AI correctness checking — confirmed

User-confirmed: the first release includes faculty-requested AI checking of an existing answer and available solution. Keep reviewable findings, reasons/uncertainty and exact input-revision/model provenance; answer-only questions remain eligible because solutions are optional. Checking does not silently replace content or grant QC, approval, publication or an AI-verified badge. Use the existing tenant credentials, enabled-model, budget and background-job policies. Flagging, correction suggestions and explicit opt-in direct correction with visible before/after changes are confirmed; verification-badge criteria remain design/review work. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Opt-in AI corrections with visible changes — confirmed

AI must flag suspected errors and show corrected answer/solution suggestions. Faculty may opt in to direct application, and the interface must still show the old/new values and reason. Without opt-in, the operation leaves existing answers/solutions unchanged. Enforce current same-tenant edit permissions and revision conflict/type-validation checks on actual writes, including background completion; never silently overwrite a concurrent edit. Keep source values and actor/model/input/application provenance. Correcting published content creates an editable new version under the same master/code, retaining the existing published snapshot and normal revision-bound QC/approval/publication controls. Direct-correction opt-in applies to one question at a time, selected separately for that question; no batch-wide or carried-over opt-in. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Matching permits unused right items — confirmed

Match the Column allows right-column items that are unused in the correct answer and serve as distractors. Validation must not require every right item to be selected. Keep one-or-more matches per left item, no right-item sharing across different left items in the correct mapping, variable column counts and four combination options with exactly one correct. Preserve unused item content in storage, extraction, editing and rendering. Example: A→P, B→Q, C→R with right-side S,T unused is valid. See [question types](QUESTION_TYPES_SPECIFICATION.md).

## First-release AI prerequisite relationships — confirmed

AI creates concept-to-concept prerequisite links in release one: which concept should be understood before another. Keep directed stable concept IDs, same-coaching/same-subject endpoints, relationship provenance and graph change history, separate from question tags and taxonomy hierarchy. Cross-subject prerequisite links are not allowed, including AI creation and admin corrections. Cross-class links within the same subject/coaching are allowed, including Class 11 prerequisite → Class 12 dependent; different classes alone must not block such links. Personalized student suggestions/mastery analytics remain later. AI links are immediately usable with AI-added/admin-review-pending status and admin notification; admin can later approve, correct or revoke them. Detailed cycle disposition and educational validation remain design work. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Prerequisite subject integrity — design consequence

Preserve stable subject context for prerequisite endpoint references and validate equal subject identity as well as equal organization for active links. Do not rely on display labels or only UI filtering. Subject reassignment/merge must revalidate affected edges while retaining graph revisions. Concrete relational constraints/transactions depend on the final taxonomy schema; no migration is implemented.

## Numerical answer cardinality — confirmed

A numerical question supports one exact answer value or one inclusive accepted range, not multiple separate ranges. There is no separate numerical-answer unit field or unit-field publication requirement; preserve units in original evidence, question/equation/solution content without silently converting numeric values. Keep the 0.00–999.00 domain, two-decimal precision, ordered inclusive endpoints and existing precision-flag policy. Imported/AI multi-range evidence must remain visible for authorized correction; do not silently select one interval or bridge the gap by widening it. Incomplete/flagged drafts remain recoverable, but an invalid multi-range key cannot pass type validation for publication. Concrete storage/API representation remains schema design. See [question formats](QUESTION_TYPES_SPECIFICATION.md).

## Concept creation authority — confirmed

Only admin and the authorized AI taxonomy workflow can add new concepts. Faculty cannot manually create concept identities, including through question-tag inputs; they may select existing concepts and correct question assignments within existing edit permissions. AI may add missing concepts during faculty processing under the immediate provisional/admin-notification policy. Enforce trusted actor/tenant checks in the API/service/worker, not a user-supplied AI flag; retain initiating user and actual AI/admin creation provenance. Creation of class, subject, chapter, topic and subtopic entries is also restricted to admin and the authorized AI taxonomy workflow; faculty selects existing entries and cannot create them through free-text tagging or a direct API call. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Multiple admins per coaching — confirmed

A coaching organization may have more than one admin. Represent administration through individual authenticated identities and organization-scoped memberships/authority; do not impose a one-admin-per-organization constraint or require a shared login. Attribute every administrative action to the actual actor and preserve organization ownership of questions and audit history.

Multiple admins do not imply access to other coaching organizations. Each coaching has a principal Owner/Admin who can appoint and remove its other admins. Ordinary admin status does not itself grant admin-appointment/removal authority. The current Owner may transfer principal ownership to another admin in the same coaching. After transfer, the former Owner remains a regular admin in that coaching and loses principal-owner authority. When removing another admin, Owner chooses either conversion to normal faculty or removal from the coaching app with no remaining coaching access. Platform admin creates the coaching and first Owner; onboarding delivery/identity mechanics, owner recovery and exact transfer/removal mechanics remain design work. Existing independent question QC/approve/publish grants and admin-only catalogue/storage/AI configuration policies remain; do not infer that the numeric admin count changes their semantics.

## All admins may remove ordinary faculty — confirmed

Any active coaching admin (including Owner) may remove an ordinary faculty member from that same coaching's app, revoking coaching access while preserving organization questions/assets, attribution, usage and audit history. Check actor and target current membership/role at commit. Ordinary admins cannot use this action on another admin or Owner; admin demotion/removal remains Owner-only. Session/job/asset-access revocation and identity-cleanup mechanics remain design work. See [identity and access](IDENTITY_AND_ACCESS.md).

## Platform-admin onboarding of coaching and first Owner — confirmed

Platform admin creates each coaching organization and its first principal Owner/Admin. Coaching public self-signup is not available. Coaching Owner/admin and faculty membership do not confer platform-level onboarding authority, and a normal Google/password/OTP login cannot self-assign it. After onboarding, the coaching's Owner controls its other admins under the confirmed policy.

Design direction: keep platform authority separate from tenant membership, validate the intended first-owner identity and record platform actor, organization, owner and outcome. Provision the organization/initial-owner relationship consistently, with safe partial-failure/retry handling and no duplicate organizations or extra principal owners from replay. Invitation delivery/acceptance, verified identity linking and initial platform-admin provisioning remain implementation design.

Platform admin now has full cross-coaching application authority, including all question and tenant-administration capabilities, as defined in [platform access](PLATFORM_ADMIN_ACCESS.md). Earlier limited onboarding/read scope is superseded; preserve workflow, version, tenant-reference, secret-handling and audit rules. No organization or real account has been created.

## Explicit platform question-bank read scope — confirmed

Platform admin can view all coaching question banks using explicit platform-read authorization. Ordinary coaching users retain own-coaching isolation; show coaching ownership/context and audit platform reads. Server-side API/RLS/storage/cache rules must distinguish authorized question reads (including retained content assets needed to display them) from unrestricted tenant-data access. No owner/migration-credential or global RLS bypass is implied. The later full-access decision includes originals/storage, credential administration, edits/QC/approve/publish and supported AI/other application actions; this read-path description is not a limit on the platform role. See [identity and access](IDENTITY_AND_ACCESS.md).

## Explicit platform question editing — confirmed

Platform admin may edit questions in all coaching organizations through explicit platform-edit authorization and target-coaching context. Enforce type/content validation, current revision and tenant-consistent references, and record platform actor plus before/after evidence without transferring coaching ownership/creator attribution. Published corrections create an editable new version under the same master/code; preserve the existing published version and revision-bound QC/approval rules. The later full-access decision also grants QC/approve/publish, supported archive/delete, original-source/credential administration and supported AI/other app actions; the edit-path description is not a limit on platform authority. Use a reviewed restricted API/RLS write policy rather than unrestricted database bypass. See [identity and access](IDENTITY_AND_ACCESS.md).

## Current platform authority — full access

Platform admin has full application access across all coachings, including question QC/approve/publish, originals/storage, users/Owners/roles, taxonomy, AI credentials/configuration/budgets/jobs and analytics. Earlier limited platform read/edit exclusions are superseded. Coaching roles retain their own-coaching boundaries. Validation, published-version preservation, current authority checks, coaching data ownership, secret handling and audit remain required. Full authority covers supported features and does not move deferred test/student features into release one. See [the platform access specification](PLATFORM_ADMIN_ACCESS.md).

## Coaching name and logo in the app — confirmed

Each coaching may display its own name and logo in the application. Include per-coaching branding in the first-release tenant configuration and show it consistently in that coaching's app context. This is display branding, separate from internal organization identity, question ownership and the globally unique question-code scheme. Renaming or replacing a logo does not move data, change question codes or rewrite historical attribution.

Design direction: store a display name and a coaching-owned logo asset reference; validate name/content and image assets through the supported upload/rendering policy. Avoid cross-coaching asset links or cached branding leakage. A missing/unavailable logo should have a clear usable fallback, not prevent question-bank work. Use accessible labeling and preserve the selected coaching context in platform-admin views.

Only platform admin may create/change coaching display name/logo settings. Coaching Owner/admin/faculty cannot change these branding settings; there is no tenant-side branding edit grant. Exact image formats/dimensions/limits, settings UI and public/pre-login placement remain implementation design. Custom domains, color themes, hiding platform identity and later export branding are not established by this name/logo confirmation. No app UI or logo asset has been created.

## Shared URL and coaching identity — confirmed design constraint

All coachings share the app entry URL. Keep stable organization IDs/memberships and tenant-owned branding configuration; a unique public coaching domain/subdomain is not a mandatory organization identity or onboarding field. Faculty scope still comes from verified membership; platform-admin actions use explicit trusted target context. Exact identity/session/deployment schema remains design work.

## Coaching subscription/payment collection — later phase

Coaching subscription and payment collection are explicitly deferred beyond the first release. Initial coaching onboarding and question-bank workflows do not depend on creating a subscription, plan or payment record. Future pricing, commercial plans, invoicing, payment gateway, renewal/expiry and subscription enforcement need their own approved specification before implementation; this is not a commitment to permanent free access.

First-release AI usage/cost reporting, coaching-owned provider credentials and monthly faculty spending controls remain required. Provider charges associated with a coaching's own API keys and application AI-budget accounting are separate from the platform collecting subscription payments. Keep 80% warning/100% new-AI-work stop and monthly reset/history under the existing policy. No payment system, plan or billing integration has been created.

## Lakh-scale question corpus — design requirement

The expected question bank is in lakhs; few users do not imply a small dataset. Plan tenant/status/type/taxonomy/code lookup and bounded list/count/duplicate-candidate access against representative data, with versions/assets/audit included in sizing. Exact schema/index/query choices and measured capacity remain open. No storage cap or new database/search provider is selected. See [capacity and performance](CAPACITY_AND_PERFORMANCE.md).

## Adaptive pattern records and future learning — design direction

Represent pattern identities/versions/configuration, layout signatures/scope/state, protected source/correction evidence and per-extraction pattern-match/mode/fallback provenance. Preserve original run/candidate anchors and new content separately from structural rules; pattern revision cannot rewrite prior runs or published questions. Patterns are coaching-specific with platform-authorized complete-dataset sharing; sharing creates independent destination records; exact mappings/import state and lifecycle thresholds remain design work. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md).

Future course/module/lesson/enrollment, live-session, recording/media-version, learner-evidence, teaching-plan and concept-video records remain later design candidates. Stable tenant/concept/resource IDs and provenance are foundations, not an instruction to create speculative tables now. See [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).

## Coaching-specific patterns and platform dataset sharing - confirmed

Each coaching keeps its data/pattern library separate. Platform admin may explicitly share the complete dataset, patterns and associated material with another coaching. Ordinary coaching roles cannot initiate cross-coaching sharing. Preserve an explicit source/target manifest, complete dependency mapping, question-code/version integrity and platform actor history. Sharing creates a one-time independent initial copy with no ongoing updates in either direction; destination may use/change its own copy. Preserve mapped independent identities/new globally unique codes for new question masters and source provenance. Destination users and API keys are set up separately, not copied; keep source actor/model evidence as provenance, not active memberships/secrets. Source-published questions retain published status without mandatory local re-review on copy; preserve imported QC evidence and immutable snapshots, with later edits using normal new-version review. Destination conflict/failure and operational-reference details remain design work. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## Published status in independent coaching copies - confirmed

When platform admin copies an existing coaching dataset, source-published question snapshots remain published in the destination without mandatory re-review merely for copying. Preserve source QC/publication provenance, the platform copy actor and exact version/dependency mapping; do not invent destination reviewer identities. New destination question masters still receive new globally unique codes. Validate complete snapshot/reference integrity; do not promote source drafts/unreviewed content. Later destination edits create a new editable version under the destination code and follow normal QC/approval/publication; copied published snapshots stay immutable. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## Concept/prerequisite notification evidence - in-app design

Store committed taxonomy events and coaching-scoped recipient/app-notification records, with entity/version correlation, current access checks and separate per-recipient read versus shared review state. Email-outbox/delivery/digest records are not required for these alerts. Alert persistence/retry must not recreate concepts/links or block valid provisional use. No notification table/queue has been implemented.

## All-admin in-app notification fan-out

Create event/recipient evidence for every active admin of the event's coaching, including Owner. Recheck current role/access and deduplicate by event/recipient; maintain individual read state separately from concept/link review. No email work or notification-only required email constraint is included. Retention/new-admin history policy remains design work.

## Identity contact requirements after alert correction

No extra mandatory admin/Owner notification-email field is required for in-app-only alerts. Preserve ordinary identity-provider/login email requirements and account-linking safeguards; do not erase stored contacts or auth identities. The former notification-only constraint and email delivery schema are superseded. No migration/account change has run.

## Canonical user and sign-in identity mappings - design consequence

Keep a stable application user ID and mapped provider/auth identities so Google, email-password and mobile-OTP routes resolve to that same user after verified linking. Memberships/grants, attribution, AI budget/usage and audit reference the canonical identity, not a new user per login method. Provider identifier uniqueness/collision, verified linking history and recovery/unlink transactions need the final identity schema. Account/credential mappings remain excluded from educational dataset copying. No identity tables/migrations have been implemented.

## Multi-device session evidence - design consequence

Support distinct concurrent session records/provider references associated with one canonical user, rather than enforcing a single session slot per account. Budget, membership and notification-read state remain user-scoped; current authorization and revision-conflict checks apply across sessions. No user-facing device-list/remote per-device logout interface is required; persistence/provider strategy, expiry, minimal session evidence and normal logout/revocation mechanics remain design work; no runtime sessions/schema exist.
