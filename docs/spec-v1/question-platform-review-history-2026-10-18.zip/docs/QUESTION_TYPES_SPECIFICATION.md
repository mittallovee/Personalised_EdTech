# Question Types — First-Release Specification

Status: all nine formats below are confirmed for the first release by the user on 17 October 2026. Answer details marked open are not invented defaults. Application implementation has not started.

## Confirmed catalogue

| Format | Confirmed structure | Confirmed answer constraints | Still to specify |
| --- | --- | --- | --- |
| Single option correct (SCQ) | Exactly four options | Exactly one correct option | Option content/rich-text representation |
| Multiple option correct | Exactly four options | One or more of the four options may be correct; a single-correct answer set is valid for this format | Scoring belongs to later test builder; detailed content examples |
| Integer | Question with integer answer | Inclusive range 0–999; no fraction | Input normalization, leading-zero display policy |
| Single digit | Question with single-digit integer answer | Inclusive range 0–9 | Input normalization |
| Numerical | Question with decimal answer; answer key is one exact value or one inclusive accepted range | No separate answer-unit field; both range endpoints are accepted; values/bounds stay within 0.00–999.00 with two decimal places; extra precision is flagged, not automatically rounded | Shorter-input formatting and detailed review-resolution UX; multiple ranges are not supported |
| List / match the column | Left/right lists with question-specific item counts; exactly four options containing matching combinations | Exactly one combination option is correct; each left item may match one or multiple right items, but a right item cannot be shared across different left items in the correct mapping | Labels and practical item-count limits; unused right items are permitted |
| Assertion–reason | Assertion and reason statements with exactly four question-specific response options | Exactly one option is correct; option text can vary by question rather than using a mandatory fixed template | Content examples and detailed semantic QC; do not impose an unapproved universal truth table |
| Passage-based | Shared passage/context and linked subquestions, each with its own permanent question code; mixed child types permitted | Each subquestion has its own question identity/version history and type rules; e.g. SCQ, numerical and integer may coexist | Exact allowed child-type catalogue, passage sharing/versioning and group editing |
| Multiple statement | Question-specific number of statements and exactly four response options about their correctness/combination | Exactly one option is correct; preserve each statement, option content and answer meaning; statement count is not fixed globally | Practical count limits, labeling and detailed content examples |

The user described two-statement content while discussing assertion/reason. Do not assume an additional tenth format until its difference from assertion–reason and multiple-statement is clarified.

## Important numeric boundaries

- Integer: `0` and `999` are in range; `-1`, `1000`, and fractional values are out of range.
- Single digit: `0` and `9` are in range; `-1`, `10`, and fractional values are out of range.
- Numerical: `0.00` and `999.00` are in range; negative values and values above `999.00` are out of range. The specified maximum is **999.00**, not 999.99.
- Two decimal places are a content requirement. Exact decimal representation should avoid floating-point ambiguity; final API/storage encoding and formatting rules require schema design.
- Do not infer numerical tolerance, range marking or partial-credit policy from decimal precision. Test scoring is deferred, while answer representation must remain precise now.

## Shared content requirements

All formats support the agreed source/provenance, language, taxonomy, difficulty, optional solution/video metadata and relevant equation/figure/table assets. Required fields at draft, review and publication must be reviewed separately. Manual and extracted content must use the same type-aware validation.

Store content with a schema version and explicit format discriminator. Preserve referenced passages/assets so that a published version cannot change indirectly. An unsupported parser layout must still yield a visible candidate/warning or actionable failure; supporting a format in manual entry does not prove reliable extraction of every layout.

## Worked examples needed before schema completion

For each format prepare a valid draft, complete publishable example and invalid-answer example. Include figure/equation variants, imported answer keys and source references. For matching, passage and statement formats, resolve the open structures first rather than creating misleading sample payloads.

## Relationship to delivery

All nine formats belong to the first question-bank release. Test assembly, scoring, paper layout and test-paper export remain later. Additional formats may be proposed, but none is added without recording the user's answer. This specification resolves format coverage, not every content-schema detail under D-07.

## Matching relationship rule — confirmed

The correct mapping may connect a left item to one or multiple right items, but each right item belongs to at most one left item. For example, A→P,R and B→Q is allowed; A→P and B→P cannot both be correct. This constrains the correct answer relationship, not the truth of distractor options; do not reject intentionally wrong choices merely because they depict an incorrect relationship. Right-column items may remain unused in the correct mapping and serve as distractors; the mapping need not cover the entire right list. Each left item still has one or more matches, and no right item is shared by different left items in the correct mapping. For example, left A,B,C and right P,Q,R,S,T may use A→P, B→Q, C→R with S,T unused. The four response options and exactly one correct combination remain required.

## Numerical precision handling — confirmed

If a numerical answer arrives with more than two decimal places, retain the original value and flag it for review. For example, 12.345 must not silently become 12.35. Do not invent a rounded answer key or discard the source candidate; store the precision issue and let authorized review resolve the final answer under the two-decimal constraint. This applies to numerical answer fields, not every number in a stem, equation or solution. Whole-job failure and any accepted-answer tolerance are not implied by the flag decision.

## Numerical exact value or accepted range — confirmed

A numerical question may specify one exact correct value or an accepted answer range (e.g. 9.79 to 9.81). Store exact and range modes distinctly; preserve the supplied endpoints rather than inventing a tolerance around an exact key. Both endpoints must follow the agreed 0.00–999.00 value domain and two-decimal precision, with lower bound not exceeding upper bound. Flag source precision problems rather than auto-rounding. User confirmed both endpoints are included: for 9.79–9.81, both 9.79 and 9.81 are accepted. Only one accepted range is supported per numerical question; multiple disjoint ranges are not allowed. The answer mode is either one exact value or one inclusive interval, not a list of alternatives. If imported or AI output supplies several ranges, preserve the source/output and flag it for authorized resolution; do not select one silently, combine intervals into a wider range, or discard the candidate. This defines answer storage now; student grading belongs to later scope.

## Optional solution at publication — confirmed

User-confirmed: a question may be published with a correct answer even if no solution/explanation is provided. Solution is optional, not a publication prerequisite. Type-valid answer, complete question content, applicable review/metadata checks and admin-defined publication permission remain required; this answer does not waive them. If a solution is supplied, preserve it as part of the version and apply relevant QC.

## PYQ exam and year required — confirmed

User-confirmed: if a question is marked as a previous-year examination question (PYQ), exam name and exam year are required before publication. Incomplete PYQ drafts may be saved but cannot publish without both fields. This conditional requirement does not force non-PYQ questions to carry exam/year values. Retain source provenance and do not fabricate missing exam/year to pass validation. Date, paper code, slot/shift and other PYQ metadata completeness remain separate decisions.

## Video solution link only — confirmed

User-confirmed: video solutions use a stored external video link; video-file upload/hosting is not required for the first release. Video solution metadata remains optional under the handover. Validate safe URL structure and preserve the link in version-scoped metadata; do not fabricate a video URL or claim external content is hosted/archived by this platform. Existing edit permissions and published-version rules apply to link changes. Link/player UI details remain design work; no streaming service or provider has been selected.

## Visual, LaTeX and MathML equation editing — confirmed

User-confirmed: manual equation entry/editing supports visual controls, LaTeX code and MathML code in the first release. Apply shared rich content to relevant stem/options/solution/passage/statements/matching fields, preserving original expression source, preview meaning, multilingual text and version history. Canonical storage, supported syntax/conversion and editor/renderer libraries remain design work; do not claim lossless interchange or silently discard unsupported markup. See [question content editor](QUESTION_CONTENT_EDITOR.md).

## One chapter and one topic per question — confirmed

User-confirmed: a question has only one chapter tag and one topic tag, not multiple chapters/topics. Required chapter/topic classification at publication means one valid selected value of each; incomplete drafts can still omit required values until ready. Preserve optional subtopic and the separately confirmed primary plus multiple secondary concept associations. Multiple concepts do not authorize hidden extra chapter/topic tags. Cross-branch concept association rules remain design work; do not silently remove the multiple-concept requirement.

## No separate numerical-answer unit field — confirmed

Numerical answers have no separate optional or required unit field. Store the agreed one exact decimal value or one inclusive range without adding an answer-unit attribute/control to the numerical format. Missing a separate unit must not block saving, review or publication.

This does not remove units from question text, equations, diagrams, original sources or supplied solutions; preserve their content and rendering. If extraction finds a source key such as “5.00 N”, retain that original evidence and context while resolving the numeric key under normal validation/QC. Do not discard the unit evidence, invent a unit field or silently convert/rescale values. Unit conversion or unit-aware student grading is not introduced by this decision; test/student delivery remains later scope.
