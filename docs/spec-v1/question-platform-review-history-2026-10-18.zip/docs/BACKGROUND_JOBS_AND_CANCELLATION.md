# Background Processing and Cancellation

Status: faculty cancellation of their own processing jobs and nonblocking background work confirmed on 17 October 2026. Already extracted questions are retained as drafts; exact cancellation boundaries and restart details remain design work. No worker/queue implementation exists.

## Confirmed behavior

- File-processing/extraction work runs asynchronously in the background.
- Faculty can upload more files while earlier jobs are running.
- Faculty can navigate/use other app workflows without waiting for extraction to finish.
- Faculty can cancel their own queued/running processing job through the app.
- Existing progress/errors, tenant isolation, source retention, retries and idempotency remain requirements.

## Proposed execution contract

Return a durable job reference/status after accepted upload rather than keeping the request/UI blocked for complete extraction. Store job/source/attempt state on the server; queue workers process stages independently of the current frontend screen. A jobs view/status API should let faculty revisit progress across navigation without duplicating processing.

Multiple submissions can be accepted and queued. This is not a promise of unlimited simultaneous execution: bound worker concurrency, file resources, provider rates and AI budget reservations. A busy worker must not force faculty to stop ordinary app work. Unknown progress totals must not be fabricated as precise percentages.

## Cancellation semantics to implement

Authorize cancellation against the actor's own job and organization, then record the request/state/audit. Cancellation is distinct from deleting original files, deleting questions or resetting a database; original deletion remains admin-only. Cooperatively stop future stages/AI dispatch and avoid retrying a cancelled task as normal pending work.

Exact behavior for active extraction or in-flight provider requests needs an explicit state/acknowledgment contract. Do not promise instant termination or a refund of an already dispatched provider call. Preserve recorded usage/provenance and report whether cancellation is requested or complete. Handle completion/cancellation races transactionally.

User-confirmed: retain already extracted unpublished candidates as drafts when the job is cancelled. Do not delete them, create duplicate replacement masters or demote already reviewed/published work. Preserve raw/source/progress/provenance and history. Unprocessed inputs remain identifiable as unprocessed; original-file retention/deletion remains governed separately. Whether a cancelled job can resume/restart and exact stage granularity remain design work.

## Acceptance direction

Verify an earlier background job does not block new uploads/navigation; status persists and each submission remains independently traceable. Verify own-job cancel works while another faculty/tenant's jobs cannot be cancelled using that permission, later stages do not restart, and race/replay handling preserves identity/audit. Add completed-output checks after the retention decision. These are planned tests, not executed results.
