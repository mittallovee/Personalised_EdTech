# Coaching-Owned AI Provider Credentials

Status: user selected coaching-owned API keys on 17 October 2026. Initial providers are Google, Anthropic, OpenAI and OpenRouter (confirmed 18 October 2026), with later provider extension. Exact model catalogue, secret-management implementation and key lifecycle details remain design work. No API keys have been requested, stored or tested.

## Confirmed direction

- Each coaching supplies its own AI provider API keys; platform-wide shared keys are not the selected credential model.
- Resolve credentials from the active coaching for every faculty/background AI operation.
- Never use another coaching's key or silently fall back to a shared platform key.
- Faculty retain default access to enabled AI tools; provider setup and supported-model capability remain prerequisites for actual provider calls, independently from per-user permission flags.
- Faculty-wise usage/budgets and the 80% warning/100% new-work stop remain application requirements.

## Proposed administration and storage

Use organization-admin configuration for provider credentials, connection state and rotation/revocation. Store secret material through an appropriately protected secret-management/encryption design; normal application records should reference credential identities/versions, not expose plaintext keys in question content, AI outputs, client bundles, logs or audit diffs. Exact secret manager and key validation/rotation UX are not selected.

Record which provider configuration/credential reference was used for an operation without recording the actual secret. Workers must resolve that reference under the correct tenant context. A stale, revoked or invalid key produces an actionable provider/configuration failure rather than a cross-tenant fallback.

## Catalogue and setup behavior

The platform still has a fixed supported/tested model catalogue and sensible defaults. Coaching credentials do not authorize arbitrary providers/models or grant code execution. Initial provider families are confirmed; exact API/model catalogue and fallback order/attempt limits need design. Coaching-admin enabled/default controls and automatic fallback with a visible error are confirmed. A missing key must be shown honestly; non-AI work remains available, and AI-dependent stages must not pretend success.

## Costs and billing evidence

Provider charges attach to the account associated with the coaching's key. The application's faculty usage/cost reporting covers its recorded calls. It must not claim to capture unrelated usage of that provider account or enforce a provider-wide billing cap. Distinguish provider-reported actual cost, calculated estimates and unknown values; concurrent reservations and late reported charges still need implementation design.

## Acceptance direction

Verify organization A calls use only A credentials and organization B only B, including queued tasks, retries and connection reuse. Verify keys are absent from ordinary faculty responses/logs, credential changes are audited safely, invalid/missing/revoked configuration fails clearly, and no hidden platform/shared credential fallback occurs. No provider or security checks have been run.

## Coaching-admin enabled models and default — confirmed

User-confirmed: each coaching admin can enable/select which models from the platform-supported catalogue are available in that coaching and set its default model. Faculty choose from that coaching's enabled, supported, operation-compatible models; default is available for quick use. Resolve only that coaching's provider keys. Tenant configuration cannot introduce arbitrary untested models or bypass capabilities/resource budgets. Automatic fallback with a visible error is confirmed; per-operation default details, fallback order/attempt limits, catalogue updates and UI remain design work.

## Automatic model fallback with visible error — confirmed

User-confirmed: when the selected AI model fails, show a safe, understandable error/failure status and automatically try another enabled, operation-compatible model for the same coaching. Record original selection, failure, fallback attempt and actual model/provider used; do not hide the failure because fallback succeeds. Use only that coaching's configured credentials. Respect supported capabilities, bounded retry/fallback policy and budget reservations; never bypass missing authorization, tenant checks or the 100% budget stop. Preserve successful partial outputs and idempotency. If alternatives fail/unavailable, show an actionable terminal error without fabricating output. Exact fallback order, attempt limits and detailed UI remain design work.

## Platform full administration — confirmed update

Platform admin may administer provider credentials, enabled/default models and budgets for every coaching and run supported AI/job operations in an explicit coaching context. This is full application authority, not shared credential ownership: selected coaching operations still use that coaching's credentials and effective saved budget with attribution/audit, no cross-coaching fallback. Protected secret storage/display and safe logs remain. See [platform access](PLATFORM_ADMIN_ACCESS.md).

## Destination keys after dataset copy - confirmed

A platform-admin independent dataset copy includes educational content/patterns, not source provider API keys. Configure destination credentials separately and resolve only its own keys for future extraction, fallback and AI operations. Missing keys show the ordinary configuration issue without using source/shared credentials; copied content remains available for non-AI work. Source AI evidence is provenance, not a new destination charge. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).


## Initial AI provider scope - confirmed 18 October 2026

User-confirmed (18 October 2026): first-release AI provider support includes Google, Anthropic, OpenAI and OpenRouter, with an extensible adapter/catalogue design for adding more providers later. Each coaching configures its own credentials; existing enabled-model/default selection, compatible automatic fallback with visible failure, usage provenance and budget controls continue. Provider selection does not mean credentials are available or integrations tested. Specific API products, model identifiers, operation capabilities, data handling, prices and routing/attribution details require current official-source verification during design. Adding a provider later requires an implemented and validated adapter/catalogue entry; it is not arbitrary endpoint execution.
