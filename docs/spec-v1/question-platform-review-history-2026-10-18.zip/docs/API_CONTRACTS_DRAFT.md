# API Contracts — Design Draft

Status: proposed contract outline, not implemented or approved final OpenAPI. Exact routes may change during design review. No production provider/model/API claims are made here.

## Cross-cutting contract

- Proposed prefix: `/api/v1`.
- Authentication and session transport depend on D-02. Public liveness may be minimal; readiness must not expose credentials or detailed infrastructure data.
- Business requests identify an active organization through a reviewed route/header/session mechanism; the server verifies membership before establishing tenant context. Tenant identity from the body is never trusted by itself.
- Distinct opaque master/version/job identities; human question codes are additional lookup keys with scope under D-06.
- Proposed timestamps: timezone-aware UTC for storage/transport, converted in UI. Exact serialization will be specified with schemas.
- Proposed errors: stable machine-readable category, safe human message, optional field errors and correlation reference. Never include stack traces or storage secrets.
- Authorization and existence responses should avoid leaking another tenant's resources. Exact forbidden/not-found behavior is a security review item.
- List endpoints need bounded pagination, stable ordering, explicit allowed filters and tenant-specific counts. Pagination style and limits remain open.
- Idempotency behavior must cover replay with the same payload and conflict on the same key with a different payload. Scope/TTL are D-12.
- Stale edits/transitions need optimistic concurrency or equivalent protection; mechanism is D-08.

## Proposed resource surface

| Resource/action | Proposed method and path | Preconditions / response behavior |
| --- | --- | --- |
| Liveness | `GET /health` | Minimal process status; no business data |
| Readiness | `GET /ready` | Dependency readiness; safe output; access policy reviewed |
| Faculty organization | `GET /api/v1/me/organization` | Authenticated faculty; its single active coaching membership only, with no organization-switch entitlement |
| Upload/job creation | `POST /api/v1/ingestion-jobs` | Authorized, supported file, resource limits and idempotency policy; async acceptance with job/source references |
| List/job detail | `GET /api/v1/ingestion-jobs` and `GET /api/v1/ingestion-jobs/{job_id}` | Tenant-scoped status, stage, counts, warnings and safe error summary |
| Retry job | `POST /api/v1/ingestion-jobs/{job_id}/retry` | Retry capability and retryable state; explicit attempt reference, no duplicate master creation |
| Candidate list/detail | `GET /api/v1/candidates` and `GET /api/v1/candidates/{candidate_id}` | Tenant-safe source references and processing/review state |
| Manual candidate | `POST /api/v1/candidates` | Origin manual; shared content validation; draft acceptance rules |
| Correct candidate | `PATCH /api/v1/candidates/{candidate_id}` | Editable state, capability and concurrency guard; preserves provenance |
| Submit/review candidate | Explicit action routes, final names open | Validated transition and actor/decision/reason record |
| Question search | `GET /api/v1/questions` | Filters, counts, pagination and eligibility aligned |
| Question/version detail | `GET /api/v1/questions/{question_id}` and version detail | Exact version available subject to authorization and retention |
| Create correction/version | `POST /api/v1/questions/{question_id}/versions` | Prior version/source reference, change reason, actor; lock prior publication |
| Publish version | `POST /api/v1/question-versions/{version_id}/publish` | Required QC/approval, explicit permission, concurrency guard and audit |
| Relationship proposal/confirmation | Relationship resources, exact routes open | Type and endpoints valid within one tenant; human confirmation where required |
| AI catalogue | `GET /api/v1/ai/models` | Enabled permitted models/capabilities and defaults; no provider credentials |
| AI operation | `POST /api/v1/ai/runs` | Allowed operation/model, budget/rate controls; result/provenance or async status |
| Test creation/versioning | Test resources, exact routes open | Specific eligible question versions, duplicate policy and criteria snapshot |

Cancellation, taxonomy administration, exports, audit queries and membership administration need explicit contracts after their policies are resolved. Routes in this draft are not a promise to expose all features in the first slice.

## Minimum schema content

**Ingestion job:** identity, organization, requester, state, current stage, stage progress, candidate/file counts, attempt count, created/updated/completed timestamps, safe warnings/errors and source-file references. Numerical progress must state its denominator; unknown total must not pretend to be a percentage.

**Candidate:** identity, origin, source location(s), raw extraction reference, proposed structured content, parser/schema version, warnings/confidence, processing state, review state and attribution. Manual input has no invented source-page reference.

**Question master:** UUID, organization, permanent code, lifecycle reference, attribution/timestamps. **Version:** its own identity/number, master reference, schema-versioned content, metadata snapshot, source/provenance, workflow/publication fields and predecessor relation.

**Structured content:** type discriminator, stem, language, optional assets, type-specific answer/option fields, solution and passage references where relevant. Rich-text/equation format, scoring semantics and sample payloads cannot be finalized until D-07.

## Contract examples needed before related implementation

For each initial question format, provide a valid draft, valid publication payload and invalid answer example. For jobs, provide accepted, processing, partial failure, final failure and retry responses. For access control, document missing auth, missing membership, missing tenant and forbidden cross-tenant references. Examples must follow finalized schemas rather than inventing a conflicting second schema.

## Confirmed scope and permissions

First-release contracts cover question entry/ingestion, review and database storage, all nine formats, image inputs and AI-driven taxonomy/tagging. Test creation/export is deferred. Admin defines approval/publication grants independently; creation/upload alone grants neither. Taxonomy discovery/activation, AI notifications and admin correction need contracts after the activation policy is decided.

## Translation eligibility — confirmed

Faculty-requested translation is allowed only after source-question review completes. Enforce this in API/service state checks, not only a UI button. Preserve the reviewed source-version reference. Exact review-completion state and translated-output review/publication details remain open; do not infer that source publication is mandatory.

## Translated question identity — confirmed

A translated question has a distinct master/new permanent question code and its own version history. Store explicit translation-of and reviewed source-version provenance; enforce same-organization relationships. Correction of a published translation creates another version under that translation's stable code. Retry/replay must not create duplicate masters/codes. Original source content/code remain unchanged.

## Passage child identities — confirmed

Passage subquestions have distinct permanent question codes/master identities and link to shared passage context. Contracts must preserve child type/answer rules and historical passage content. Context identity/version schema and group-edit behavior remain to be specified.

## Variant count, target type and difficulty — confirmed

User-confirmed: faculty chooses variant count, can change the target question type, and needs target difficulty selection (1–10). Preserve these controls in the generation plan and AI provenance. Validate output against the target format and reassess answer/options/concepts/difficulty rather than copying source fields. A target setting is not proof of achieved difficulty. Source review completion remains unnecessary. Mixed-target batches are confirmed; practical limits/defaults and operation permissions still need design.

## Mixed-target variant requests — confirmed, 17 October 2026

User-confirmed: one faculty request may generate a mixture of question types and target difficulty levels. The accepted example is two SCQ variants at difficulty 4 plus one numerical at difficulty 7. Store each group/item target and requested count, derive a consistent total and bind output provenance to its requested plan. Validate each output against its own target format. Partial failures must identify affected plan entries rather than silently substituting another type/difficulty or duplicating successful outputs.

## Additional faculty instructions for variants — confirmed, 17 October 2026

User-confirmed: faculty may enter additional instructions for AI variant generation, such as changing only numerical values or reducing calculation. Keep them with the requested count/type/difficulty plan and AI provenance. Interpret them within the confirmed same-primary-concept and target-format requirements; surface conflicts instead of silently changing requested targets. Instructions do not grant permissions, cross tenant boundaries or bypass QC/publication checks. Exact shared/per-item instruction controls and length limits remain design details.

## Faculty sees the complete coaching question bank — confirmed

User-confirmed: faculty can view the complete question bank of their own coaching organization, not only questions they created or uploaded. Do not apply a creator-only filter to ordinary faculty question-bank visibility. Organization ownership, single-coaching account scope and cross-tenant denial remain unchanged. Viewing the full bank does not itself grant editing, approval/publication, original-file deletion or storage-dashboard rights. Detailed staging/review-state access and edit permissions remain separate policy questions.

## Shared pending-review access — confirmed

User-confirmed: any faculty member with review/QC permission may review pending questions in their own coaching. Mandatory per-question reviewer assignment is not required. Present a shared pending-review queue scoped to that organization and enforce the independent review grant. Preserve revision-bound decisions, actor/history and correction-return/resubmission. Concurrent decisions need transactional conflict handling rather than silently overwriting each other. Optional assignment is not a required feature by this answer; default faculty without the review grant cannot complete formal QC.

## Bulk mixed-source upload — confirmed

User-confirmed: first release supports bulk upload of multiple PDF, Word and image files in one submission. Preserve per-file validation, source identity/checksum, tenant scope and observable progress/errors; existing 50 MB/document and 10 MB/image limits remain per file. Bulk upload does not bypass staging/QC or imply automatic publication. Exact maximum file count, aggregate bytes, resumable transport and handling of separate paper/answer-key associations remain design work.

## Link separate paper, answer key and solution sources — confirmed

User-confirmed: question papers and their answer keys/solutions may be separate files and must be linkable for joint processing in the first release. Preserve group identity and independent question/answer/solution source locations; candidates may reference multiple files. Ambiguous/missing/conflicting matches remain reviewable, not fabricated or silently dropped. Manual versus AI pairing and detailed matching policy remain open. See [linked multi-file ingestion](MULTI_FILE_INGESTION.md).

## AI file pairing with faculty correction — confirmed

User-confirmed: AI identifies and directly links related paper/key/solution files; faculty may correct the pairing afterward. Do not require manual group selection or confirmation before AI pairing runs. Retain model/matching/source provenance, distinguish file grouping from answer alignment and re-evaluate affected candidate associations when pairing is corrected. Ambiguities remain visible for review; protected question edits and published history still follow existing permissions/version rules.

## Faculty-requested solving of missing answers — confirmed

User-confirmed: when an imported question has no answer, faculty can request AI to solve it and fill the answer. On-demand only; no automatic solving for every upload. Preserve model/prompt/source-revision provenance and distinguish AI output from an extracted key. Validate answer format and retain normal QC; generation alone grants neither verified status nor publication. Solutions remain optional. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Faculty-wise AI usage/cost for admin — confirmed

User-confirmed: admin needs faculty-wise AI usage and cost reporting. Record tenant, faculty/requester, operation, model/provider and available usage/cost evidence. Separate provider-reported actual cost, calculated estimates and unavailable values; do not show unknown as zero. Dashboard visibility does not itself define budgets or per-user feature gates. See [AI usage/cost dashboard](AI_USAGE_AND_COST.md).

## Monthly per-faculty AI budgets — confirmed

User-confirmed: admin can configure a monthly AI spending limit for each faculty member. Keep tenant/faculty attribution, budget amount/currency/period and auditable admin changes. This is spending control, not a reversal of default faculty AI tool access. Whether exceeding the limit only warns or blocks new AI work, exact monthly reset semantics, concurrency reservations and cost-reconciliation policy remain open; do not assume a numerical default or threshold behavior.

## Budget thresholds — 80% warning, 100% stop

User-confirmed: issue a warning when a faculty member reaches 80% of their configured monthly AI budget, and stop new AI work at 100%. Enforce the stop at provider dispatch/service boundaries, not only a disabled UI button. Preserve completed results, saved questions and non-AI work. Do not assume in-flight requests are cancelled or final provider bills can never exceed a cap when usage arrives late; define reservation, reconciliation and in-flight handling explicitly. Warning delivery/deduplication and exact monthly reset semantics remain design work.

## Calendar-month usage reset — confirmed

User-confirmed: monthly budget usage starts afresh on the first day of every calendar month. Preserve prior-month usage/cost and audit history; reset the current-period counter, not historical records. Apply the configured faculty limit to the new period. This is not a rolling 30-day window. Exact organization timezone, in-flight request attribution at month boundaries and cost-reconciliation rules remain implementation design work.

## Coaching-admin enabled models and default — confirmed

User-confirmed: each coaching admin can enable/select which models from the platform-supported catalogue are available in that coaching and set its default model. Faculty choose from that coaching's enabled, supported, operation-compatible models; default is available for quick use. Resolve only that coaching's provider keys. Tenant configuration cannot introduce arbitrary untested models or bypass capabilities/resource budgets. Automatic fallback with a visible error is confirmed; per-operation default details, fallback order/attempt limits, catalogue updates and UI remain design work.

## Automatic model fallback with visible error — confirmed

User-confirmed: when the selected AI model fails, show a safe, understandable error/failure status and automatically try another enabled, operation-compatible model for the same coaching. Record original selection, failure, fallback attempt and actual model/provider used; do not hide the failure because fallback succeeds. Use only that coaching's configured credentials. Respect supported capabilities, bounded retry/fallback policy and budget reservations; never bypass missing authorization, tenant checks or the 100% budget stop. Preserve successful partial outputs and idempotency. If alternatives fail/unavailable, show an actionable terminal error without fabricating output. Exact fallback order, attempt limits and detailed UI remain design work.

## Automatic own-coaching duplicate checks — confirmed

User-confirmed: every new question is automatically checked against its own coaching's existing question bank for duplicates. Shared downstream rules cover manual/import/generated candidates. Preserve tenant-safe candidate evidence and sources; human QC confirms duplicate/variant/translation disposition before canonical/merge decisions. Do not silently reject/delete uncertain candidates or collapse distinct variants/translations. Exact matching policy/thresholds and final confirmed-duplicate treatment remain open. See [duplicate policy](DUPLICATE_AND_VARIANT_POLICY.md).

## Exact duplicate attaches source without new code — confirmed

User-confirmed: after human review confirms an intake candidate is exactly an existing question, link the new source/provenance to the existing question instead of creating a new master/code. Keep the existing permanent code and matching-version evidence; preserve source/candidate records and review audit. Appending source evidence must not silently overwrite content, answer, solution or published metadata. Conflicting keys or non-identical content require visible review rather than forced duplicate treatment. Existing published duplicate masters/canonical merge policy remains separate; variants/translations retain their confirmed distinct codes.

## Legacy DOC and DOCX inputs — confirmed

User-confirmed: first release supports both legacy .doc and modern .docx Word inputs. Apply the accepted 50 MB/document per-file limit and shared bulk/staging workflow. Keep uploaded original bytes; any conversion/extraction artifact needs source/tool/version provenance and visible warnings. Choose and verify an appropriate legacy parser/converter rather than assuming the proposed DOCX extractor covers legacy files. Preserve equations, tables, figures and source anchors where possible; uncertain/lost structure must remain visible for correction. No converter has been selected, installed or tested.

## Background jobs, concurrent app use and own-job cancel — confirmed

User-confirmed: faculty may cancel their own running file-processing job. Jobs run in the background; faculty can upload new files and perform other app work while earlier processing continues. Use durable independently traceable job/stage state with resource/budget limits, not a blocking UI request. Cancellation is not source deletion or silent removal of published/reviewed content. Partial-output retention, in-flight acknowledgement and completion races need detailed semantics. See [background jobs/cancellation](BACKGROUND_JOBS_AND_CANCELLATION.md).

## Cancelled jobs retain extracted drafts — confirmed

User-confirmed: cancelling a processing job keeps questions already extracted as draft work. Preserve source/candidate identity, progress, warnings and audit; do not discard completed output or alter already reviewed/published states. Cancellation stops further work according to the acknowledged stage contract, not deletion of originals or saved questions. Retry/resume behavior must not duplicate retained candidates/masters; exact cancelled-job restart UX remains open.

## Admin and creator question archival — confirmed

User-confirmed: archive removes a question from the active bank while retaining content/history. Admin may archive questions in their own coaching, and creator faculty may archive their own question. Complete-bank view or cross-author edit permission alone does not grant archive authority over other creators' questions. Preserve code, immutable published versions, assets, sources/audit and historical references; archival is not physical deletion or admin-only original-file deletion. Restore behavior remains open. See [question archival](QUESTION_ARCHIVAL.md).

## Admin and creator may restore archived questions — confirmed

User-confirmed: both admin and creator may restore archived questions. Admin acts within their coaching; creator acts on their own question. Keep the existing code, content/versions/provenance and archive/restore audit. Restoring availability is not automatic approval/publication of an unreviewed draft or authority to overwrite published content. Detailed state/eligibility and concurrency handling remain design work.

## Video solution link only — confirmed

User-confirmed: video solutions use a stored external video link; video-file upload/hosting is not required for the first release. Video solution metadata remains optional under the handover. Validate safe URL structure and preserve the link in version-scoped metadata; do not fabricate a video URL or claim external content is hosted/archived by this platform. Existing edit permissions and published-version rules apply to link changes. Link/player UI details remain design work; no streaming service or provider has been selected.

## Visual, LaTeX and MathML equation editing — confirmed

User-confirmed: manual equation entry/editing supports visual controls, LaTeX code and MathML code in the first release. Apply shared rich content to relevant stem/options/solution/passage/statements/matching fields, preserving original expression source, preview meaning, multilingual text and version history. Canonical storage, supported syntax/conversion and editor/renderer libraries remain design work; do not claim lossless interchange or silently discard unsupported markup. See [question content editor](QUESTION_CONTENT_EDITOR.md).

## One chapter and one topic per question — confirmed

User-confirmed: a question has only one chapter tag and one topic tag, not multiple chapters/topics. Required chapter/topic classification at publication means one valid selected value of each; incomplete drafts can still omit required values until ready. Preserve optional subtopic and the separately confirmed primary plus multiple secondary concept associations. Multiple concepts do not authorize hidden extra chapter/topic tags. Cross-branch concept association rules remain design work; do not silently remove the multiple-concept requirement.

## Faculty-requested AI correctness checking — confirmed

User-confirmed: the first release includes faculty-requested AI checking of an existing answer and available solution. Keep reviewable findings, reasons/uncertainty and exact input-revision/model provenance; answer-only questions remain eligible because solutions are optional. Checking does not silently replace content or grant QC, approval, publication or an AI-verified badge. Use the existing tenant credentials, enabled-model, budget and background-job policies. Flagging, correction suggestions and explicit opt-in direct correction with visible before/after changes are confirmed; verification-badge criteria remain design/review work. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Opt-in AI corrections with visible changes — confirmed

AI must flag suspected errors and show corrected answer/solution suggestions. Faculty may opt in to direct application, and the interface must still show the old/new values and reason. Without opt-in, the operation leaves existing answers/solutions unchanged. Enforce current same-tenant edit permissions and revision conflict/type-validation checks on actual writes, including background completion; never silently overwrite a concurrent edit. Keep source values and actor/model/input/application provenance. Correcting published content creates an editable new version under the same master/code, retaining the existing published snapshot and normal revision-bound QC/approval/publication controls. Direct-correction opt-in applies to one question at a time, selected separately for that question; no batch-wide or carried-over opt-in. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Matching permits unused right items — confirmed

Match the Column allows right-column items that are unused in the correct answer and serve as distractors. Validation must not require every right item to be selected. Keep one-or-more matches per left item, no right-item sharing across different left items in the correct mapping, variable column counts and four combination options with exactly one correct. Preserve unused item content in storage, extraction, editing and rendering. Example: A→P, B→Q, C→R with right-side S,T unused is valid. See [question types](QUESTION_TYPES_SPECIFICATION.md).

## First-release AI prerequisite relationships — confirmed

AI creates concept-to-concept prerequisite links in release one: which concept should be understood before another. Keep directed stable concept IDs, same-coaching/same-subject endpoints, relationship provenance and graph change history, separate from question tags and taxonomy hierarchy. Cross-subject prerequisite links are not allowed, including AI creation and admin corrections. Cross-class links within the same subject/coaching are allowed, including Class 11 prerequisite → Class 12 dependent; different classes alone must not block such links. Personalized student suggestions/mastery analytics remain later. AI links are immediately usable with AI-added/admin-review-pending status and admin notification; admin can later approve, correct or revoke them. Detailed cycle disposition and educational validation remain design work. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Faculty knowledge graph navigation in release one — confirmed

Faculty can view their coaching's knowledge tree as a graph and click a concept to open linked questions. Query by stable concept ID against primary/secondary question assignments, preserving existing bank access and tenant scope for graph nodes, edges, counts and question navigation. Viewing grants no graph-write, question-edit or QC/approve/publish authority. Show provisional AI/admin-review-pending status and current active links accurately. This is faculty bank navigation; student recommendations/mastery analytics remain later. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Prerequisite subject validation — confirmed constraint

Before creating/activating/correcting a prerequisite link, validate same coaching and same stable subject context for both endpoints. Reject a cross-subject write with a clear validation outcome; AI background completion follows the same rule as admin writes. Unknown or ambiguous subject association cannot silently pass. Do not return invalid cross-subject edges through graph queries. Cross-class links within the same subject/coaching are allowed; do not require equal endpoint class IDs. Broader cross-chapter details remain separate review work.

## Numerical answer cardinality — confirmed

A numerical question supports one exact answer value or one inclusive accepted range, not multiple separate ranges. There is no separate numerical-answer unit field or unit-field publication requirement; preserve units in original evidence, question/equation/solution content without silently converting numeric values. Keep the 0.00–999.00 domain, two-decimal precision, ordered inclusive endpoints and existing precision-flag policy. Imported/AI multi-range evidence must remain visible for authorized correction; do not silently select one interval or bridge the gap by widening it. Incomplete/flagged drafts remain recoverable, but an invalid multi-range key cannot pass type validation for publication. Concrete storage/API representation remains schema design. See [question formats](QUESTION_TYPES_SPECIFICATION.md).

## Concept creation authority — confirmed

Only admin and the authorized AI taxonomy workflow can add new concepts. Faculty cannot manually create concept identities, including through question-tag inputs; they may select existing concepts and correct question assignments within existing edit permissions. AI may add missing concepts during faculty processing under the immediate provisional/admin-notification policy. Enforce trusted actor/tenant checks in the API/service/worker, not a user-supplied AI flag; retain initiating user and actual AI/admin creation provenance. Creation of class, subject, chapter, topic and subtopic entries is also restricted to admin and the authorized AI taxonomy workflow; faculty selects existing entries and cannot create them through free-text tagging or a direct API call. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Multiple admins per coaching — confirmed

A coaching organization may have more than one admin. Represent administration through individual authenticated identities and organization-scoped memberships/authority; do not impose a one-admin-per-organization constraint or require a shared login. Attribute every administrative action to the actual actor and preserve organization ownership of questions and audit history.

Multiple admins do not imply access to other coaching organizations. Each coaching has a principal Owner/Admin who can appoint and remove its other admins. Ordinary admin status does not itself grant admin-appointment/removal authority. The current Owner may transfer principal ownership to another admin in the same coaching. After transfer, the former Owner remains a regular admin in that coaching and loses principal-owner authority. When removing another admin, Owner chooses either conversion to normal faculty or removal from the coaching app with no remaining coaching access. Platform admin creates the coaching and first Owner; onboarding delivery/identity mechanics, owner recovery and exact transfer/removal mechanics remain design work. Existing independent question QC/approve/publish grants and admin-only catalogue/storage/AI configuration policies remain; do not infer that the numeric admin count changes their semantics.

## Coaching admin appointment/removal — authority contract

Principal Owner/Admin may appoint/remove other admins in their coaching. Enforce active principal-owner membership, same-organization target and current role revision at the service/transaction boundary; ordinary admin or faculty cannot claim this capability by submitting a role value. Record role-change evidence and enforce current authority on later admin operations. Principal-owner transfer is a separate owner-initiated operation to another active same-coaching admin; recovery and exact transfer mechanics remain design work. Owner must explicitly select normal-faculty conversion or coaching-app removal; do not infer residual faculty access for the removal choice. Exact routes, invitation acceptance and session/job revocation mechanics remain design work.

## Owner transfer — confirmed capability and draft invariants

Current principal Owner/Admin may transfer the principal role to a different active admin in the same coaching. At commit, check current owner/membership, target admin eligibility, organization and role revision. Use an atomic handover with one resulting principal owner, auditable old/new identities and safe conflict/replay handling; on failure preserve existing ownership. This changes application authority only, not question/source ownership or historical attribution. The former Owner retains regular admin membership and loses owner-only authority in the same handover; detailed acceptance/reauthentication flow remains under review; no route has been implemented.

## Admin-removal disposition — confirmed contract requirement

Owner-only admin management must distinguish `convert_to_faculty` from `remove_from_app` (names illustrative). The first removes admin authority while preserving normal faculty membership; the second removes coaching app membership/access. Validate current Owner, same-coaching non-owner target and current role revision at commit. Do not infer a default outcome or accept a requester's desired role as authority. Preserve organization data and audit/attribution. New requests and protected background effects must use current access; session, in-flight job, asset-link revocation and identity-cleanup mechanics remain implementation design.

## All admins may remove ordinary faculty — confirmed

Any active coaching admin (including Owner) may remove an ordinary faculty member from that same coaching's app, revoking coaching access while preserving organization questions/assets, attribution, usage and audit history. Check actor and target current membership/role at commit. Ordinary admins cannot use this action on another admin or Owner; admin demotion/removal remains Owner-only. Session/job/asset-access revocation and identity-cleanup mechanics remain design work. See [identity and access](IDENTITY_AND_ACCESS.md).

## Platform-admin onboarding of coaching and first Owner — confirmed

Platform admin creates each coaching organization and its first principal Owner/Admin. Coaching public self-signup is not available. Coaching Owner/admin and faculty membership do not confer platform-level onboarding authority, and a normal Google/password/OTP login cannot self-assign it. After onboarding, the coaching's Owner controls its other admins under the confirmed policy.

Design direction: keep platform authority separate from tenant membership, validate the intended first-owner identity and record platform actor, organization, owner and outcome. Provision the organization/initial-owner relationship consistently, with safe partial-failure/retry handling and no duplicate organizations or extra principal owners from replay. Invitation delivery/acceptance, verified identity linking and initial platform-admin provisioning remain implementation design.

Platform admin now has full cross-coaching application authority, including all question and tenant-administration capabilities, as defined in [platform access](PLATFORM_ADMIN_ACCESS.md). Earlier limited onboarding/read scope is superseded; preserve workflow, version, tenant-reference, secret-handling and audit rules. No organization or real account has been created.

## Explicit platform question-bank read scope — confirmed

Platform admin can view all coaching question banks using explicit platform-read authorization. Ordinary coaching users retain own-coaching isolation; show coaching ownership/context and audit platform reads. Server-side API/RLS/storage/cache rules must distinguish authorized question reads (including retained content assets needed to display them) from unrestricted tenant-data access. No owner/migration-credential or global RLS bypass is implied. The later full-access decision includes originals/storage, credential administration, edits/QC/approve/publish and supported AI/other application actions; this read-path description is not a limit on the platform role. See [identity and access](IDENTITY_AND_ACCESS.md).

## Explicit platform question editing — confirmed

Platform admin may edit questions in all coaching organizations through explicit platform-edit authorization and target-coaching context. Enforce type/content validation, current revision and tenant-consistent references, and record platform actor plus before/after evidence without transferring coaching ownership/creator attribution. Published corrections create an editable new version under the same master/code; preserve the existing published version and revision-bound QC/approval rules. The later full-access decision also grants QC/approve/publish, supported archive/delete, original-source/credential administration and supported AI/other app actions; the edit-path description is not a limit on platform authority. Use a reviewed restricted API/RLS write policy rather than unrestricted database bypass. See [identity and access](IDENTITY_AND_ACCESS.md).

## Current platform authority — full access

Platform admin has full application access across all coachings, including question QC/approve/publish, originals/storage, users/Owners/roles, taxonomy, AI credentials/configuration/budgets/jobs and analytics. Earlier limited platform read/edit exclusions are superseded. Coaching roles retain their own-coaching boundaries. Validation, published-version preservation, current authority checks, coaching data ownership, secret handling and audit remain required. Full authority covers supported features and does not move deferred test/student features into release one. See [the platform access specification](PLATFORM_ADMIN_ACCESS.md).

## Coaching name and logo in the app — confirmed

Each coaching may display its own name and logo in the application. Include per-coaching branding in the first-release tenant configuration and show it consistently in that coaching's app context. This is display branding, separate from internal organization identity, question ownership and the globally unique question-code scheme. Renaming or replacing a logo does not move data, change question codes or rewrite historical attribution.

Design direction: store a display name and a coaching-owned logo asset reference; validate name/content and image assets through the supported upload/rendering policy. Avoid cross-coaching asset links or cached branding leakage. A missing/unavailable logo should have a clear usable fallback, not prevent question-bank work. Use accessible labeling and preserve the selected coaching context in platform-admin views.

Only platform admin may create/change coaching display name/logo settings. Coaching Owner/admin/faculty cannot change these branding settings; there is no tenant-side branding edit grant. Exact image formats/dimensions/limits, settings UI and public/pre-login placement remain implementation design. Custom domains, color themes, hiding platform identity and later export branding are not established by this name/logo confirmation. No app UI or logo asset has been created.

## Branding write authority — confirmed, 18 October 2026

Only current platform admin may update a coaching display name or logo. Deny coaching Owner/admin/faculty writes to these fields through both dedicated branding operations and generic organization-profile updates. Logo replacement/asset mutation must enforce the same authority; editing a question or uploading a source image is not a branding-write grant. Preserve stable organization identity and record platform actor, coaching and before/after branding references. Exact routes and logo processing remain design work.

## One shared app website/link for all coachings — confirmed

All coaching organizations use the same app website/entry link. Do not require a separate domain, subdomain or coaching-specific entry link for each organization in the first release. Ordinary question/detail links may still exist within the shared application; this decision is about a common entry point, not eliminating resource routes.

After sign-in, resolve a coaching user's organization and branding from their trusted identity/membership. Faculty remains bound to one coaching with no cross-coaching switcher. Never use the shared URL or a client-supplied tenant value as business-access authority. Platform admin may select an explicit coaching context under the full platform role, retaining actor/target audit.

Use tenant-safe API, private-asset, session and cache context so the shared entry cannot mix coaching names/logos, questions or sources. Platform admin alone changes coaching branding. Missing/unavailable logo behavior remains usable; exact anonymous/pre-login branding and routes are UI design. The chosen common domain, hosting, physical database/deployment arrangement and commercial billing remain separate decisions. Shared website does not weaken data ownership/isolation or create public coaching signup. No website or domain has been created.

## Coaching subscription/payment collection — later phase

Coaching subscription and payment collection are explicitly deferred beyond the first release. Initial coaching onboarding and question-bank workflows do not depend on creating a subscription, plan or payment record. Future pricing, commercial plans, invoicing, payment gateway, renewal/expiry and subscription enforcement need their own approved specification before implementation; this is not a commitment to permanent free access.

First-release AI usage/cost reporting, coaching-owned provider credentials and monthly faculty spending controls remain required. Provider charges associated with a coaching's own API keys and application AI-budget accounting are separate from the platform collecting subscription payments. Keep 80% warning/100% new-AI-work stop and monthly reset/history under the existing policy. No payment system, plan or billing integration has been created.

## Adaptive extraction contracts and later teaching

Background ingestion learns unknown layouts and saves/uses compatible versioned patterns automatically. Results/status need pattern/version, bootstrap/reuse/fallback mode, coverage/warnings and model/token/cost/timing evidence. Validate schemas and preserve replay safety, source identity, tenant/QC/publication controls. Never fill a new file with prior answers. Patterns are coaching-specific; platform admin may share the complete dataset with another coaching. Sharing is an independent initial copy without synchronization; thresholds/import state/conflict/UI details remain open. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md).

Course/live/recorded and personalized teaching/concept-video APIs are later work; enrollment, learner context, media states, permissions and costs need separate contracts. No media route/provider is ready to implement. See [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).

## Coaching-specific patterns and platform dataset sharing - confirmed

Each coaching keeps its data/pattern library separate. Platform admin may explicitly share the complete dataset, patterns and associated material with another coaching. Ordinary coaching roles cannot initiate cross-coaching sharing. Preserve an explicit source/target manifest, complete dependency mapping, question-code/version integrity and platform actor history. Sharing creates a one-time independent initial copy with no ongoing updates in either direction; destination may use/change its own copy. Preserve mapped independent identities/new globally unique codes for new question masters and source provenance. Destination users and API keys are set up separately, not copied; keep source actor/model evidence as provenance, not active memberships/secrets. Source-published questions retain published status without mandatory local re-review on copy; preserve imported QC evidence and immutable snapshots, with later edits using normal new-version review. Destination conflict/failure and operational-reference details remain design work. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## Dataset-copy exclusion contract - confirmed

The copy manifest includes educational questions/source/assets/taxonomy/patterns. Exclude source login/session/active membership grants and provider secrets; destination users/keys use its own onboarding/configuration. Source actor/model/cost references are imported evidence, never destination authority, new charges or dispatched jobs. Preserve existing destination Owner/branding and resolve only destination keys for future AI. Imported publication-state and nonempty-target conflict policy remain open. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## Published status in independent coaching copies - confirmed

When platform admin copies an existing coaching dataset, source-published question snapshots remain published in the destination without mandatory re-review merely for copying. Preserve source QC/publication provenance, the platform copy actor and exact version/dependency mapping; do not invent destination reviewer identities. New destination question masters still receive new globally unique codes. Validate complete snapshot/reference integrity; do not promote source drafts/unreviewed content. Later destination edits create a new editable version under the destination code and follow normal QC/approval/publication; copied published snapshots stay immutable. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## AI taxonomy notification contract - in-app only

New AI concept/prerequisite creation persists a coaching/entity/version-correct app alert for every active coaching admin including Owner. Deduplicate event/recipient work and retain AI provenance and authenticated revision-aware review. No email notification, SMTP/outbox or email digest is required; missing notification-contact email cannot block activation/normal access for an otherwise valid admin. Existing sign-in/identity requirements still apply. Current-role access and per-user read state remain required; no delivery integration exists.

## Notification-contact validation - superseded email requirement

The separate mandatory admin/Owner email contact rule created for email alerts is withdrawn. Notification-only email presence is not an onboarding/promotion/profile gate. Email/password and Google/mobile-OTP login retain their own verified identity/contact requirements; this does not authorize deleting a login email, silently merging identities or weakening authentication. App notifications use current authorized membership, not an email address.

## Linked login identity contract - confirmed result

All configured linked Google/email-password/mobile-OTP methods resolve to the same canonical user and current coaching/role grants. Link flows must verify existing-account control and the new method; a submitted email/phone or role field is insufficient. Fail conflicting identities without silently merging their data/memberships. Login/linking does not re-enroll removed faculty or grant platform authority. Exact routes/provider/recovery/session details remain design work; in-app-only notification policy is unchanged.

## Concurrent linked-account sessions

Accept concurrent valid mobile/laptop sessions for the same canonical user, including different configured linked login methods. Each request uses current user/membership/role authority and shared usage/idempotency/revision checks; device/session IDs do not create another user or budget. Authentication on a second device must not invalidate the first merely due to single-session assumptions. User-facing session/device-list and remote per-device logout management are excluded. Ordinary current-session logout remains; exact expiry/device cap/server-side revoke mechanics remain design work.
