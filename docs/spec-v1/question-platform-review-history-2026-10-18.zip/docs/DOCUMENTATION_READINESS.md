# Documentation Readiness and Review Gates

Prepared: 17 October 2026. **Current status: documentation baseline available for review; implementation not started.**

Current interview closure audit (18 October 2026): [the review closure plan](REVIEW_CLOSURE_PLAN.md) originally listed three inputs. Initial provider support is now confirmed for Google, Anthropic, OpenAI and OpenRouter with later extension; development hosting is now confirmed on this PC. Production hosting and its infrastructure budget are deferred, leaving zero required user questions in this interview round. This closes product discovery for the current scope, not design/document review or implementation readiness. The design details and later milestone gates below are not additional mandatory interview questions. The assistant should propose routine technical defaults and consolidate the documents before final review.

## Established facts

- All 13 Markdown files in the original handover archive were read; the master context, decisions and roadmap were read first.
- The user confirmed no existing source code exists and asked to complete/understand documentation before code.
- The user confirmed one initial coaching institute with architecture supporting many institutes; D-01 rollout scope is resolved, with subscription/payment collection deferred; future commercial details and deployment remain open. Review proceeds one question at a time.
- Admin controls approval/publication permissions independently. Creators require corresponding grants for own-content actions; create/upload grants neither.
- The initial local repository had no commits or tracked application files.
- The ZIP is retained as historical provenance. Expanded working documents live in this folder.

## Document coverage

| Area | Working document(s) | Readiness |
| --- | --- | --- |
| Goals and scope | Master context, PRD | Initial question-bank/database scope confirmed; tests/exports later; schema detail open |
| Requirements/acceptance | Requirements traceability, acceptance test plan | Draft criteria mapped; user review pending |
| User journeys and permissions | User workflows and permissions | Admin-controlled approval/publication confirmed; permission configuration details open |
| Decisions | Decisions/open questions, product decision register | Known choices separated from proposals; answers pending |
| Architecture and data | System architecture, database schema | Conceptual draft; stack/schema choices pending |
| Contracts | API contract draft | Resource/precondition outline; payload schemas pending format decisions |
| Ingestion | Question ingestion pipeline, upload/asset policy | PDF/Word/images and 50/10 MB limits confirmed; exact extensions/OCR/retry policies open |
| Publishing | Question lifecycle/QC | Published lock agreed; detailed states/draft policy pending |
| AI | AI orchestration, taxonomy/knowledge graph | AI-managed taxonomy/tagging required; immediate provisional activation/admin notification confirmed; provider/budget detail open |
| Tests and later students | Test builder and analytics | Requirements captured; scoring/export/privacy decisions pending |
| Security and operations | Security and multi-tenancy | Boundary/test requirements captured; deployment/retention targets pending |
| Delivery | Roadmap and implementation handover | Documentation-first order captured; first code slice pending review |

## Before calling requirements ready

1. Review the Hindi guide and first-release workflows with the user.
2. Resolve remaining commercial/permission/content-schema questions as relevant to the next slice. D-16 already defers tests/exports. All nine formats, admin-controlled permissions and one initial institute with multi-organization architecture are confirmed.
3. Confirm D-02/D-04/D-06/D-08 and the data/tenant decisions affecting the first executable slice.
4. Add reviewed sample question schemas, allowed transition/permission tables, and initial API payload examples after relevant choices.
5. Set measurable acceptance targets where required; do not invent targets without a corpus or user agreement.
6. Reconcile every answered decision across documents and record the approved next scope.

This gate intentionally distinguishes complete coverage of known requirements from finalized product specifications. Documents are not fully approved or implementation-ready while required decisions remain open.

## Later milestone gates

Before extraction: limits, representative files, OCR languages, unsupported-content rules, job retry/partial success policy. Before AI: model catalogue verification, provider data handling, operation permissions, budget and verification policy. Before test builder: scoring, duplicate/batch rules, exports and version locks. Before production/student data: operational recovery, privacy/consent, retention/deletion and incident handling.

## Verification scope

Documentation checks may verify Markdown inventory, relative link targets and requirement/decision references. Such checks do not validate architecture feasibility, application correctness, provider availability or migrations. Application tests and migrations have not been run because there is no application.

## Latest review progress

Confirmed: first release is question-bank entry/upload/review and database saving; tests/exports later. All nine formats included, numeric/option constraints recorded. PDF/Word/images included, accepted 50 MB/document and 10 MB/image limits. Detailed primary/multiple-secondary concept taxonomy and AI-created/maintained tagging catalogue required. AI immediate provisional concept addition with admin notification/revocation is confirmed. See the three dedicated specifications; schema details remain open; activation direction is confirmed.

## Confirmed AI and original-source lifecycle update

AI directly fills validated editable metadata without a per-field approval gate. New concepts may be added and used immediately with AI-added/admin-review-pending status. Notify admin for later approve/edit/merge/revoke; revocation stops new automatic use and preserves published snapshots. This supersedes the earlier approval-first rule; question approve/publish permissions remain separate.

Retain original source files until admin chooses deletion. Only admin can see storage analytics and delete originals; faculty can view their organization's originals. Original deletion must preserve saved questions and independently retained required diagrams/assets, show source-unavailable status honestly and record the deletion. No automatic expiry has been selected. See [source lifecycle](SOURCE_STORAGE_AND_RETENTION.md).

## Language catalogue and metadata display review update

English, Hindi and Gujarati were explicitly requested, plus three or four widely used regional languages. Initial four regional defaults are Bengali, Marathi, Telugu and Tamil, selected under that criterion. Admin may add more languages. See [language support](LANGUAGE_SUPPORT.md) for source basis and capability verification. Display one language at a time; each translation has a new master/code linked to the source; detailed QC remains open and generation is faculty-requested after source review.

The normal question view shows final/current metadata. Internal audit and AI provenance remain required; a per-field change timeline is not a required normal-screen feature.

## Prerequisite graph scope update

First-release AI creation of directed concept prerequisite links is confirmed. Immediate provisional link activation with admin notification and later approve/correct/revoke is confirmed; semantic examples, cycle disposition and educational evaluation remain design work. Later student recommendations are not brought into release one. Contract/schema work must distinguish concept edges, taxonomy parents and question concept assignments; this is documentation scope, not an implemented graph service.

## Platform role scope resolved

Full application access for platform admin across coachings is confirmed, superseding limited read/edit exclusions. See [platform access](PLATFORM_ADMIN_ACCESS.md). Enforcement/RLS, initial administrator identity, secret-display and operational contracts remain implementation design. No app exists and no platform operations or tests have run.

## Billing delivery boundary

Coaching subscription/payment collection is confirmed later scope. It must not block initial onboarding or question-bank workflows. Required AI usage/cost reporting and monthly spending controls remain in release one; subscription pricing, provider/gateway and commercial access policy are later design work. No billing code or payment integration exists.

## Initial usage clarification

Initial faculty count is qualitatively small, not a numerical cap or capacity guarantee. The bank is expected in lakhs; exact corpus count, concurrency/upload rate and measurable response/recovery targets remain design/evaluation work. This preserves first-release scope and future multi-coaching growth; no benchmark has been executed.

## Existing question source availability

User reports existing question-source files are available, with both text/selectable material and scanned PDFs/photos. This does not constitute a corpus inventory, measured mix, verified question count or extraction result. Representative text/scan/handwriting/layout samples and answer-key associations are still needed to complete evidence-based ingestion/OCR contracts. No source files have been parsed or benchmarked by this update.

## Adaptive extraction and later teaching update

First-release AI pattern learning/saving/reuse is confirmed, including handwritten questions and solutions. Source samples are explicitly deferred; continue documentation/contracts now, with multi-layout/drift/coverage and quality/token/time evaluation pending actual examples. Do not repeat upload requests or stop requirements work merely because samples are unavailable.

Later courses/live/recorded and student-personalized AI teaching/concept videos need separate enrollment/learner/media/quality contracts. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md) and [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md). No extraction/teaching capability is implemented or benchmarked.

## Coaching separation and optional platform sharing

Coaching data/pattern libraries are separate by default. Platform admin may explicitly share a complete coaching dataset with patterns/associated material to another coaching. Independent initial copy without synchronization is confirmed. Destination owns and can use/edit its copy under its roles; manifest/category treatment, exact ownership/code/dependency mapping, import-state and target-conflict details remain design work before implementation. This does not block ongoing requirements work. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md). No data has been shared.

## Copy scope: separate users and provider credentials

Independent initial copying covers educational questions/sources/taxonomy/patterns; destination users and API keys are explicitly set up separately. Preserve source evidence as provenance without active identity/privilege/secret or past-cost inheritance. Imported publication eligibility and nonempty-target/operational-history handling remain design/product details. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md). No data/credentials have been copied.

## Notification correction: app only

Email notifications and their dependent required admin notification-contact field are superseded by in-app-only alerts to all active coaching admins including Owner. Remove notification-email/digest/provider work from release readiness. Login/identity/recovery choices remain unchanged; current role checks, recipient read state, provenance and retry-safe app alerts still need implementation. No message/account action occurred.
