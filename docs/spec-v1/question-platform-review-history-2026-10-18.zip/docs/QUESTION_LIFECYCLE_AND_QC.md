# Question Lifecycle, Review and QC

## State and immutability review

Agreed invariant: published content is immutable, corrections create another version and historical tests remain pinned. Detailed transitions below are proposals to review under D-03/D-05/D-08, not final role grants.

**User-confirmed:** admin defines each user's approval/publication grants independently. A creator needs the corresponding grant for own-content actions. Creation/upload grants neither. A separate reviewer is not universally mandatory, but QC, validation, valid prior states and audit still apply.

| Action | Preconditions to define | Required invariant |
| --- | --- | --- |
| Save candidate/draft | Editable state and editor permission; required draft fields | Preserve origin and reject cross-tenant references |
| Submit for content QC | Publication-required structure or agreed submission subset | Record actor and submitted revision |
| Request changes/reject | Reviewer capability and valid review state | Record reason, maintain recoverable content/history |
| Approve | QC checks complete, correct revision, approver permission | Approval belongs to the reviewed content revision |
| Publish | Approved eligible version, explicit publish permission | Lock content and preserve audit/publication evidence |
| Correct published content | Authorized correction action and change reason | New version; old version remains unchanged |
| Archive/withdraw | Policy and permission still open | Do not delete historical referenced content |

An edit after review must not silently inherit approval for different content. Resolve approval invalidation and concurrency before implementation. The draft-storage choice (mutable draft versus append-only revisions) is separate from permanent published locking.

## Minimum QC evidence

Each review decision should identify the reviewer, candidate/version revision, outcome, time, reason or checklist evidence where required, and source/provenance. Question-type validation must cover correct option references, numerical/integer/single-digit constraints, matching structure, statement combinations, and passage dependencies according to the chosen content schema. Format-specific rules and publication-required metadata are D-07/D-09.

Assets and equations must remain renderable for historical versions. A published version whose metadata/asset bytes can be altered indirectly is not reproducible. Human reviewers must be able to inspect original source context for imported material.

## Duplicate and translation review boundaries

Linking an extracted duplicate to an existing master preserves the new source provenance and recorded human decision. Do not merge questions or delete sources based only on an AI score. Translation review needs a defined source-version relationship; source correction may require translation re-review under D-15.

## Lifecycle
Proposed lifecycle: `DRAFT → CONTENT_QC → APPROVED → PUBLISHED`. Define rejection/changes-requested states explicitly during implementation.

## Review roles
- Creator: create/import candidate questions and edit drafts.
- Reviewer/validator: check extracted content, answers, diagrams, options, and metadata.
- Approver/admin: approve and publish according to organization policy.
- Roles are scoped to organization membership and may be refined into permissions.

## Publishing
- Publishing is a controlled action with authorization and audit event.
- Published version content must be immutable for historical reproducibility.
- Corrections create a new version; do not rewrite the version referenced by an existing test.
- Keep actor, timestamp, source, and change reason.

## QC checks
- Question text and options complete.
- Answer/key and solution consistency reviewed as appropriate.
- Equations, units, figures, tables, and passage links preserved.
- Taxonomy and question type plausible.
- Source and PYQ metadata traceable.
- Duplicate/variant suggestion reviewed.
- Translation linked to the correct master and checked by a qualified reviewer.
- AI-verified status must be governed by explicit checks; AI-generated alone does not mean verified.

## Duplicate handling
- Exact checksum/normalized-text matching as a first pass.
- Fuzzy/semantic candidate generation as a second pass.
- Human confirmation before merging or declaring canonical relationships.
- Keep original source provenance even when linked to an existing master.

## Translation eligibility — confirmed

Faculty-requested translation is allowed only after source-question review completes. Enforce this in API/service state checks, not only a UI button. Preserve the reviewed source-version reference. Exact review-completion state and translated-output review/publication details remain open; do not infer that source publication is mandatory.

## Translated question identity — confirmed

A translated question has a distinct master/new permanent question code and its own version history. Store explicit translation-of and reviewed source-version provenance; enforce same-organization relationships. Correction of a published translation creates another version under that translation's stable code. Retry/replay must not create duplicate masters/codes. Original source content/code remain unchanged.

## Independent source/translation updates — confirmed

The user confirmed that original and translated questions may be updated independently. Do not require simultaneous edits or automatically overwrite a translation when its source changes. Each master keeps its own stable code and version history; preserve the translation-of link and exact originating source version. Published corrections create a new version for the affected master. This does not authorize silent mutation of either published version.

## Optional solution at publication — confirmed

User-confirmed: a question may be published with a correct answer even if no solution/explanation is provided. Solution is optional, not a publication prerequisite. Type-valid answer, complete question content, applicable review/metadata checks and admin-defined publication permission remain required; this answer does not waive them. If a solution is supplied, preserve it as part of the version and apply relevant QC.

## Primary concept required for publication — confirmed

User-confirmed: a question must have a primary concept tag before publication. Missing primary concept blocks publication, while incomplete drafts remain editable. AI may assign the primary concept directly from the catalogue or create an immediately usable AI-added/admin-review-pending concept under the confirmed policy; catalogue admin approval is not a new prerequisite. Validate concept existence and organization scope. Secondary concepts remain optional unless a later decision explicitly requires them; primary-tag presence alone does not prove content correctness.

## Required publication classification — confirmed

User-confirmed: class, subject, chapter and topic are mandatory before publication, in addition to the previously required primary concept and type-valid correct answer. Incomplete drafts remain saveable. Validate organization scope and hierarchy consistency for selected catalogue entries; merely nonempty text does not establish a valid assignment. AI directly fills metadata under the existing policy. Subtopic and other metadata completeness are separate decisions still under review; solution remains optional.

## Subtopic optional at publication — confirmed, 17 October 2026

User-confirmed: subtopic is optional. Its absence must not block publication if class, subject, chapter, topic, primary concept, correct answer and other applicable requirements are met. If a subtopic is assigned, validate its hierarchy and tenant scope. Do not invent a subtopic solely to satisfy a completeness check.

## Difficulty required for publication — confirmed

User-confirmed: a valid difficulty level on the agreed 1–10 scale is required before publication. AI may fill it directly with provenance and authorized users may correct it. Missing or out-of-scale difficulty blocks publication, while incomplete drafts may be saved. Calibration/definitions and any finer numeric granularity remain design work; presence of a difficulty label alone does not establish correctness.

## Bloom level required for publication — confirmed

User-confirmed: a valid Bloom taxonomy level is required before publication. AI directly fills the field with model/prompt provenance and authorized users may correct it. Missing or invalid catalogue values block publication; incomplete drafts remain saveable. Preserve a stable level identity with localized labels and version-scoped metadata. This does not turn an AI-assigned label into evidence of educational quality; calibration/examples remain design work.

## PYQ exam and year required — confirmed

User-confirmed: if a question is marked as a previous-year examination question (PYQ), exam name and exam year are required before publication. Incomplete PYQ drafts may be saved but cannot publish without both fields. This conditional requirement does not force non-PYQ questions to carry exam/year values. Retain source provenance and do not fabricate missing exam/year to pass validation. Date, paper code, slot/shift and other PYQ metadata completeness remain separate decisions.

## Optional PYQ detail fields — confirmed, 17 October 2026

User-confirmed: PYQ date, shift/slot and paper code are optional. Populate them when known, retain provenance and leave unknown values absent rather than inventing them. Their absence does not block publication. Exam name and year remain mandatory when PYQ is selected. See the consolidated [publication requirements](PUBLICATION_REQUIREMENTS.md).

## Return for correction and resubmit — confirmed

User-confirmed: when review finds an issue, the question can be returned to its creator for correction and submitted for review again. Preserve content/source identity and review history; returning work is not deletion or automatic creation of a new master. Represent a changes-requested correction loop alongside the existing draft/content-QC/approved/published flow. Authorize return/edit/resubmit actions and bind review decisions to the reviewed revision; published versions remain immutable. Exact role grants, reason/comment requirements, reassignment and separate rejection/withdrawal policies remain open.

## Distinct identity for practice variants — confirmed

User-confirmed: a new practice variant made by changing values or conditions receives its own permanent, globally unique eight-character alphanumeric question code. It is a distinct question master with its own version history, explicitly linked as variant-of to the original. Preserve source-version and creation/AI provenance where applicable. This does not change the correction policy: correcting an existing question creates a new version under that existing master/code. Automatic variant generation, inheritance of review status and generation permissions are not established by this answer.

## AI variants in first release — confirmed

User-confirmed: AI generation of practice variants is included in the first release. Generated variants receive separate masters/new global eight-character codes and variant-of/source-version provenance; they follow normal question QC and authorized approval/publication. Original content remains unchanged. Faculty request is the confirmed trigger; no automatic per-question generation. Source eligibility, generation count/controls and operation permissions remain open. See [AI variant generation](AI_VARIANT_GENERATION.md).

## Variant generation before source review — confirmed, 17 October 2026

User-confirmed: original-question review completion is not required to generate a variant. Faculty may request a variant from an accessible draft/unreviewed source. Preserve the exact source content/version and its review status; source approval is not inherited. Generated variants still enter normal candidate/draft QC and require valid publication fields and admin-granted approve/publish permissions. Translation retains its separate post-review gate; do not apply that gate to variants.

## First-release AI diagram creation/editing — confirmed

User-confirmed: first release includes AI generation of question diagrams and modification of existing diagrams when needed. Keep reviewable asset output, provenance, same-tenant attachment, preserved originals and version-safe references. Human QC checks diagram/question/answer consistency; no automatic verification or publication. Invocation controls, supported representation/providers/models and evaluation remain open. See [AI diagram assistance](AI_DIAGRAM_ASSISTANCE.md).

## Admin controls cross-author editing — confirmed

User-confirmed: admin decides whether a user may edit questions created/uploaded by other faculty in the same coaching. Complete bank visibility does not grant cross-author edit permission. Enforce this independently from approval/publication grants and tenant scope. Published content is never overwritten: authorized corrections create a new version under the existing question code and retain audit/source history. Own-draft editing, exact default grants and edit/approval invalidation details remain governed by the final permission/lifecycle design.

## Admin-granted review/QC permission — confirmed

User-confirmed: formal question review/QC requires a separate permission granted by admin. Default faculty bank/source viewing, upload/manual entry and AI access do not grant formal review authority. Review, approval and publication are independent grants. A user may perform their own review/approval/publication only when holding the corresponding permissions; no different person is universally mandated. Review permission authorizes reviewed-state decisions/correction-return within the workflow, not protected content edits without the required edit permission. Preserve actor/revision-bound QC evidence and deny unauthorized review transitions.

## Shared pending-review access — confirmed

User-confirmed: any faculty member with review/QC permission may review pending questions in their own coaching. Mandatory per-question reviewer assignment is not required. Present a shared pending-review queue scoped to that organization and enforce the independent review grant. Preserve revision-bound decisions, actor/history and correction-return/resubmission. Concurrent decisions need transactional conflict handling rather than silently overwriting each other. Optional assignment is not a required feature by this answer; default faculty without the review grant cannot complete formal QC.

## Faculty-requested solving of missing answers — confirmed

User-confirmed: when an imported question has no answer, faculty can request AI to solve it and fill the answer. On-demand only; no automatic solving for every upload. Preserve model/prompt/source-revision provenance and distinguish AI output from an extracted key. Validate answer format and retain normal QC; generation alone grants neither verified status nor publication. Solutions remain optional. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Automatic own-coaching duplicate checks — confirmed

User-confirmed: every new question is automatically checked against its own coaching's existing question bank for duplicates. Shared downstream rules cover manual/import/generated candidates. Preserve tenant-safe candidate evidence and sources; human QC confirms duplicate/variant/translation disposition before canonical/merge decisions. Do not silently reject/delete uncertain candidates or collapse distinct variants/translations. Exact matching policy/thresholds and final confirmed-duplicate treatment remain open. See [duplicate policy](DUPLICATE_AND_VARIANT_POLICY.md).

## Exact duplicate attaches source without new code — confirmed

User-confirmed: after human review confirms an intake candidate is exactly an existing question, link the new source/provenance to the existing question instead of creating a new master/code. Keep the existing permanent code and matching-version evidence; preserve source/candidate records and review audit. Appending source evidence must not silently overwrite content, answer, solution or published metadata. Conflicting keys or non-identical content require visible review rather than forced duplicate treatment. Existing published duplicate masters/canonical merge policy remains separate; variants/translations retain their confirmed distinct codes.

## Admin and creator question archival — confirmed

User-confirmed: archive removes a question from the active bank while retaining content/history. Admin may archive questions in their own coaching, and creator faculty may archive their own question. Complete-bank view or cross-author edit permission alone does not grant archive authority over other creators' questions. Preserve code, immutable published versions, assets, sources/audit and historical references; archival is not physical deletion or admin-only original-file deletion. Restore behavior remains open. See [question archival](QUESTION_ARCHIVAL.md).

## Admin and creator may restore archived questions — confirmed

User-confirmed: both admin and creator may restore archived questions. Admin acts within their coaching; creator acts on their own question. Keep the existing code, content/versions/provenance and archive/restore audit. Restoring availability is not automatic approval/publication of an unreviewed draft or authority to overwrite published content. Detailed state/eligibility and concurrency handling remain design work.

## Faculty-requested AI correctness checking — confirmed

User-confirmed: the first release includes faculty-requested AI checking of an existing answer and available solution. Keep reviewable findings, reasons/uncertainty and exact input-revision/model provenance; answer-only questions remain eligible because solutions are optional. Checking does not silently replace content or grant QC, approval, publication or an AI-verified badge. Use the existing tenant credentials, enabled-model, budget and background-job policies. Flagging, correction suggestions and explicit opt-in direct correction with visible before/after changes are confirmed; verification-badge criteria remain design/review work. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Opt-in AI corrections with visible changes — confirmed

AI must flag suspected errors and show corrected answer/solution suggestions. Faculty may opt in to direct application, and the interface must still show the old/new values and reason. Without opt-in, the operation leaves existing answers/solutions unchanged. Enforce current same-tenant edit permissions and revision conflict/type-validation checks on actual writes, including background completion; never silently overwrite a concurrent edit. Keep source values and actor/model/input/application provenance. Correcting published content creates an editable new version under the same master/code, retaining the existing published snapshot and normal revision-bound QC/approval/publication controls. Direct-correction opt-in applies to one question at a time, selected separately for that question; no batch-wide or carried-over opt-in. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Explicit platform question editing — confirmed

Platform admin may edit questions in all coaching organizations through explicit platform-edit authorization and target-coaching context. Enforce type/content validation, current revision and tenant-consistent references, and record platform actor plus before/after evidence without transferring coaching ownership/creator attribution. Published corrections create an editable new version under the same master/code; preserve the existing published version and revision-bound QC/approval rules. The later full-access decision also grants QC/approve/publish, supported archive/delete, original-source/credential administration and supported AI/other app actions; the edit-path description is not a limit on platform authority. Use a reviewed restricted API/RLS write policy rather than unrestricted database bypass. See [identity and access](IDENTITY_AND_ACCESS.md).

## Current platform authority — full access

Platform admin has full application access across all coachings, including question QC/approve/publish, originals/storage, users/Owners/roles, taxonomy, AI credentials/configuration/budgets/jobs and analytics. Earlier limited platform read/edit exclusions are superseded. Coaching roles retain their own-coaching boundaries. Validation, published-version preservation, current authority checks, coaching data ownership, secret handling and audit remain required. Full authority covers supported features and does not move deferred test/student features into release one. See [the platform access specification](PLATFORM_ADMIN_ACCESS.md).

## Published status in independent coaching copies - confirmed

When platform admin copies an existing coaching dataset, source-published question snapshots remain published in the destination without mandatory re-review merely for copying. Preserve source QC/publication provenance, the platform copy actor and exact version/dependency mapping; do not invent destination reviewer identities. New destination question masters still receive new globally unique codes. Validate complete snapshot/reference integrity; do not promote source drafts/unreviewed content. Later destination edits create a new editable version under the destination code and follow normal QC/approval/publication; copied published snapshots stay immutable. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).
