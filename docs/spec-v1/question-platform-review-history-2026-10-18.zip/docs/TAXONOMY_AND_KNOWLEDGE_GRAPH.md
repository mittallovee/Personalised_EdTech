# Taxonomy, AI Tagging and Knowledge Graph

Status: requirements and immediate provisional activation policy confirmed; detailed schema under review. Prepared 17 October 2026. No AI integration or taxonomy service has been implemented.

## Confirmed requirements

- Detailed classification includes class, subject, chapter, topic and subtopic. The user explicitly described class/subject/topic/subtopic; chapter remains from the prior agreed metadata.
- Questions can link to a primary concept and multiple secondary concepts. Examples of secondary concept one/two do not impose a fixed maximum of two.
- Stable concept relationships will support a future knowledge tree and concept-based question recommendations for students. Recommendation delivery and mastery analytics remain later scope.
- AI directly fills metadata after validation; per-field human approval is not required. Authorized users can correct it later, with traceability.
- AI creates the initial taxonomy catalogue and chooses tags from that catalogue rather than producing unrelated free-text labels for each question.
- If a needed concept is missing, AI can extend the catalogue through the selected update workflow.

A primary concept is required before publication, as confirmed by the user. Incomplete drafts may omit it. Class, subject, chapter and topic are also confirmed mandatory before publication. Subtopic is confirmed optional; other per-node/metadata completeness remains under review. If a subtopic is supplied, validate its hierarchy and scope. Do not silently make every field mandatory. A provisional AI-added concept is usable under the confirmed immediate-activation policy.

## Catalogue and assignment design — proposed

Use stable identities for hierarchy nodes and concepts, with labels, definitions, aliases/synonyms, language, organization scope and provenance. Avoid treating identical text in different contexts as automatically the same concept. An AI operation should resolve existing concepts before proposing a new identity, and should retain evidence for why each concept applies.

Question assignments should preserve the exact question version, concept identity, primary/secondary role, suggestion/accepted status, confidence where meaningful and AI/human attribution. Detailed meaning of confidence and primary-concept selection needs examples. Published metadata must be reproducible even when catalogue labels or relationships later change.

A question hierarchy is not the same as a prerequisite graph. AI-created prerequisite links are confirmed first-release scope: they express which concept should be understood before another. AI-created prerequisite links are immediately usable with admin notification and later admin correction/revocation, as confirmed below. Related-concept links, concrete educational edges, weights, cycle policy and mastery formulas remain design/evaluation work. Personalized student recommendations and analytics remain later scope. Do not infer recommendation quality merely from concept tags or AI-created edges.

## AI tagging lifecycle — proposed implementation flow

1. Load the applicable organization's enabled catalogue and taxonomy/schema version.
2. Analyze validated question content and suggest classification/concept assignments.
3. Resolve existing IDs using definitions, aliases and context; check candidate duplicates before creating another node.
4. If no appropriate concept exists, create a structured discovery record with proposed label/definition, parent/context, supporting question reference and model/prompt provenance.
5. Create a missing validated concept as AI-added/admin-review-pending and use it for tagging immediately. Notify admin; prior approval is not a processing prerequisite.
6. Store traceable assignments; continue the question workflow according to publication/QC permissions.
7. Support admin correction, merging aliases/remapping where appropriate and version-aware audit.

An AI catalogue update does not authorize AI publication of a question, change user permissions or grant cross-organization access.

## Activation policy: recorded sequence

1. The user initially chose **admin approval** for new concepts. Under that policy, new discoveries remain pending until admin approval.
2. The user then asked for advice about an alternative: **AI adds directly, processing continues, admin is informed and may later revoke**.
3. The user explicitly accepted the immediate-add/admin-notification workflow. This supersedes approval-first: new concepts can be used while admin review is pending.

## Confirmed activation workflow

Allow AI to create a **provisional, usable concept**, labeled as AI-added with admin review pending. It can be used for candidate tagging so processing continues. Keep its stable ID, definition, context and source/model/prompt evidence. Notify all active admins of that coaching, including Owner, inside the app through the review/notification list. Email alerts and their dependent mandatory contact requirement are cancelled; authentication requirements are unchanged.

Admin can approve, edit, merge into an existing concept, or revoke the concept. Revocation should deactivate it for new automatic assignments and create a review/remapping action for affected current drafts. It must not delete questions, break references or silently change historical published versions. Exact impact on publication eligibility and recommendation use remains a policy decision.

Before creating a provisional concept, require structured validation, correct organization/parent scope and an existing-concept similarity/alias check. Concurrent duplicate proposals need idempotency and merge handling. Bound automated catalogue growth; the numerical limits and review service levels are not decided.

This user-approved approach keeps tagging moving while making uncertainty and admin control visible. It does not grant permission to publish questions or bypass tenant/schema checks.

## Historical and future-use boundaries

Published question versions retain the taxonomy/assignment snapshot needed for historical tests. A concept merge/revocation updates present catalogue availability and records a mapping/history event; it does not rewrite published question meaning. Later analytics can use explicit canonical mappings while retaining the original concept/version evidence.

Concept-based student suggestions will need reviewed prerequisite semantics, sufficient attempt evidence, explainable ranking and educational validation. Neither a primary tag nor an AI confidence score is a student mastery measurement.

## Acceptance cases for the confirmed policy

- AI reuses the correct existing concept/alias instead of creating near duplicates.
- Primary and multiple secondary assignments remain linked to the correct question version and tenant.
- Missing concepts are immediately usable with explicit AI-added/review-pending status and provenance; no prior admin approval blocks tagging.
- Concurrent discovery does not create uncontrolled duplicate identities.
- Admin notification/review is visible and actionable after immediate activation.
- Approve/merge/revoke produces audit evidence, handles current assignments and preserves published history.
- Catalogue access and AI lookup cannot expose another organization's private taxonomy/questions.

## Language catalogue and metadata display review update

English, Hindi and Gujarati were explicitly requested, plus three or four widely used regional languages. Initial four regional defaults are Bengali, Marathi, Telugu and Tamil, selected under that criterion. Admin may add more languages. See [language support](LANGUAGE_SUPPORT.md) for source basis and capability verification. Display one language at a time; each translation has a new master/code linked to the source; detailed QC remains open and generation is faculty-requested after source review.

The normal question view shows final/current metadata. Internal audit and AI provenance remain required; a per-field change timeline is not a required normal-screen feature.

## Difficulty required for publication — confirmed

User-confirmed: a valid difficulty level on the agreed 1–10 scale is required before publication. AI may fill it directly with provenance and authorized users may correct it. Missing or out-of-scale difficulty blocks publication, while incomplete drafts may be saved. Calibration/definitions and any finer numeric granularity remain design work; presence of a difficulty label alone does not establish correctness.

## Bloom level required for publication — confirmed

User-confirmed: a valid Bloom taxonomy level is required before publication. AI directly fills the field with model/prompt provenance and authorized users may correct it. Missing or invalid catalogue values block publication; incomplete drafts remain saveable. Preserve a stable level identity with localized labels and version-scoped metadata. This does not turn an AI-assigned label into evidence of educational quality; calibration/examples remain design work.

## Variants preserve the primary concept — confirmed, 17 October 2026

User-confirmed: practice variants must keep the original primary concept. Question type, requested difficulty and values/conditions may change without changing that main concept. Preserve the stable concept ID and source-version provenance. Validate semantic fidelity rather than merely copying the concept label onto unrelated generated content. Source review is not required; if source primary metadata is missing, resolve it through the existing AI/candidate metadata workflow rather than introducing a new review prerequisite. Other concept/quality checks still apply.

## One chapter and one topic per question — confirmed

User-confirmed: a question has only one chapter tag and one topic tag, not multiple chapters/topics. Required chapter/topic classification at publication means one valid selected value of each; incomplete drafts can still omit required values until ready. Preserve optional subtopic and the separately confirmed primary plus multiple secondary concept associations. Multiple concepts do not authorize hidden extra chapter/topic tags. Cross-branch concept association rules remain design work; do not silently remove the multiple-concept requirement.

## AI prerequisite links in the first release — confirmed

AI must create directed prerequisite relationships between concepts in release one, forming the foundation for the later knowledge graph and personalized question suggestions. This is a concept-to-concept relationship, separate from question primary/secondary tagging and the class/chapter/topic hierarchy. It does not add extra chapter/topic tags to a question or require a student app in release one.

Proposed contract: represent prerequisite A → dependent B as “understand A before learning B.” Store stable endpoint IDs, organization, relationship type, explanation/supporting evidence when available, AI run/model/prompt, graph revision, status and change history. Multiple prerequisites/dependents need explicit relationships rather than a single taxonomy-parent field. Version relationships so later catalogue edits do not erase previous graph or question-version evidence.

Validate same-tenant endpoint access/existence and relation direction; surface duplicate/self/circular or conflicting proposals instead of silently accepting inconsistent learning sequences. Proposed design is to reject self-links and duplicates and detect prerequisite cycles, keeping problematic AI output reviewable. Exact cycle disposition and educational calibration remain design work; co-occurrence in a question alone does not establish a prerequisite.

The user explicitly confirmed immediate activation for AI-created prerequisite links, matching the concept workflow: validated links are usable with AI-added/admin-review-pending status, and admin receives a notification/review entry. Admin may later approve, correct or revoke a link; no prior approval blocks adding valid links or continuing processing. This grants neither automatic student recommendations nor ranking/mastery formulas or new faculty graph-edit authority.

Planned acceptance: AI outputs traceable directed links for known concepts; support multiple prerequisites; preserve endpoint scope and graph revisions; flag missing/invalid/circular proposals and uncertain evidence; verify immediate activation/admin notification and authorized later correction/revocation with preserved graph history. No AI graph integration or educational quality evaluation has been executed.

## Prerequisite link administration — confirmed workflow

AI adds validated same-coaching prerequisite links directly, marks them AI-added/admin-review-pending and continues processing. Admin sees the new links and their explanation/provenance in a review list; prior approval is not required for their use. Admin can approve, correct or revoke them afterward.

Design direction: retain stable link identity, endpoint/direction changes, actor/reason/time and before/after graph revisions. Revocation removes the link from the active prerequisite graph without deleting concepts, questions, original evidence or historical graph versions. Correction or removal must not silently change published question content. An unchanged rejected/revoked relationship must not immediately return through an automatic retry; keep disposition evidence and define deliberate rediscovery handling. Structural/tenant validation still precedes activation; immediate use does not waive invalid/self/cyclic-link handling. In-app-only alerts to all active coaching admins including Owner are confirmed; email/digest/contact requirements are withdrawn and detailed app review UI remains implementation design, and faculty graph-edit permission is not granted by this decision.

## Faculty graph browsing and linked questions — confirmed

In the first release, faculty can view their coaching's knowledge tree as a graph and click a concept to open its linked questions. This is a faculty question-bank navigation feature, distinct from later personalized student recommendations and mastery analytics. The graph may contain multiple prerequisites/dependents; do not force prerequisite relationships into a single-parent tree.

Design direction: render prerequisite direction and concept labels using stable identities and supported languages. Distinguish immediately usable AI-added/review-pending concepts and links from admin-reviewed ones. Revoked links are absent from the current active graph while historical relationship evidence remains available through authorized administration/history. A selected concept navigates to questions assigned that concept as primary or secondary, without presenting inferred prerequisite questions as directly tagged matches. Deduplicate questions that match multiple assignments and preserve the bank's existing content/status access policy. Show empty, loading, unavailable and failure states honestly.

Enforce tenant/membership scope for graph endpoints, concept details, counts and linked-question queries. Faculty graph viewing/clicking grants neither graph modification nor question edit/QC/approve/publish rights. Show question content/version under existing bank rules; a displayed historical version must retain its own classification evidence. Graph layout, progressive loading/search/filter controls and rendering library remain implementation design; the user has not approved a separate graph-editing interface or student mastery visualization.

Acceptance direction: faculty opens the graph, sees direction/provisional status, selects a concept and reaches its primary/secondary-linked own-coaching questions; empty concepts show no results, revoked links disappear from active view, and cross-tenant IDs/counts/navigation are rejected. A concept click must not trigger question generation, publication or a chargeable AI operation merely to retrieve stored links.

## Prerequisites stay within one subject — confirmed

Prerequisite links may connect concepts only within the same subject. Cross-subject links, including a Maths concept as a Physics prerequisite, are not allowed. Enforce this for AI-created links, admin corrections and any graph-write contract before activation; immediate provisional use does not bypass the subject restriction.

Design direction: resolve both endpoints against the same stable subject identity/context and coaching rather than compare localized labels. Missing or ambiguous subject context stays unresolved for correction; do not silently invent a subject or activate an invalid edge. Subject corrections/merges need to revalidate affected active links and preserve prior graph evidence rather than silently keep a newly cross-subject relationship active. Faculty views and queries must not expose invalid cross-subject edges.

This decision concerns concept prerequisite relationships. Cross-class prerequisites within a subject are confirmed below; this decision alone did not settle cross-chapter policy and does not change question primary/multiple-secondary tagging, one-chapter/one-topic classification, or the later student-product boundary.

## Cross-class prerequisites within a subject — confirmed

Prerequisite links may connect concepts across different classes within the same subject and coaching. For example, a Class 11 concept can be a prerequisite for a Class 12 concept. Different class identities alone must not cause a valid relationship to be rejected or hidden.

Preserve each endpoint's class/catalogue context and stable concept/subject identity. Do not duplicate a concept, change a question's class/chapter/topic tags, or manufacture subject equivalence to create the link. Subject matching is by stable subject context rather than separate class-specific display labels. Cross-subject links remain forbidden. AI immediate activation/admin notification and later admin correction/revocation still apply, as do direction, provenance and graph-history rules.

Graph loading and navigation must be able to retrieve a linked prerequisite/dependent from another class under the same coaching/subject scope. Any class filter is a view choice, not a ban on stored cross-class links; detailed filter behavior remains UI design. Direction comes from the educational prerequisite relationship, not simply sorting class numbers. Reverse-class pedagogical examples and general cross-chapter constraints remain design/review details rather than new restrictions inferred from this answer.

## New concept creation: admin and AI only — confirmed

Only coaching admin and the authorized AI taxonomy workflow may create new concept identities. Faculty cannot manually add a new concept through the catalogue, question editor or graph UI. Existing faculty graph viewing and authorized question-tag correction/selection from available concepts remain; selecting a concept for a question is not concept creation.

The AI may still discover and add a missing concept while processing faculty work, using the confirmed immediate usable/AI-added/admin-review-pending policy with admin notification and later approve/edit/merge/revoke. Default faculty AI access therefore remains available, but it is not a direct catalogue-create permission. Attribute the initiating faculty separately from the AI operation and preserve model/validation evidence.

Design consequence: enforce admin creation on manual/API writes and a trusted, validated AI service path for AI creation. A client-supplied “AI” actor/origin flag cannot bypass permissions. Check tenant scope, valid catalogue context, existing concept/alias matches and idempotency on both paths. Admin-created concepts do not need an AI provenance claim; retain their human actor and change history. The following confirmation extends the same creation-authority restriction to class, subject, chapter, topic and subtopic entries.

## Hierarchy entry creation: admin and AI only — confirmed

Only admin and the authorized AI taxonomy workflow may add class, subject, chapter, topic or subtopic entries. Faculty can select available entries and correct question assignments within their existing edit permissions, but cannot manually create new catalogue entries. This extends the concept-creation authority decision to the remaining hierarchy levels; it does not make optional subtopic mandatory.

Apply the same server-side tenant/actor boundary to manual catalogue writes, implicit creation from question-editor inputs and background AI processing. Reuse stable existing entries/aliases in their valid parent context before creating another identity; preserve AI/admin and initiating-user provenance. A user-supplied origin label is not authorization. Validate hierarchy/parent scope and preserve published classification evidence when the catalogue evolves.

This confirms creation authority. Detailed validation, activation statuses and catalogue administration UI for non-concept hierarchy entries remain implementation design; do not silently change the separately confirmed concept/prerequisite provisional-use and admin-review rules or grant faculty graph/catalogue editing rights.

## AI concept/prerequisite alerts: in-app only - current rule

AI-added concepts and prerequisite links notify all active admins in the originating coaching, including Owner, inside the app only. Email notifications are cancelled for the current release. There is no notification-email provider, delivery queue, email digest or separate mandatory admin email-contact requirement for these alerts. Existing Google/email-password/mobile-OTP login choices and their identity requirements remain unchanged.

Preserve immediate provisional use: alerts/review do not add a prior approval gate or block valid AI tagging. Store tenant/entity/version-correct events and per-recipient notification/read state, with AI provenance and authenticated review links. Deduplicate event/recipient records on retry; read/dismiss and shared concept/link review outcomes are distinct. Recheck active admin membership on notification access so removed/demoted users cannot rely on stale recipient records. No other-coaching broadcast is introduced.

Notification persistence/recovery must not duplicate taxonomy additions or falsely report completed review. Detailed in-app presentation, retention and newly appointed admin access to old alerts remain implementation design. No message or application notification has been sent.

