# Product and Technical Decision Register

Status: review draft, 17 October 2026. D-01/D-03/D-07/D-09/D-10/D-13/D-16 have recorded answers or partial resolutions below. Unanswered details remain open; suggestions are not approvals.

Only decisions that block the next implementation slice need closure before that slice; deferral must be explicit. The user currently wants documentation review before code.

| ID | Decision needed | Proposal or concrete options for discussion | Needed before |
| --- | --- | --- | --- |
| D-01 | Rollout and multi-organization scope — partially resolved | Confirmed: initially one coaching institute; retain support for many coaching organizations from the design stage. Coaching name/logo display is confirmed; one shared website/app entry link is confirmed with no separate coaching domains/subdomains required; independent products, broader theme customization and physical deployment arrangement remain unconfirmed | Product scope |
| D-02 | Login/unified identity/onboarding/single-coaching scope confirmed; provider/link-flow open | Google/email-password/mobile OTP can link to one canonical user with the same grants/history; admin invites/creates faculty; each faculty account has one coaching and no organization switcher. Provider/session, linking/recovery, invite delivery and owner bootstrap remain open | Foundation/identity |
| D-03 | Faculty defaults, protected grants and shared review confirmed; role/UI detail open | Faculty get own-bank/source view and upload/manual/AI by default. Admin grants QC/approve/publish/cross-author edits separately; any QC-authorized faculty reviews own-coaching pending work without assignment. Storage admin-only; role/UI design open | Identity/QC |
| D-04 | Implementation stack | Review proposed Next.js/FastAPI/PostgreSQL stack and queue/storage choices; choose migration policy and runtime versions after local compatibility verification | Foundation |
| D-05 | Return-for-correction loop and publication fields partially resolved | Review may return work to creator for correction/resubmission. Publication field requirements are consolidated separately. Rejection/withdrawal/archive, edit invalidation, approved locking and detailed grants remain open | QC schema |
| D-06 | Eight-character globally unique question code confirmed; alphabet detail open | Exactly eight alphanumeric characters, globally unique across all organizations. Secure generation/collision handling remain required; exact alphabet/case, lookup UX and non-reuse policy need design | Question master schema |
| D-07 | All nine formats confirmed for first release; schema details open | SCQ, multiple correct, integer, single digit, numerical, matching, assertion–reason, passage and multiple statement. Numeric/option constraints: see question-type specification | Question schema |
| D-08 | Draft history, version lock and concurrency | Published immutability is settled. Decide whether drafts mutate or produce revisions, when approved content locks, conflict handling and supersedes links | Version schema |
| D-09 | Detailed taxonomy and knowledge-tree direction — partially resolved | Class/subject/chapter/topic/subtopic; primary and multiple secondary concepts; stable concept identities for later recommendations. AI creates and maintains catalogue; provisional immediate activation with admin notification/revocation confirmed | Metadata schema |
| D-10 | Bulk PDF/DOC/DOCX/images and per-file limits confirmed; technical details open | Bulk upload, linked paper/key/solution files, legacy DOC plus DOCX, 50 MB/document and 10 MB/image. Exact image extensions, aggregate/file-count bounds, storage/conversion and byte interpretation remain design work | Upload |
| D-11 | Language scope, legacy Word and handwriting confirmed; OCR/evaluation detail open | Printed/scanned and handwritten question photos/scans in release one; initial seven-language catalogue and admin extension. Select/benchmark OCR/vision/conversion engines and corpus; encrypted/corrupt-input handling remains open | Extraction/language support |
| D-12 | Background/concurrent workflows and own-job cancellation confirmed; recovery detail open | New uploads/other app work continue during background jobs; faculty may cancel own jobs. Finalize partial-output retention, cancellation races/in-flight behavior, retry/idempotency/progress and limits | Job orchestration |
| D-13 | AI workflows, coaching-owned keys and budget policy confirmed; catalogue/implementation detail open | Each coaching supplies provider keys. Faculty defaults, AI metadata/taxonomy/variants/diagrams/on-demand answers, usage dashboard, monthly budgets with 80% warning/100% stop and first-day reset confirmed. Initial providers: Google, Anthropic, OpenAI and OpenRouter; allow later extension. Exact APIs/models, secret manager, verification/accounting design remain open | AI integrations |
| D-14 | Automatic own-bank checking and confirmed-duplicate source linking resolved; thresholds/canonical detail open | Human-confirmed exact intake duplicate adds source to existing question with no new code. Variants/translations remain distinct. Algorithms/thresholds, existing duplicate-master handling and later test/batch policy remain open | Relationships/test builder |
| D-15 | Translation identity, display and generation confirmed; QC detail open | Distinct master/new code for each translated question, linked to reviewed source version; one display language; faculty-requested generation after source review; detailed QC/permissions remain open | Translation schema |
| D-16 | First-release boundary confirmed; test details deferred | First release: question-bank entry/upload/review and database saving. Test creation and test-paper exports later; scoring, batch and export detail deferred | Later test builder |
| D-17 | Student product and privacy | Separate later discovery: enrollment, minors/privacy/consent, submissions, timing, event semantics, analytics and recommendation evaluation | Student design |
| D-18 | Local development on this PC confirmed; production deferred | Develop and host the development environment on this PC. Propose local service/storage configuration; actual stack/runtime compatibility remains to be verified. Production hosting/budget, monitoring, recovery goals and availability targets are later deployment gates | Local foundation design; production gate |
| D-19 | Source storage and admin/creator question archival confirmed; restore/retention detail open | Originals retained until admin deletion, admin storage analytics, faculty source view; admin archives own-coaching questions and creator archives own questions without deleting history. Restore, backups/audit retention and inactive-user lifecycle remain open | Data lifecycle; production gate |
| D-20 | Faculty UI, final metadata view and accessibility — partially resolved | Normal question UI shows final/current metadata, not a per-field change timeline. Keep backend audit/provenance. Language catalogue direction confirmed; interface localization, mobile/accessibility and bulk UX detail open | Faculty UI |
| D-21 | Adaptive extraction patterns — confirmed first release | AI learns unknown layouts, saves/versioned patterns and automatically reuses compatible layouts with drift/coverage checks, handwriting/solution support and token/time evidence; separate coaching libraries/platform sharing confirmed, independent initial copy confirmed, lifecycle/engines open | Ingestion design |
| D-22 | Courses/live/recorded and personalized AI teaching — confirmed later | Faculty courses/live/recorded classes and AI teaching/student-need/level-specific concept videos; future learner/media/enrollment/provider/evaluation contracts required | Later learning |
| D-23 | Coaching-specific data/patterns and platform sharing - confirmed | Separate libraries by default; platform admin may share complete dataset/patterns/associated material with another coaching; independent initial copy/no synchronization confirmed; users/API keys set up separately; import state, operational references and conflicts remain design work | Dataset-sharing design |

## Settled constraints carried forward

Organization ownership; strong tenant isolation; shared downstream manual/import processing; separate UUID/code/version identities; permanent 8-character alphanumeric codes; immutable published versions and exact-version test references; explicit relationships; controlled AI catalogue and provenance; modular monolith with workers; human QC authority.

## Recorded answers

### D-01 — rollout scope, 17 October 2026

- **User-confirmed answer:** launch initially for one coaching institute; keep support for many institutes.
- **Implication:** multi-tenant data ownership, membership and isolation remain foundation requirements from the beginning. One initial organization is a rollout choice, not a single-tenant architecture requirement.
- **Not decided:** shared versus separate deployments, independent product instances, extended theme/white-label settings, actual shared domain, later commercial billing details and cross-organization sharing. Subscription/payment collection is explicitly deferred beyond release one. A later confirmation selects one shared app entry link, not separate coaching domains/subdomains. No additional features are inferred.
- **Affected documents/requirements:** master context, PRD, R-01, roadmap and Hindi review guide.
- **Discussion preference:** ask one question at a time. Do not present the remaining decision list as a bundle of questions.

### D-03 — admin-controlled permissions, 17 October 2026

Admin determines each user's approval and publication permissions independently. Creators may act on their own content only with the corresponding grants. Creating/uploading grants neither permission. A separate person is not universally mandatory. Validation, human QC, correct prior states and audit remain required. Direct-user versus role/group configuration and custom-role UI remain open.

### D-16 — first-release scope, 17 October 2026

Question-bank entry/upload, review and saving questions in the database come first. Test creation and test-paper export are deferred. Keep exact-version foundations for future tests without building test assembly now. This does not authorize coding before the documentation review finishes.

### D-07 — first-release formats, 17 October 2026

All nine formats in [the type specification](QUESTION_TYPES_SPECIFICATION.md) are included. SCQ has four options and exactly one correct answer. Multiple-correct has four options with a correct-option set. Integer is 0–999 inclusive; single digit is 0–9; numerical is 0.00–999.00 inclusive with two decimal places. Matching and assertion–reason are included; the user also confirmed passage-based and multiple-statement in the first release. Type-specific unresolved structures are listed in that specification.

### D-10 — sources and size limits, 17 October 2026

The user included PDF, Word and image uploads, delegated reasonable sizes, and then explicitly accepted 50 MB per document and 10 MB per image. See [upload policy](UPLOAD_AND_ASSET_POLICY.md). Exact extensions, byte semantics and parser resource limits are not settled by this answer.

### D-09/D-13 — detailed AI-managed taxonomy, 17 October 2026

The user wants detailed class/subject/topic/subtopic classification, preserving the previously discussed chapter layer, and primary plus multiple secondary concepts. Their examples of secondary concept one/two do not impose a fixed maximum. Knowledge-tree and concept-based personalized suggestions are future goals; stable concepts and associations are foundations now.

AI generates the initial taxonomy catalogue and directly fills question metadata from it after validation, with provenance and later authorized correction. When a concept is missing, AI may create it with AI-added/admin-review-pending status and use it immediately. Admin receives a notification/review entry and may approve, edit, merge or revoke it. This confirmed workflow supersedes the earlier approval-first choice. Revoke prevents future automatic assignments and preserves published history. See [taxonomy design](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Decision record format

For each resolution, record: decision ID; date; user-approved answer; reason; alternatives considered only if relevant; affected requirements/documents; deferred follow-up. A technical research finding may validate feasibility but does not count as a user decision about product scope.

## Suggested discussion order

1. Confirm product meaning, intended organizations, first release and workflow with D-01/D-03/D-07/D-16.
2. Resolve identities, version semantics, taxonomy and translation representation.
3. Review authentication, stack and foundation deployment assumptions.
4. Set file/OCR/job policies with representative documents.
5. Review AI, exports and production/student requirements before their milestones.

## D-19 — original-file lifecycle, 17 October 2026

User-confirmed: retain original ingestion PDFs/Word/images, show storage analytics to admin, and let admin decide when to delete. Only admin has storage analytics and deletion rights. Faculty may view original sources within their organization. Saved questions and required question assets must survive original deletion. No fixed automatic expiry was requested. Deletion audit, derived-asset references, backup purge and broader privacy/retention policies need implementation design; do not imply originals can always be retrieved after deletion.

## D-11/D-20 — language catalogue and final metadata view, 17 October 2026

User-confirmed: English, Hindi, Gujarati and three or four widely used regional languages; admin can add more. Four defaults selected under this direction: Bengali, Marathi, Telugu and Tamil, based on the historical Census 2011 speaker ordering in the official source linked in [language support](LANGUAGE_SUPPORT.md). The user explicitly named the first three; the four regional defaults are the project selection under their request, not separately named by the user.

User stated the normal UI should show final metadata. Retain internal audit/provenance as already required; do not impose a visible per-field history on the question screen. Dedicated audit access and retention remain separately governed. Single-language-at-a-time display is now confirmed; translation uses a distinct master/new code; detailed QC and UI localization remain open.

### D-15 — one language at a time, 17 October 2026

User-confirmed: one question language displayed at a time is sufficient. Side-by-side English/Hindi or other bilingual rendering is not required. Do not infer that translations are prohibited or automatically generated; generation trigger, identity and selection/switching behavior still need review.

## D-09/D-11 — metadata language, 17 October 2026

User-confirmed: metadata should be filled in the question language; no mandatory English copy. Use stable taxonomy identities distinct from localized labels. This answer resolves metadata language, not the unanswered trigger for generating question translations.

### D-15 — faculty-requested translation, 17 October 2026

User-confirmed: generate translations when faculty wants them. Upload/ingestion must not automatically fan out translations into all supported languages. Preserve source question-version and output language/provenance; selecting an existing translation versus generating another needs clear behavior. Translation identity and detailed approval/quality checks remain open.

### D-15 — source review gate for translation, 17 October 2026

User clarified that faculty-requested translation is available only after question review. Disable and reject translation before source-review completion, and bind the operation to the reviewed source version. This does not by itself require source publication or authorize publication of the translated output. The exact state/event representing completed review must be aligned with the final lifecycle design.

### D-15 — translated-question identity, 17 October 2026

User-confirmed: a translated question gets a new permanent question code. It is a distinct master with its own version history, linked as translation-of to the original master and exact reviewed source version. Corrections to the translated question create versions under its stable code; source history remains unchanged. Idempotent job retries must not create another master/code for the same output. Intentional retranslation/replacement policy and detailed QC remain open. This resolves earlier uncertainty over same-master language variants.

## Independent source/translation updates — confirmed

The user confirmed that original and translated questions may be updated independently. Do not require simultaneous edits or automatically overwrite a translation when its source changes. Each master keeps its own stable code and version history; preserve the translation-of link and exact originating source version. Published corrections create a new version for the affected master. This does not authorize silent mutation of either published version.

## D-07 — matching cardinality clarification, 17 October 2026

User-confirmed: a left-column item may match one or multiple right-column items. Preserve the full match set, not a single right-item field. This answer does not fix list sizes, whether different left items can share a right item, or whether response entry uses four combined options versus direct mappings. Update R-16 and AT-12 alongside the format specification.

## D-07 — matching response options, 17 October 2026

User-confirmed: Match the Column presents exactly four options containing matching combinations. This resolves the earlier direct-mapping versus option-based response question in favor of four options. Preserve the underlying actual matching relationship as well as the four option combinations. Whether exactly one or multiple combination options can be marked correct is not decided by option count. List sizes and reuse of a right item across left items remain open.

## D-07 — matching correct-option count, 17 October 2026

User-confirmed: exactly one of the four matching-combination options is correct. This resolves the previously open correct-option count; multiple matches within a combination remain supported. Preserve the full underlying mapping and reject answer keys selecting zero or multiple combination options for this format. List sizes and reuse of right-column items across left items remain open.

## D-07 — variable matching-column sizes, 17 October 2026

User-confirmed: the number of items in each matching column may vary according to the question. Do not enforce four items per column. The response still contains exactly four matching-combination options with exactly one correct option. Each left item may map to one or multiple right items. Practical count limits, label scheme and right-item reuse across different left items remain open.

## D-07 — no right-item sharing in correct matching, 17 October 2026

User-confirmed: a right-column item cannot match multiple different left-column items in the correct matching. A left item may still match one or multiple right items. Correct mapping sets for different left items therefore do not overlap on the right. This resolves previously open right-item reuse. Do not impose correct-answer semantic constraints on intentionally incorrect distractor choices; item-count limits, labels and unused-right-item policy remain open.

## D-07 — Assertion–Reason option count, 17 October 2026

User-confirmed: Assertion–Reason contains exactly four response options with exactly one correct answer. Preserve separate assertion/reason content and the chosen response key. The option wording/template and supported truth/explanation cases remain open; four options alone do not define a universal truth table or treatment of both-false statements. R-16 and AT-12 are updated.

## D-07 — Assertion–Reason variable option wording, 17 October 2026

User-confirmed: option text can vary by question. Keep exactly four options and exactly one correct answer, but do not require one fixed option template or use a global truth-table enumeration as a replacement for the supplied text. Preserve assertion/reason, option content and answer identity. The earlier option-wording uncertainty is resolved; detailed semantic quality examples remain design work.

## D-07 — Multiple Statement response options, 17 October 2026

User-confirmed: Multiple Statement questions contain exactly four response options with exactly one correct answer. Preserve the separate statements and option content; do not substitute an unrequested direct per-statement answer-entry interface. Number of statements and detailed examples remain open. R-16 and AT-12 reflect this rule.

## D-07 — variable Multiple Statement count, 17 October 2026

User-confirmed: number of statements may vary by question. Do not impose a global fixed count. Keep exactly four response options with exactly one correct answer. Preserve separate ordered statements and their identities so option references remain consistent. Practical count limits, labeling and detailed fixtures remain design work. This resolves the earlier statement-count question.

## D-07 — mixed question types under a passage, 17 October 2026

User-confirmed: a passage may contain questions of different types, including the stated example of SCQ, numerical and integer under the same passage. Apply answer/validation rules independently for each child type; do not impose one format on the entire passage. This does not establish recursive passage nesting or every possible child type. Exact child catalogue, child identity and passage versioning/sharing still require design review.

## D-07 — permanent code per passage subquestion, 17 October 2026

User accepted the recommendation: each passage subquestion has its own permanent question code and all children link to the shared passage. Each child is a separate question master with its own version history. This resolves child identity. It does not decide whether the passage context also needs a human-readable code, how it is reused across groups, or which child types/nesting are allowed.

## D-07 — single-correct set allowed in Multiple Option Correct, 17 October 2026

User-confirmed: a Multiple Option Correct question may have only one correct option. With exactly four options, the correct-option set is nonempty and may contain one or more members. Do not require two correct options or silently change its format to SCQ merely because its answer set has size one. Scoring remains later test-builder scope.

## D-07 — numerical extra precision review, 17 October 2026

User chose flagging rather than automatic rounding. Preserve an over-precision numerical answer (example 12.345) and flag for authorized review; do not silently replace it with 12.35. Keep source/provenance and visible correction need. This does not require failing an entire ingestion job or rounding other numbers in content. Accepted-answer range/tolerance and harmless input-format normalization remain separate design questions.

## D-07 — numerical accepted ranges, 17 October 2026

User-confirmed: a numerical question may have an accepted answer range as well as an exact-value answer mode. Preserve the given range (example 9.79–9.81) without assuming a global tolerance. The agreed 0.00–999.00 value domain and two-decimal precision apply to stored values/endpoints; flag over-precision rather than rounding. Inclusivity/exclusivity and support for multiple disjoint ranges remain open. Student attempt evaluation is still later scope.

## D-07 — inclusive numerical answer range, 17 October 2026

User-confirmed: both endpoints of an accepted numerical answer range are included. For 9.79–9.81, 9.79 and 9.81 are accepted, along with in-range values under the agreed precision policy. This resolves earlier boundary-inclusivity uncertainty; do not introduce a default exclusive boundary. R-16/AT-12 and the type specification are updated.

## D-05/D-07 — solution optional for publication, 17 October 2026

User-confirmed: a question may be published with a correct answer even if no solution/explanation is provided. Solution is optional, not a publication prerequisite. Type-valid answer, complete question content, applicable review/metadata checks and admin-defined publication permission remain required; this answer does not waive them. If a solution is supplied, preserve it as part of the version and apply relevant QC. Other publication-required metadata fields remain under review.

## D-05/D-09 — primary concept publication requirement, 17 October 2026

User-confirmed: a question must have a primary concept tag before publication. Missing primary concept blocks publication, while incomplete drafts remain editable. AI may assign the primary concept directly from the catalogue or create an immediately usable AI-added/admin-review-pending concept under the confirmed policy; catalogue admin approval is not a new prerequisite. Validate concept existence and organization scope. Secondary concepts remain optional unless a later decision explicitly requires them; primary-tag presence alone does not prove content correctness.

## D-05/D-09 — required publication hierarchy, 17 October 2026

User-confirmed: class, subject, chapter and topic are mandatory before publication, in addition to the previously required primary concept and type-valid correct answer. Incomplete drafts remain saveable. Validate organization scope and hierarchy consistency for selected catalogue entries; merely nonempty text does not establish a valid assignment. AI directly fills metadata under the existing policy. Subtopic and other metadata completeness are separate decisions still under review; solution remains optional.

## Subtopic optional at publication — confirmed, 17 October 2026

User-confirmed: subtopic is optional. Its absence must not block publication if class, subject, chapter, topic, primary concept, correct answer and other applicable requirements are met. If a subtopic is assigned, validate its hierarchy and tenant scope. Do not invent a subtopic solely to satisfy a completeness check.

## D-05/D-09 — required publication difficulty, 17 October 2026

User-confirmed: a valid difficulty level on the agreed 1–10 scale is required before publication. AI may fill it directly with provenance and authorized users may correct it. Missing or out-of-scale difficulty blocks publication, while incomplete drafts may be saved. Calibration/definitions and any finer numeric granularity remain design work; presence of a difficulty label alone does not establish correctness.

## D-05/D-09 — required publication Bloom level, 17 October 2026

User-confirmed: a valid Bloom taxonomy level is required before publication. AI directly fills the field with model/prompt provenance and authorized users may correct it. Missing or invalid catalogue values block publication; incomplete drafts remain saveable. Preserve a stable level identity with localized labels and version-scoped metadata. This does not turn an AI-assigned label into evidence of educational quality; calibration/examples remain design work.

## D-05/D-09 — conditional PYQ publication fields, 17 October 2026

User-confirmed: if a question is marked as a previous-year examination question (PYQ), exam name and exam year are required before publication. Incomplete PYQ drafts may be saved but cannot publish without both fields. This conditional requirement does not force non-PYQ questions to carry exam/year values. Retain source provenance and do not fabricate missing exam/year to pass validation. Date, paper code, slot/shift and other PYQ metadata completeness remain separate decisions.

## Optional PYQ detail fields — confirmed, 17 October 2026

User-confirmed: PYQ date, shift/slot and paper code are optional. Populate them when known, retain provenance and leave unknown values absent rather than inventing them. Their absence does not block publication. Exam name and year remain mandatory when PYQ is selected. See the consolidated [publication requirements](PUBLICATION_REQUIREMENTS.md).

## D-05 — correction and re-review loop, 17 October 2026

User-confirmed: when review finds an issue, the question can be returned to its creator for correction and submitted for review again. Preserve content/source identity and review history; returning work is not deletion or automatic creation of a new master. Represent a changes-requested correction loop alongside the existing draft/content-QC/approved/published flow. Authorize return/edit/resubmit actions and bind review decisions to the reviewed revision; published versions remain immutable. Exact role grants, reason/comment requirements, reassignment and separate rejection/withdrawal policies remain open.

## D-06 — globally unique permanent question codes, 17 October 2026

User-confirmed: question code is unique across the whole platform, including different coaching organizations. This supersedes the draft tenant-scoped preference, which was not an approved requirement. Enforce a global database uniqueness constraint with secure random generation and collision retries. This does not create shared question ownership, expose other tenants or permit unauthenticated code lookup. Alphabet/case and code-retirement details remain open; length is now confirmed as eight characters.

## D-06 — exactly eight characters, 17 October 2026

User accepted the recommendation: permanent question code contains exactly eight alphanumeric characters. This resolves the former seven-versus-eight range in favor of eight. Keep platform-wide uniqueness, secure random generation, database collision handling and separation from internal UUID/version IDs. Exact character alphabet/case and lifecycle policies remain design work. The original handover ZIP is preserved unchanged as historical context.

## D-07/D-14 — separate code for a new variant, 17 October 2026

User-confirmed: a new practice variant made by changing values or conditions receives its own permanent, globally unique eight-character alphanumeric question code. It is a distinct question master with its own version history, explicitly linked as variant-of to the original. Preserve source-version and creation/AI provenance where applicable. This does not change the correction policy: correcting an existing question creates a new version under that existing master/code. Automatic variant generation, inheritance of review status and generation permissions are not established by this answer.

## D-13/D-14 — AI variant generation in release one, 17 October 2026

User-confirmed: AI generation of practice variants is included in the first release. Generated variants receive separate masters/new global eight-character codes and variant-of/source-version provenance; they follow normal question QC and authorized approval/publication. Original content remains unchanged. Faculty request is the confirmed trigger; no automatic per-question generation. Source eligibility, generation count/controls and operation permissions remain open. See [AI variant generation](AI_VARIANT_GENERATION.md). This resolves whether the feature is deferred: it is included now.

## D-13/D-14 — faculty-requested variant generation, 17 October 2026

User-confirmed: AI generates practice variants if faculty needs/requests them. Do not automatically generate variants during every upload, ingestion or new-question creation. This resolves the invocation trigger, while source state, operation authorization, count/controls, budget and QC details remain to be specified.

## Variant generation before source review — confirmed, 17 October 2026

User-confirmed: original-question review completion is not required to generate a variant. Faculty may request a variant from an accessible draft/unreviewed source. Preserve the exact source content/version and its review status; source approval is not inherited. Generated variants still enter normal candidate/draft QC and require valid publication fields and admin-granted approve/publish permissions. Translation retains its separate post-review gate; do not apply that gate to variants.

## D-13/D-14 — faculty-controlled variant count/type/difficulty, 17 October 2026

User-confirmed: faculty chooses variant count, can change the target question type, and needs target difficulty selection (1–10). Preserve these controls in the generation plan and AI provenance. Validate output against the target format and reassess answer/options/concepts/difficulty rather than copying source fields. A target setting is not proof of achieved difficulty. Source review completion remains unnecessary. Mixed-target batches are confirmed; practical limits/defaults and operation permissions still need design.

## Mixed-target variant requests — confirmed, 17 October 2026

User-confirmed: one faculty request may generate a mixture of question types and target difficulty levels. The accepted example is two SCQ variants at difficulty 4 plus one numerical at difficulty 7. Store each group/item target and requested count, derive a consistent total and bind output provenance to its requested plan. Validate each output against its own target format. Partial failures must identify affected plan entries rather than silently substituting another type/difficulty or duplicating successful outputs.

## Variants preserve the primary concept — confirmed, 17 October 2026

User-confirmed: practice variants must keep the original primary concept. Question type, requested difficulty and values/conditions may change without changing that main concept. Preserve the stable concept ID and source-version provenance. Validate semantic fidelity rather than merely copying the concept label onto unrelated generated content. Source review is not required; if source primary metadata is missing, resolve it through the existing AI/candidate metadata workflow rather than introducing a new review prerequisite. Other concept/quality checks still apply.

## Additional faculty instructions for variants — confirmed, 17 October 2026

User-confirmed: faculty may enter additional instructions for AI variant generation, such as changing only numerical values or reducing calculation. Keep them with the requested count/type/difficulty plan and AI provenance. Interpret them within the confirmed same-primary-concept and target-format requirements; surface conflicts instead of silently changing requested targets. Instructions do not grant permissions, cross tenant boundaries or bypass QC/publication checks. Exact shared/per-item instruction controls and length limits remain design details.

## D-07/D-13 — AI diagram generation/editing in release one, 17 October 2026

User-confirmed: first release includes AI generation of question diagrams and modification of existing diagrams when needed. Keep reviewable asset output, provenance, same-tenant attachment, preserved originals and version-safe references. Human QC checks diagram/question/answer consistency; no automatic verification or publication. Invocation controls, supported representation/providers/models and evaluation remain open. See [AI diagram assistance](AI_DIAGRAM_ASSISTANCE.md).

## Faculty-requested diagram generation/editing — confirmed, 17 October 2026

User-confirmed: AI diagram generation and editing run only on faculty request. Do not automatically create or modify diagrams during every upload/ingestion/new-question workflow, and do not replace source figures without the requested editing action. Preserve input/output assets, provenance, tenant access, published snapshots and normal QC. Detailed operation permissions, input controls, providers and output representation remain design work.

## D-02 — all three login methods, 17 October 2026

User-confirmed: Google login, email/password and mobile OTP are all required in the first release as alternative sign-in methods. Identity provider/session implementation, account linking, OTP delivery and onboarding remain open. Authentication does not grant organization membership or action permissions. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-02 — admin invites/creates faculty, 17 October 2026

User-confirmed: faculty accounts are created/invited only by admin; public self-signup is not the faculty onboarding route. Authentication alone cannot enroll an uninvited user or grant organization permissions. Preserve organization-scoped invitation/membership and audit. Owner/platform bootstrap, invitation delivery and verified account linking remain separate design questions.

## D-02 — faculty account limited to one coaching, 17 October 2026

User-confirmed: each faculty account belongs to only one coaching organization and cannot switch between multiple coaching memberships. The platform remains multi-tenant, with separate faculty accounts/data for different organizations and runtime isolation. Enforce the single-coaching account scope server-side; hiding a switcher is not sufficient. This faculty rule does not define platform-owner/admin scope or whether the same human may hold separately provisioned accounts; do not silently infer identity-provider/account-merging behavior.

## D-03/D-20 — full own-coaching question-bank visibility, 17 October 2026

User-confirmed: faculty can view the complete question bank of their own coaching organization, not only questions they created or uploaded. Do not apply a creator-only filter to ordinary faculty question-bank visibility. Organization ownership, single-coaching account scope and cross-tenant denial remain unchanged. Viewing the full bank does not itself grant editing, approval/publication, original-file deletion or storage-dashboard rights. Detailed staging/review-state access and edit permissions remain separate policy questions.

## D-03 — admin-granted editing of other faculty questions, 17 October 2026

User-confirmed: admin decides whether a user may edit questions created/uploaded by other faculty in the same coaching. Complete bank visibility does not grant cross-author edit permission. Enforce this independently from approval/publication grants and tenant scope. Published content is never overwritten: authorized corrections create a new version under the existing question code and retain audit/source history. Own-draft editing, exact default grants and edit/approval invalidation details remain governed by the final permission/lifecycle design.

## D-03/D-13 — default upload/manual/AI access, 17 October 2026

User-confirmed after clarification: upload, manual entry and AI tools are available to all faculty by default, without separate per-user admin enable permissions. Enforce active single-coaching membership, tenant scope, configured models/resource limits and existing operation-state rules. Approval, publication, editing another faculty's question and admin-only storage/deletion remain separately controlled. Default AI access does not authorize protected writes to another question. See [confirmed access matrix](PERMISSIONS_MATRIX.md). This supersedes earlier uncertainty about per-user invocation grants for these tools.

## D-03/D-05 — independent admin-granted review/QC, 17 October 2026

User-confirmed: formal question review/QC requires a separate permission granted by admin. Default faculty bank/source viewing, upload/manual entry and AI access do not grant formal review authority. Review, approval and publication are independent grants. A user may perform their own review/approval/publication only when holding the corresponding permissions; no different person is universally mandated. Review permission authorizes reviewed-state decisions/correction-return within the workflow, not protected content edits without the required edit permission. Preserve actor/revision-bound QC evidence and deny unauthorized review transitions.

## D-03/D-05 — any permitted reviewer, no mandatory assignment, 17 October 2026

User-confirmed: any faculty member with review/QC permission may review pending questions in their own coaching. Mandatory per-question reviewer assignment is not required. Present a shared pending-review queue scoped to that organization and enforce the independent review grant. Preserve revision-bound decisions, actor/history and correction-return/resubmission. Concurrent decisions need transactional conflict handling rather than silently overwriting each other. Optional assignment is not a required feature by this answer; default faculty without the review grant cannot complete formal QC.

## D-10/D-12 — bulk PDF/Word/image upload, 17 October 2026

User-confirmed: first release supports bulk upload of multiple PDF, Word and image files in one submission. Preserve per-file validation, source identity/checksum, tenant scope and observable progress/errors; existing 50 MB/document and 10 MB/image limits remain per file. Bulk upload does not bypass staging/QC or imply automatic publication. Exact maximum file count, aggregate bytes, resumable transport and handling of separate paper/answer-key associations remain design work.

## D-10/D-12 — linked paper/key/solution files, 17 October 2026

User-confirmed: question papers and their answer keys/solutions may be separate files and must be linkable for joint processing in the first release. Preserve group identity and independent question/answer/solution source locations; candidates may reference multiple files. Ambiguous/missing/conflicting matches remain reviewable, not fabricated or silently dropped. Manual versus AI pairing and detailed matching policy remain open. See [linked multi-file ingestion](MULTI_FILE_INGESTION.md).

## D-12/D-13 — AI pairing, faculty correction, 17 October 2026

User-confirmed: AI identifies and directly links related paper/key/solution files; faculty may correct the pairing afterward. Do not require manual group selection or confirmation before AI pairing runs. Retain model/matching/source provenance, distinguish file grouping from answer alignment and re-evaluate affected candidate associations when pairing is corrected. Ambiguities remain visible for review; protected question edits and published history still follow existing permissions/version rules.

## D-07/D-13 — on-demand AI fill for missing answers, 17 October 2026

User-confirmed: when an imported question has no answer, faculty can request AI to solve it and fill the answer. On-demand only; no automatic solving for every upload. Preserve model/prompt/source-revision provenance and distinguish AI output from an extracted key. Validate answer format and retain normal QC; generation alone grants neither verified status nor publication. Solutions remain optional. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## D-13 — admin faculty-wise AI usage/cost dashboard, 17 October 2026

User-confirmed: admin needs faculty-wise AI usage and cost reporting. Record tenant, faculty/requester, operation, model/provider and available usage/cost evidence. Separate provider-reported actual cost, calculated estimates and unavailable values; do not show unknown as zero. Dashboard visibility does not itself define budgets or per-user feature gates. See [AI usage/cost dashboard](AI_USAGE_AND_COST.md). Budget thresholds and enforcement remain open.

## D-13 — admin monthly budget per faculty, 17 October 2026

User-confirmed: admin can configure a monthly AI spending limit for each faculty member. Keep tenant/faculty attribution, budget amount/currency/period and auditable admin changes. This is spending control, not a reversal of default faculty AI tool access. Whether exceeding the limit only warns or blocks new AI work, exact monthly reset semantics, concurrency reservations and cost-reconciliation policy remain open; do not assume a numerical default or threshold behavior.

## D-13 — AI budget warning/stop thresholds, 17 October 2026

User-confirmed: issue a warning when a faculty member reaches 80% of their configured monthly AI budget, and stop new AI work at 100%. Enforce the stop at provider dispatch/service boundaries, not only a disabled UI button. Preserve completed results, saved questions and non-AI work. Do not assume in-flight requests are cancelled or final provider bills can never exceed a cap when usage arrives late; define reservation, reconciliation and in-flight handling explicitly. Warning delivery/deduplication and exact monthly reset semantics remain design work. This resolves the earlier warning-versus-blocking choice.

## D-13 — monthly budget resets on first day, 17 October 2026

User-confirmed: monthly budget usage starts afresh on the first day of every calendar month. Preserve prior-month usage/cost and audit history; reset the current-period counter, not historical records. Apply the configured faculty limit to the new period. This is not a rolling 30-day window. Exact organization timezone, in-flight request attribution at month boundaries and cost-reconciliation rules remain implementation design work.

## D-13 — each coaching supplies its AI keys, 17 October 2026

User-confirmed: each coaching supplies its own AI provider API keys instead of using centrally shared platform keys. Resolve secrets per organization for all API/worker operations, preserve credential-reference provenance without secret exposure, and never fall back to another coaching's/shared key. Provider billing belongs to the configured coaching account; application usage/budgets cover recorded app calls. Provider catalogue, secret manager, rotation/validation UX and fallback ordering/attempt limits remain design work; automatic fallback uses only the same coaching's configured keys. See [coaching-owned credentials](TENANT_AI_CREDENTIALS.md).

## D-13 — coaching-admin model catalogue configuration, 17 October 2026

User-confirmed: each coaching admin can enable/select which models from the platform-supported catalogue are available in that coaching and set its default model. Faculty choose from that coaching's enabled, supported, operation-compatible models; default is available for quick use. Resolve only that coaching's provider keys. Tenant configuration cannot introduce arbitrary untested models or bypass capabilities/resource budgets. Automatic fallback with a visible error is confirmed; per-operation default details, fallback order/attempt limits, catalogue updates and UI remain design work.

## D-12/D-13 — automatic fallback and error visibility, 17 October 2026

User-confirmed: when the selected AI model fails, show a safe, understandable error/failure status and automatically try another enabled, operation-compatible model for the same coaching. Record original selection, failure, fallback attempt and actual model/provider used; do not hide the failure because fallback succeeds. Use only that coaching's configured credentials. Respect supported capabilities, bounded retry/fallback policy and budget reservations; never bypass missing authorization, tenant checks or the 100% budget stop. Preserve successful partial outputs and idempotency. If alternatives fail/unavailable, show an actionable terminal error without fabricating output. Exact fallback order, attempt limits and detailed UI remain design work.

## D-14 — automatic duplicate checks on new questions, 17 October 2026

User-confirmed: every new question is automatically checked against its own coaching's existing question bank for duplicates. Shared downstream rules cover manual/import/generated candidates. Preserve tenant-safe candidate evidence and sources; human QC confirms duplicate/variant/translation disposition before canonical/merge decisions. Do not silently reject/delete uncertain candidates or collapse distinct variants/translations. Exact matching policy/thresholds and final confirmed-duplicate treatment remain open. See [duplicate policy](DUPLICATE_AND_VARIANT_POLICY.md).

## D-14 — exact duplicate intake reuses existing master/code, 17 October 2026

User-confirmed: after human review confirms an intake candidate is exactly an existing question, link the new source/provenance to the existing question instead of creating a new master/code. Keep the existing permanent code and matching-version evidence; preserve source/candidate records and review audit. Appending source evidence must not silently overwrite content, answer, solution or published metadata. Conflicting keys or non-identical content require visible review rather than forced duplicate treatment. Existing published duplicate masters/canonical merge policy remains separate; variants/translations retain their confirmed distinct codes.

## D-10/D-11 — legacy Word DOC support, 17 October 2026

User-confirmed: first release supports both legacy .doc and modern .docx Word inputs. Apply the accepted 50 MB/document per-file limit and shared bulk/staging workflow. Keep uploaded original bytes; any conversion/extraction artifact needs source/tool/version provenance and visible warnings. Choose and verify an appropriate legacy parser/converter rather than assuming the proposed DOCX extractor covers legacy files. Preserve equations, tables, figures and source anchors where possible; uncertain/lost structure must remain visible for correction. No converter has been selected, installed or tested.

## D-11 — handwritten source support, 17 October 2026

User-confirmed: handwritten question photos/scans are included in the first release. Use shared extraction/staging/QC with original/source preservation; flag uncertain text, equations, units and diagrams instead of inventing or silently dropping content. OCR/vision engines, per-language quality, corpus and targets must be evaluated; no accuracy is claimed. Source-figure extraction is distinct from faculty-requested diagram generation/editing. See [OCR and handwriting](OCR_AND_HANDWRITING.md).

## D-12 — background processing and faculty cancellation, 17 October 2026

User-confirmed: faculty may cancel their own running file-processing job. Jobs run in the background; faculty can upload new files and perform other app work while earlier processing continues. Use durable independently traceable job/stage state with resource/budget limits, not a blocking UI request. Cancellation is not source deletion or silent removal of published/reviewed content. Partial-output retention, in-flight acknowledgement and completion races need detailed semantics. See [background jobs/cancellation](BACKGROUND_JOBS_AND_CANCELLATION.md).

## D-12 — preserve extracted drafts on cancellation, 17 October 2026

User-confirmed: cancelling a processing job keeps questions already extracted as draft work. Preserve source/candidate identity, progress, warnings and audit; do not discard completed output or alter already reviewed/published states. Cancellation stops further work according to the acknowledged stage contract, not deletion of originals or saved questions. Retry/resume behavior must not duplicate retained candidates/masters; exact cancelled-job restart UX remains open.

## D-05/D-19 — admin and creator may archive, 17 October 2026

User-confirmed: archive removes a question from the active bank while retaining content/history. Admin may archive questions in their own coaching, and creator faculty may archive their own question. Complete-bank view or cross-author edit permission alone does not grant archive authority over other creators' questions. Preserve code, immutable published versions, assets, sources/audit and historical references; archival is not physical deletion or admin-only original-file deletion. Restore behavior remains open. See [question archival](QUESTION_ARCHIVAL.md).

## D-05/D-19 — restore by admin and creator, 17 October 2026

User-confirmed: both admin and creator may restore archived questions. Admin acts within their coaching; creator acts on their own question. Keep the existing code, content/versions/provenance and archive/restore audit. Restoring availability is not automatic approval/publication of an unreviewed draft or authority to overwrite published content. Detailed state/eligibility and concurrency handling remain design work.

## D-09/D-20 — video solution as link, 17 October 2026

User-confirmed: video solutions use a stored external video link; video-file upload/hosting is not required for the first release. Video solution metadata remains optional under the handover. Validate safe URL structure and preserve the link in version-scoped metadata; do not fabricate a video URL or claim external content is hosted/archived by this platform. Existing edit permissions and published-version rules apply to link changes. Link/player UI details remain design work; no streaming service or provider has been selected.

## D-07/D-20 — three equation input methods, 17 October 2026

User-confirmed: manual equation entry/editing supports visual controls, LaTeX code and MathML code in the first release. Apply shared rich content to relevant stem/options/solution/passage/statements/matching fields, preserving original expression source, preview meaning, multilingual text and version history. Canonical storage, supported syntax/conversion and editor/renderer libraries remain design work; do not claim lossless interchange or silently discard unsupported markup. See [question content editor](QUESTION_CONTENT_EDITOR.md).

## D-09 — single chapter/topic tagging, 17 October 2026

User-confirmed: a question has only one chapter tag and one topic tag, not multiple chapters/topics. Required chapter/topic classification at publication means one valid selected value of each; incomplete drafts can still omit required values until ready. Preserve optional subtopic and the separately confirmed primary plus multiple secondary concept associations. Multiple concepts do not authorize hidden extra chapter/topic tags. Cross-branch concept association rules remain design work; do not silently remove the multiple-concept requirement.

## D-13 — AI checking of existing answers/solutions, 17 October 2026

User-confirmed: faculty-requested correctness checking of existing answers and available solutions belongs in the first release. This is separate from filling a missing source answer. Preserve findings and revision/model provenance under existing tenant, budget and background policies. It does not automatically modify content, complete human QC or approve/publish; solution remains optional. Detailed badge criteria and whether AI should suggest corrections remain open. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## D-13 — flag, suggest and opt-in direct AI correction, 17 October 2026

User-confirmed: show suspected errors and corrected answer/solution suggestions; if faculty opts in, AI may apply corrections directly and must also display the changes. This supersedes the earlier unresolved correction-suggestion question, not the existing no-silent-overwrite, permission, source-preservation or published-immutability rules. No opt-in leaves existing content unchanged. Applied corrections need current edit authority, type validation, revision-conflict handling and provenance. Published corrections keep the same master/code and create a new editable version for normal QC/approval/publication. Direct-correction opt-in is confirmed separately for one question at a time; a batch-wide opt-in is not allowed. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## D-13 — direct AI correction per question only, 17 October 2026

User-confirmed: faculty chooses direct correction for one question at a time. Bind opt-in to that question and its input revision; do not use one selection to authorize writes to multiple questions or remember it as an automatic preference for subsequent questions. Existing correction visibility, edit permissions, source/history preservation, validation, conflict and version/QC rules remain. This decision does not restrict the separately confirmed bulk upload or redefine other AI operations.

## D-07 — unused right-column distractors allowed, 17 October 2026

User-confirmed: right-column items may remain unmatched in the correct mapping, including three left items/five right items with two unused distractors. Do not enforce full coverage of the right list. Preserve one-or-more matches per left item, no sharing of a right item across different left items in the correct mapping, variable column counts and exactly four combination options with one correct. This resolves the earlier unused-right-item question; practical limits and labels remain design work.

## D-09/D-13 — first-release AI prerequisite links, 17 October 2026

User-confirmed: AI should create links specifying which concept is needed before another in the first release. These are directed concept relationships, distinct from taxonomy parents and question primary/secondary tags. Use stable tenant-scoped endpoints with graph revision and model/source/change evidence. Student recommendation delivery/mastery analytics remain later. Immediate link activation/admin notification and later admin approve/correct/revoke are confirmed in the following decision; exact cycle disposition and educational validation remain design work. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## D-09/D-13 — immediate AI prerequisite links with admin control, 17 October 2026

User-confirmed: AI-created prerequisite links follow the immediate-use concept workflow. Add validated links as AI-added/admin-review-pending, notify admin and continue without prior approval. Admin may later approve, correct or revoke a link. Keep graph revisions, AI/actor provenance and earlier relationship evidence; revoking changes active graph availability rather than deleting concepts/questions or rewriting published content. Structural/tenant checks remain required and student recommendations remain later. No additional faculty graph-edit grant is inferred. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## D-09 — faculty graph view and concept-to-question navigation, 17 October 2026

User-confirmed: first release provides faculty a graph view of the knowledge tree and lets them click a concept to open linked questions. Use own-coaching stable concept IDs and primary/secondary question assignments with existing bank/status permissions and tenant-safe counts/navigation. Viewing does not grant graph editing or question edit/QC/approve/publish. Provisional links/nodes should remain visibly review-pending and revoked links absent from active view. Student recommendation delivery and mastery analytics remain later. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## D-09 — no cross-subject prerequisites, 17 October 2026

User-confirmed: prerequisite links connect concepts within the same subject only; cross-subject relationships such as Maths-to-Physics are not permitted. Apply equal stable subject context and coaching validation to AI-created links, admin corrections and active graph queries. This does not settle cross-class/cross-chapter relationships or restrict primary/secondary question concepts beyond previous decisions. Keep graph revisions and revalidate affected links when concept subject context changes. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## D-09 — cross-class prerequisites within the same subject, 17 October 2026

User-confirmed: concepts in different classes may have prerequisite links when they belong to the same subject/coaching, such as Class 11 → Class 12. Different class IDs alone must not block storage, activation or graph traversal. Retain endpoint class context and stable concept/subject identity without changing question classification or permitting cross-subject edges. Existing AI provisional activation/admin notification/correction, tenant validation and history policies apply. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## D-07 — numerical questions allow only one range, 17 October 2026

User-confirmed: no multiple separate accepted ranges for a numerical question. Support one exact value or one inclusive range, retaining the agreed 0.00–999.00 domain/two decimals and extra-precision flagging. This resolves the earlier multiple-range question. Preserve and flag multi-range imported/AI evidence for correction rather than silently picking, merging or expanding ranges. Such a key cannot pass publication validation until resolved; student grading remains later. See [question formats](QUESTION_TYPES_SPECIFICATION.md).

## D-07 — no separate numerical-answer unit field, 17 October 2026

User-confirmed: a numerical answer does not need a separate optional unit field. Keep one exact value or one inclusive range under the established numeric bounds/precision. Absence of an answer-unit field cannot block saving/review/publication. Preserve units in original source evidence, question text/equations/figures and available solutions; do not infer permission to strip them or silently convert/rescale an extracted value. Student grading remains later. See [question formats](QUESTION_TYPES_SPECIFICATION.md).

## D-09/D-03 — new concepts created only by admin and AI, 17 October 2026

User-confirmed: only admin and AI may create new concepts; faculty cannot add a concept manually. Keep existing concept selection/authorized question-tag corrections distinct from catalogue creation. AI may add missing concepts during faculty processing under the established immediate provisional activation, admin notification and later review/merge/revoke policy. Use trusted service/worker authorization and actual actor/model evidence, not a client-supplied AI identity flag. The next confirmation extends this creation restriction to the other hierarchy node types. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## D-09/D-03 — hierarchy entries created only by admin and AI, 17 October 2026

User-confirmed: class, subject, chapter, topic and subtopic creation is restricted to admin and the authorized AI taxonomy workflow, just as for new concepts. Faculty selects existing entries under applicable question-edit permissions; free-text assignment or a direct request cannot implicitly create a catalogue entry. Validate tenant/parent context and retain stable identities, initiating-user/AI/admin provenance and published snapshots. This decision concerns creation authority and does not change optional subtopic or the confirmed concept/prerequisite provisional-use policy. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## D-02/D-03 — multiple admins in one coaching, 17 October 2026

User-confirmed: one coaching may have multiple admins. Preserve individually authenticated membership/authority and actor-specific audit rather than a shared login or one-admin uniqueness rule. Organization ownership and tenant boundaries remain. The following confirmation establishes a principal Owner/Admin who appoints/removes the other admins; bootstrap, ownership transfer/recovery and detailed removal effects remain design/review work. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-02/D-03 — principal Owner/Admin manages other admins, 17 October 2026

User-confirmed: each coaching has a main Owner/Admin with authority to add/remove the other admins. Keep this authority organization-scoped and distinct from ordinary admin/faculty role access, with current-actor/target checks and role-change audit. Principal ownership does not bypass question QC, independent approve/publish checks or published immutability. Owner-initiated transfer to another same-coaching admin is confirmed in the following decision; bootstrap/recovery, exact transfer flow and precise role-removal/residual-membership mechanics remain open; no actual account changes have been performed. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-02/D-03 — ownership transfer allowed, 17 October 2026

User-confirmed: principal Owner/Admin may transfer ownership to another admin within the same coaching. Preserve organization-owned questions/data, historical actor attribution and tenant scope. Design the handover against current-owner and active-target checks with one resulting principal owner, atomic failure/conflict handling and old/new-owner audit. The following confirmation retains the former Owner as regular admin; bootstrap/recovery and exact acceptance/reauthentication mechanics remain open. This is a documented capability, not an account action. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-02/D-03 — former Owner remains regular admin, 17 October 2026

User-confirmed: after ownership transfer the outgoing Owner stays a regular admin of the same coaching. The incoming Owner holds principal-owner authority; the outgoing Owner can no longer appoint/remove admins or transfer ownership using their previous status. Preserve ordinary-admin membership, organization data and historical attribution as part of the handover; failed transfer preserves the original roles. This does not decide residual membership when an ordinary admin role is separately removed. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-02/D-03 — Owner selects admin demotion or app removal, 17 October 2026

User-confirmed: Owner decides whether another admin becomes normal faculty or is removed from the coaching app. Conversion preserves faculty membership under existing grant rules and removes admin authority; app removal leaves no coaching access. These are explicit alternatives, not an automatic demotion on every removal. Preserve coaching questions/assets, attribution, usage and audit. This does not alter ownership-transfer retention; ordinary faculty-removal authority is confirmed in the following decision. Session/in-flight job, recovery and underlying identity-cleanup details remain design work; no real account action has occurred. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-02/D-03 — all admins can remove ordinary faculty, 17 October 2026

User-confirmed: all coaching admins may remove ordinary faculty from their coaching app. Enforce current actor/target membership and role, revoke coaching access and preserve organization content, attribution, usage and audit. A target currently holding admin/Owner authority is outside the ordinary-faculty removal action; other-admin demotion/removal stays Owner-only. Prevent stale-role and cross-tenant bypasses. Detailed revocation, cleanup and reinstatement mechanics remain design work; no real account action occurred. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-01/D-02/D-03 — platform admin creates coaching and first Owner, 17 October 2026

User-confirmed: platform admin provisions new coaching organizations and their first principal Owner/Admin; coaching self-signup is excluded. Distinguish platform authority from tenant Owner/admin/faculty membership and normal login, with actor/organization/first-owner audit and consistent retry-safe provisioning. Coaching Owner then manages other admins. Initial platform-admin setup, owner invitation/verified identity activation and recovery remain implementation design; this onboarding decision alone grants no general tenant access; the following confirmation adds explicit platform question-bank viewing, not original-source/credential or write scope. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-01/D-02/D-03 — platform admin may view all question banks, 17 October 2026

User-confirmed: platform admin may view the question banks of every coaching. This is an explicit platform-read capability with coaching ownership/context and actor/target audit, separate from tenant membership. Ordinary tenant users remain isolated; use a restricted application/RLS read design rather than blanket database bypass. Viewing alone does not grant edit/QC/approve/publish/delete, cross-coaching copy/export, original ingestion-file, provider-key or tenant AI-operation authority. These scopes remain separate. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-01/D-02/D-03 — platform admin may edit coaching questions, 17 October 2026

User-confirmed: platform admin can also edit questions across coaching banks. Keep explicit platform-edit/target-coaching authorization, current revision, content/type validation, tenant-consistent references and editor before/after audit. Retain original coaching ownership and creator attribution; published corrections create a new editable version under the same code while preserving prior snapshots. Changed revisions do not inherit earlier approval/verification or auto-publish. Edit scope alone does not grant QC/approve/publish, source/secret access, archive/delete, cross-coaching copy/export or tenant AI dispatch. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-01/D-02/D-03 — platform admin has full access, 17 October 2026

User explicitly confirmed “full access of everything,” including approval and publication. This supersedes earlier limited platform onboarding/read/edit scope and open exclusions. Platform admin may use every supported app capability across coachings: questions/QC/approve/publish, roles/Owners/users, originals/storage, taxonomy/languages, AI credential/configuration/budget/job controls and analytics. Ordinary tenant role restrictions remain within coachings. Preserve required validation, immutable published versions, data ownership/attribution, principal-owner consistency, credential handling and audit. Full authority does not invent unimplemented hard-delete/impersonation/copy workflows or move deferred test/student features into release one. See [full platform access](PLATFORM_ADMIN_ACCESS.md).

## D-01/D-20 — per-coaching name and logo, 17 October 2026

User-confirmed: each coaching can display its own name and logo in the app. Include tenant-owned branding settings without changing organization/question identity or historical attribution, with safe assets/cache and accessible missing-logo fallback. The later permission confirmation restricts name/logo changes to platform admin; coaching Owner/admin/faculty cannot edit branding. Custom domains, color themes, platform-brand removal and later export branding are not confirmed by this answer.

## D-01/D-03/D-20 — coaching branding edited only by platform admin, 18 October 2026

User-confirmed: coaching admins cannot change their own coaching name/logo. Platform admin manages these settings under full access; no coaching Owner/admin/faculty branding-write grant is introduced. Enforce this on dedicated settings and generic organization/asset writes, not just by hiding controls. Preserve tenant identity, question codes/attribution and actor/target change audit. No app branding has been changed.

## D-01/D-02/D-20 — common app website/link, 18 October 2026

User-confirmed: all coachings use the same website/app entry link, rather than separate links per coaching. No custom tenant domains/subdomains are needed for the first release. Resolve coaching context/branding from authenticated membership and retain the one-coaching faculty scope; platform admin may select a target coaching under full authority. Shared URL/session/cache must not mix tenant data or branding. Actual domain/hosting/deployment and billing remain design/product work; ordinary in-app resource links are unaffected. No domain or website has been provisioned.

## D-01/D-20 — subscription/payment collection deferred, 18 October 2026

User-confirmed: coaching subscription/payment collection will be added later. First-release onboarding/question-bank access must not require a payment/subscription setup. Pricing/plans, gateway/invoicing and renewal/access-enforcement policy are uncommitted future scope. This does not defer coaching-owned provider credentials, faculty-wise AI cost/usage or 80% warning/100% stop monthly spending controls, and does not promise permanent free access.

## D-01/D-18/D-20 — small initial faculty group, 18 October 2026

User describes initial faculty count as “very less.” Record a small initial group, with no exact count, concurrency target or hard user cap. This does not change the initial one-coaching/multi-coaching-ready rollout, feature scope, role policies or background-job requirements. Corpus size and quantitative performance/deployment sizing still need evidence; no benchmark has run.

## D-01/D-14/D-18/D-20 — question bank in lakhs, 18 October 2026

User-confirmed: expected question-bank size is in lakhs. This complements the small initial faculty group; it does not establish exact corpus/concurrency/storage limits, numeric speed targets or existing implementation capacity. Plan bounded navigation/filter/count, own-coaching duplicate candidate retrieval and background imports with representative evaluation. Initial bulk-load timing and file/asset distribution remain open. See [capacity and performance](CAPACITY_AND_PERFORMANCE.md).

## D-01/D-10/D-11 — existing question sources available, 18 October 2026

User confirms existing PDF/Word/image question material is available for the intended bank. This is reported source availability, not a verified count, inspected format distribution or completed upload/extraction of the lakh-scale corpus. Representative source inventory and selectable-text/scan/handwriting/layout/answer-key samples remain the next evidence needed for ingestion/OCR design. Current scope and limits remain unchanged.

## D-10/D-11 — both text and scanned sources, 18 October 2026

User-confirmed: existing material includes both selectable/text-based files and scanned PDFs/photos. Keep text extraction and OCR paths in first-release ingestion; representative evaluation must cover both, not select one as the sole source mode. Proportions, mixed-page layouts, handwriting prevalence, quality/throughput and exact engine choices remain unverified. No source corpus has been parsed by this requirements update.

## D-21/D-22 — adaptive ingestion now, teaching platform later, 18 October 2026

Source samples will be shared later; documentation continues now. Many files share one layout and many others share another. First-release AI extraction should learn unknown layouts, save/version patterns and automatically reuse compatible new files to reduce repeated extraction tokens/time, supporting handwritten questions and solutions. Validate coverage/structure and use AI fallback on drift, without copying old answers or claiming free recognition. Separate coaching libraries and platform-admin complete-dataset sharing are confirmed by D-23; copy/sync semantics and numerical savings remain open. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md).

Later faculty courses, live classes, recorded sessions and AI teaching/concept videos personalized to student need/current level are confirmed. Keep them future modules with detailed contracts and educational evidence deferred. See [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).

## D-21/D-23 - separate libraries and complete dataset sharing, 18 October 2026

User-confirmed: patterns are different/separate for each coaching. Platform admin may choose to share the complete coaching database/dataset, including patterns and associated material, with another coaching. Preserve default isolation and make this an explicit platform-only operation, with complete dependency/source/target mapping, attribution/history and global-code/version integrity. One-time independent copy versus continued updates is the next product question; account/configuration/credential category semantics and target conflicts still need a contract. No sharing/data movement has occurred. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## D-23 - independent initial copy and destination autonomy, 18 October 2026

User-confirmed: share a one-time initial independent copy so the receiving coaching can use/change it according to its needs. No automatic source/destination synchronization follows. Destination-owned question/pattern/taxonomy/asset identities preserve source provenance; new copied masters need new globally unique eight-character codes, while existing destination matches need the reviewed conflict policy. Retain required assets independently so source cleanup does not break the completed copy; preserve source/history and normal destination editing/version/QC rules. Users/credential/configuration category treatment, imported publication eligibility and nonempty-target conflicts remain contract details. No actual copy has occurred. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## D-23 - separate users and API keys for destination, 18 October 2026

User-confirmed: copy questions, sources, taxonomy and patterns as educational content; set up the receiving coaching's users and API keys separately. Do not clone source login accounts/sessions, active membership/privilege grants or provider secrets. Keep creator/reviewer/AI evidence as provenance, not destination access or fresh spending. Destination ownership/branding remains its own configuration. Normal onboarding and destination-key/budget rules apply; imported publication eligibility and target conflicts remain open. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## D-23 - copied published questions stay published, 18 October 2026

User-confirmed: already published source questions remain published in the independent initial copy; no mandatory new destination review is required solely for copying. Preserve exact content/dependency/version mapping, imported source QC/publication evidence and platform copy audit without copying reviewer accounts or fabricating new local approvals. Do not promote nonpublished source work or altered/incomplete output through this path. Later destination edits create another editable version under its own code and use normal QC/approval/publication. No publication or dataset operation has been performed.

## D-03/D-09/D-13 - admin alerts in app and email, 18 October 2026 [Superseded channel/contact policy; current rule is in-app only]

User-confirmed: AI-added concepts and prerequisite links notify admin through both app and email. Keep authenticated review/provenance, immediate provisional use and ongoing processing independent of mail delivery. Deduplicate retry/replay and retain failed delivery state without losing app review items. Which coaching admins receive the notifications, timing/digest and provider mechanics remain open. This is a software requirement only; no messages have been sent.

## D-03/D-09/D-13 - all coaching admins receive taxonomy alerts, 18 October 2026 [Superseded channel/contact policy; current rule is in-app only]

User-confirmed: AI concept/prerequisite notifications go to all active admins of the originating coaching, including Owner, via app and email. Do not silently notify only Owner or all platform/other-coaching admins. Preserve current-role access, per-recipient channel/read states and event deduplication; shared review state is separate. Email contact requirements, timing/digest/provider and new-admin historical visibility remain design work. No messages have been sent.

## D-02/D-03/D-09 - mandatory admin email, 18 October 2026 [Superseded channel/contact policy; current rule is in-app only]

User-confirmed: every coaching admin including Owner needs an email address so all receive required email notifications. Treat it as required contact data in onboarding/promotion/profile validation, independent of Google/email-password/mobile-OTP sign-in. Faculty email policy is unchanged. Verification/change/recovery and digest/provider mechanics remain design work; bounce/failure cannot become fabricated success or block valid tagging. No account or mail action occurred.

## D-02/D-03/D-09/D-13 - in-app-only correction, 18 October 2026

User explicitly revoked email notifications: no notification emails now, only in-app alerts. This supersedes the earlier dual-channel policy and the extra admin/Owner email-contact mandate introduced solely to deliver those alerts. Keep all active admins of the originating coaching including Owner as app recipients. No email delivery/outbox/digest/provider work is required for this notification feature. Existing Google/email-password/mobile-OTP login and identity requirements are unchanged; do not remove actual auth/contact data. Keep current-role access, per-user read state, shared review-state separation, provenance and idempotent alert creation. No mail or account action occurred.

## D-02/D-03 - one user account across login methods, 18 October 2026

User-confirmed: link Google, email/password and mobile OTP to the same application user so any configured method opens the same membership/permissions/history. Keep one canonical budget/attribution identity. Verify account/method control; do not merge roles/data just because email/phone matches, bypass single-coaching scope or restore revoked access. This does not require all methods on every login or reinstate notification emails/mandatory notification-email contact. Provider, linking/change/recovery and session/multi-device mechanics remain design work.

## D-02/D-03 - simultaneous mobile/laptop login, 18 October 2026

User-confirmed: one account may remain logged in on mobile and laptop simultaneously. Keep separate sessions tied to the canonical identity with common membership/grants/history/notifications/budget. A second legitimate login must not automatically evict the first; current-role revocation and revision/idempotency controls apply on every device. No exact device cap, session lifetime or active-device/logout UI is decided. No sessions/account changes have occurred.

## D-02/D-20 - no user-facing device manager, 18 October 2026

User declined logged-in-device listing and selecting a remote device to log out. Exclude that UI from the current release while retaining ordinary current-session logout, simultaneous mobile/laptop access and technical session expiry/current-role revocation. No hard device cap or lifetime is selected. No sessions/accounts were changed.


## Initial AI provider scope - confirmed 18 October 2026

User-confirmed (18 October 2026): first-release AI provider support includes Google, Anthropic, OpenAI and OpenRouter, with an extensible adapter/catalogue design for adding more providers later. Each coaching configures its own credentials; existing enabled-model/default selection, compatible automatic fallback with visible failure, usage provenance and budget controls continue. Provider selection does not mean credentials are available or integrations tested. Specific API products, model identifiers, operation capabilities, data handling, prices and routing/attribution details require current official-source verification during design. Adding a provider later requires an implemented and validated adapter/catalogue entry; it is not arbitrary endpoint execution.


## Local development hosting - confirmed 18 October 2026

User-confirmed (18 October 2026): the development app will be hosted on this PC. Production hosting is deferred; do not infer public PC hosting, remote faculty access, a purchased cloud account or a production deployment. The assistant should propose a local development setup with persistent data/assets, background jobs and configuration boundaries compatible with later hosting. Stack/runtime/resource compatibility and representative performance are not verified. No dependencies have been installed and no server or application has been started.

The monthly hosted-server/storage budget question is deferred with production hosting; this is a planning consequence, not an approved zero-cost or unlimited budget. Coaching-owned AI APIs and their usage/budget controls remain separate. The current interview has no further required user questions; design consolidation and document review must precede code.
