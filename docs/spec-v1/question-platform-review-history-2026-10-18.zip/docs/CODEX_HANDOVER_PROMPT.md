# Codex Handover Prompt

## Current task and precedence — 17 October 2026

The user confirmed no prior code exists. Their latest instruction is to understand requirements and prepare proper documentation **before** implementation. The old repository-audit prompt in the original ZIP is historical context; it does not establish that code exists or authorize scaffolding now.

Current work is documentation review: read the master context, decisions and roadmap first, then the complete documentation index. Preserve agreed decisions, identify open choices and use the requirement/decision IDs. Ask focused product questions and record answers; do not treat recommendations as approved choices.

When documentation affecting the next slice is reviewed, agree that slice with the user and build only within that scope. Verify actual tool/dependency availability at implementation time. Do not claim any application checks, migrations, RLS controls, authentication, extraction or AI operations work without executed evidence.

Current review outputs are requirements traceability, workflows/permission draft, decision register, API outline, acceptance plan, Hindi product review guide and documentation readiness. Content-schema examples and exact transition/role grants are intentionally pending product answers rather than silently invented.


## Implementation guardrails for later use

- Preserve organization ownership, shared manual/import processing, distinct identities, immutable publication and exact-version test selection.
- Keep tenant isolation and human-authorized QC throughout API, worker and storage paths.
- Use the controlled AI catalogue with provenance; do not trust suggestions as authoritative facts.
- Do not access production systems, expose unauthenticated development endpoints or commit secrets.
- Do not delete data, reset databases, force-push or overwrite an existing implementation without applicable authorization.
- Before a command that changes database data, explain its target and impact and obtain required approval.
- Run meaningful checks on safe disposable targets and record commands/results; mark unavailable checks explicitly.
- Make small reviewable changes and update requirement/test/document references together.

## Expected continuation report

State the reviewed decisions, remaining blockers/deferred choices, agreed next scope and actual verification evidence. A design proposal is not a user-approved decision or a test result.

## Latest confirmed product scope

One initial coaching institute with multi-tenant architecture; admin-defined approval/publication grants; question-bank entry/upload/review/database saving first; test creation/export later. All nine formats, PDF/Word/images and 50 MB/document plus 10 MB/image limits are confirmed. Detailed primary/multiple-secondary concepts and AI-created taxonomy/tagging are required. Immediate provisional AI concept activation with admin notification and later correction/revocation is confirmed and replaces approval-first. AI fills metadata directly. Originals are retained until admin deletion; only admin sees storage analytics/deletes, while faculty can view original sources. Read the dedicated type/upload/taxonomy specifications and the live decision register before continuing.

## Confirmed AI and original-source lifecycle update

AI directly fills validated editable metadata without a per-field approval gate. New concepts may be added and used immediately with AI-added/admin-review-pending status. Notify admin for later approve/edit/merge/revoke; revocation stops new automatic use and preserves published snapshots. This supersedes the earlier approval-first rule; question approve/publish permissions remain separate.

Retain original source files until admin chooses deletion. Only admin can see storage analytics and delete originals; faculty can view their organization's originals. Original deletion must preserve saved questions and independently retained required diagrams/assets, show source-unavailable status honestly and record the deletion. No automatic expiry has been selected. See [source lifecycle](SOURCE_STORAGE_AND_RETENTION.md).

## Language catalogue and metadata display review update

English, Hindi and Gujarati were explicitly requested, plus three or four widely used regional languages. Initial four regional defaults are Bengali, Marathi, Telugu and Tamil, selected under that criterion. Admin may add more languages. See [language support](LANGUAGE_SUPPORT.md) for source basis and capability verification. Display one language at a time; each translation has a new master/code linked to the source; detailed QC remains open and generation is faculty-requested after source review.

The normal question view shows final/current metadata. Internal audit and AI provenance remain required; a per-field change timeline is not a required normal-screen feature.
