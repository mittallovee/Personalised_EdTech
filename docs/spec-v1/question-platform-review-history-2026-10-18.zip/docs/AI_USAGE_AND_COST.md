# AI Usage and Cost — Admin Dashboard

Status: faculty-wise AI usage/cost visibility for admin confirmed on 17 October 2026. Admin-configurable monthly per-faculty budgets are confirmed; warning at 80% usage and stopping new AI work at 100% are confirmed; calendar-month reset on the first day is confirmed; timezone/accounting details, providers and rates remain under review. No usage ledger or dashboard has been implemented.

## Confirmed requirement

Admin needs a dashboard showing each faculty member's AI usage and associated cost within their coaching. Default access to AI tools remains available to faculty; no per-user feature-enable flags are required. Admin may separately configure each faculty member's monthly spending limit; warn when budget usage reaches 80%, and stop new AI work at 100%.

## Proposed reporting dimensions

- Faculty/requesting actor, with organization scope enforced.
- Operation such as metadata tagging, taxonomy discovery, file pairing, variant generation, diagrams, translation or answer assistance.
- Provider/model and operation/run status.
- Available usage units: requests, tokens or provider-specific image/other units.
- Cost and its evidence status: provider-reported actual, calculated estimate, or unavailable.
- Time filters and useful aggregates; exact dashboard layout is design work.

Record AI work initiated by an ingestion job against its requester where valid, including automatic tagging/pairing. Keep unattributable/system work separately identified rather than inventing a faculty actor. Requests may include multiple provider attempts; distinguish product operations from billable attempts and avoid double-counting the same reported charge.

## Cost correctness

Use reported provider usage/cost when available. Otherwise a calculated estimate needs the applicable price/configuration version and units. Unknown cost is unknown, not zero. Store currency and distinguish estimates from actuals; no provider prices, conversion rates or rupee forecasts are selected here. Retry/failure accounting must reflect available billing evidence, not assume failed operations are always free.

## Access and audit

The dashboard is an organization-admin management resource. Viewing the full question bank or using AI does not grant access to another tenant's faculty/cost data. Exact faculty self-usage visibility is not specified by this admin-dashboard decision. Keep usage references and safe logs without provider credentials or unnecessary question/student content.

## Open controls

Admin can set monthly per-faculty spending limits. Thresholds are confirmed: warning at 80% and stop new AI work at 100%. Reset usage for each calendar month on its first day, preserving prior-month history. Exact timezone/boundary handling, additional organization-wide budget controls and concurrent-request reservations need design. Provider credentials, catalogue configuration, usage retention/export and reporting latency remain design work. Do not turn a dashboard requirement into an unapproved financial limit.

## Acceptance direction

Verify actor/organization/operation attribution, provider-attempt versus operation counts, actual/estimated/unavailable cost labels, aggregate consistency, retry accounting and tenant-safe admin access. No application/provider checks have been run.

## Budget thresholds — 80% warning, 100% stop

User-confirmed: issue a warning when a faculty member reaches 80% of their configured monthly AI budget, and stop new AI work at 100%. Enforce the stop at provider dispatch/service boundaries, not only a disabled UI button. Preserve completed results, saved questions and non-AI work. Do not assume in-flight requests are cancelled or final provider bills can never exceed a cap when usage arrives late; define reservation, reconciliation and in-flight handling explicitly. Warning delivery/deduplication and exact monthly reset semantics remain design work.

## Calendar-month usage reset — confirmed

User-confirmed: monthly budget usage starts afresh on the first day of every calendar month. Preserve prior-month usage/cost and audit history; reset the current-period counter, not historical records. Apply the configured faculty limit to the new period. This is not a rolling 30-day window. Exact organization timezone, in-flight request attribution at month boundaries and cost-reconciliation rules remain implementation design work.

## Coaching-owned AI API keys — confirmed

User-confirmed: each coaching supplies its own AI provider API keys instead of using centrally shared platform keys. Resolve secrets per organization for all API/worker operations, preserve credential-reference provenance without secret exposure, and never fall back to another coaching's/shared key. Provider billing belongs to the configured coaching account; application usage/budgets cover recorded app calls. Provider catalogue, secret manager, rotation/validation UX and fallback ordering/attempt limits remain design work; automatic fallback uses only the same coaching's configured keys. See [coaching-owned credentials](TENANT_AI_CREDENTIALS.md).

## Automatic model fallback with visible error — confirmed

User-confirmed: when the selected AI model fails, show a safe, understandable error/failure status and automatically try another enabled, operation-compatible model for the same coaching. Record original selection, failure, fallback attempt and actual model/provider used; do not hide the failure because fallback succeeds. Use only that coaching's configured credentials. Respect supported capabilities, bounded retry/fallback policy and budget reservations; never bypass missing authorization, tenant checks or the 100% budget stop. Preserve successful partial outputs and idempotency. If alternatives fail/unavailable, show an actionable terminal error without fabricating output. Exact fallback order, attempt limits and detailed UI remain design work.

## Coaching subscription/payment collection — later phase

Coaching subscription and payment collection are explicitly deferred beyond the first release. Initial coaching onboarding and question-bank workflows do not depend on creating a subscription, plan or payment record. Future pricing, commercial plans, invoicing, payment gateway, renewal/expiry and subscription enforcement need their own approved specification before implementation; this is not a commitment to permanent free access.

First-release AI usage/cost reporting, coaching-owned provider credentials and monthly faculty spending controls remain required. Provider charges associated with a coaching's own API keys and application AI-budget accounting are separate from the platform collecting subscription payments. Keep 80% warning/100% new-AI-work stop and monthly reset/history under the existing policy. No payment system, plan or billing integration has been created.

## Pattern reuse savings evidence

Report extraction mode/pattern version and recognition, structure-analysis, fallback and other AI calls/tokens/cost separately. Compare comparable initial-AI and repeated-pattern processing without claiming zero tokens or guaranteed savings. New handwriting may still incur recognition cost; preserve quality/completeness and normal QC. No benchmark has run. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md).
