# Question Bank Multi-SaaS — Project Handover

## Active documentation baseline — 17 October 2026

**Status: draft for product review, not approved for application implementation.**

The user has confirmed that no prior code exists. The earlier source-recovery assumption below is historical. The current instruction is to understand and complete requirements/documentation first, then begin implementation.

For the latest session decisions and where to resume, read [the continuation checkpoint](SESSION_CHECKPOINT.md).

For the bounded remaining interview and assistant-owned design work, see [the current review closure plan](REVIEW_CLOSURE_PLAN.md).

### Reading order

1. [Project context](PROJECT_MASTER_CONTEXT.md), [decisions and open questions](DECISIONS_AND_OPEN_QUESTIONS.md), and [roadmap](IMPLEMENTATION_ROADMAP.md).
2. [Hindi product review guide](REQUIREMENTS_REVIEW_HI.md) and [PRD](PRD.md).
3. [Requirements and acceptance criteria](REQUIREMENTS_TRACEABILITY.md), [user workflows and permissions](USER_WORKFLOWS_AND_PERMISSIONS.md), and [decision register](PRODUCT_DECISION_REGISTER.md).
4. [Architecture](SYSTEM_ARCHITECTURE.md), [database](DATABASE_SCHEMA.md), [API contracts](API_CONTRACTS_DRAFT.md), [ingestion](QUESTION_INGESTION_PIPELINE.md), [question QC](QUESTION_LIFECYCLE_AND_QC.md), [AI](AI_MODEL_ORCHESTRATION.md), [test builder](TEST_BUILDER_AND_ANALYTICS.md), and [security](SECURITY_AND_MULTI_TENANCY.md).
5. [Acceptance test plan](ACCEPTANCE_TEST_PLAN.md), [documentation readiness](DOCUMENTATION_READINESS.md), and [implementation handover](CODEX_HANDOVER_PROMPT.md).

### Detailed specifications added during review

- [Identity, login and access](IDENTITY_AND_ACCESS.md)
- [Platform admin full application access](PLATFORM_ADMIN_ACCESS.md)
- [Capacity and performance: lakh-scale bank](CAPACITY_AND_PERFORMANCE.md)
- [Consolidated faculty/admin access matrix](PERMISSIONS_MATRIX.md)

- [Consolidated publication requirements](PUBLICATION_REQUIREMENTS.md)
- [Question archival and historical preservation](QUESTION_ARCHIVAL.md)
- [AI generation of practice variants](AI_VARIANT_GENERATION.md)
- [Duplicate checking and variant relationships](DUPLICATE_AND_VARIANT_POLICY.md)
- [AI diagram generation and editing](AI_DIAGRAM_ASSISTANCE.md)
- [AI answer assistance and correctness checking](AI_ANSWER_ASSISTANCE.md)
- [Admin AI usage and cost reporting](AI_USAGE_AND_COST.md)
- [Coaching-owned AI provider keys](TENANT_AI_CREDENTIALS.md)

- [Question formats and answer constraints](QUESTION_TYPES_SPECIFICATION.md)
- [Visual, LaTeX and MathML equation editing](QUESTION_CONTENT_EDITOR.md)
- [Question language catalogue and admin extension](LANGUAGE_SUPPORT.md)
- [Upload and asset policy](UPLOAD_AND_ASSET_POLICY.md)
- [Linked question-paper, key and solution files](MULTI_FILE_INGESTION.md)
- [Adaptive AI extraction and reusable layout patterns](ADAPTIVE_EXTRACTION_PATTERNS.md)
- [Platform-managed complete coaching dataset sharing](CROSS_COACHING_DATA_SHARING.md)
- [Later courses/classes and personalized AI teaching](FUTURE_LEARNING_AND_AI_TEACHING.md)
- [Background jobs and cancellation](BACKGROUND_JOBS_AND_CANCELLATION.md)
- [OCR and handwritten question extraction](OCR_AND_HANDWRITING.md)
- [Original source storage, access and retention](SOURCE_STORAGE_AND_RETENTION.md)
- [Taxonomy, AI prerequisites and faculty knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md)

### Meaning of status labels

- **Agreed:** explicitly carried forward from the handover or confirmed by the user.
- **Proposed:** a design recommendation awaiting review; not a settled decision.
- **Open:** an unanswered product or technical question.
- **Verified:** established by inspecting files or executing a documented check; never inferred from a design document.

Technical safeguards may be specified without choosing product policy. For example, unauthorized transitions must be denied, while who is authorized to publish remains open.

Relative links refer to documents in this folder. The original archive is retained unchanged. Use the original ZIP if historical package text is needed; the current planning documents are indexed above.
