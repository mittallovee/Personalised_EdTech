# Security and Multi-Tenancy

## Trust boundaries and planned controls

This is a design requirement, not a security certification. Authentication, deployment, retention and limits are unresolved. Test evidence must use the real runtime DB role and worker paths, not only mocks or an owner account.

| Boundary | Threat to address | Required design/test |
| --- | --- | --- |
| Client to API | Forged tenant/resource IDs and stale membership | Authenticate, verify active membership/action, tenant-safe lookup on every operation |
| API to PostgreSQL | Missing tenant filter, context leakage, privileged bypass | Fail-closed RLS, transaction-scoped trusted context, least-privileged app role, pooled-connection isolation tests |
| Child relationships | A row links to another organization's data | Tenant-aware foreign keys/constraints plus request validation |
| Queue to worker | Forged/replayed messages or wrong job context | Validate job/tenant identity; idempotent processing and fresh tenant context per task |
| Storage access | Public/leaked originals or cross-tenant signed links | Private objects, authorized scoped reads, short-lived grants and safe logs |
| File parsers | Oversized/hostile/corrupt files | Signature/integrity/size/page checks, bounded processing, controlled temporary files, malware policy D-10 |
| AI/provider | Prompt injection, invalid IDs, data exposure or uncontrolled spend | Treat content/output as data, schema validation, tenant-safe retrieval, allowed models/operations and budgets |
| Published versions | API bypass, direct DB update or mutable asset replacement | Enforce lock at normal runtime DB paths and preserve referenced asset/content snapshots |
| Browser rendering | Unsafe rich text, links, equation/asset markup | Define content sanitization and rendering policy; restrict schemes/embeds and validate asset access |
| Administration/exports | Unreviewed broad access or deletion | Explicit permissions, audit trail, retention/deletion policy and export scoping |

## Identity and runtime details to decide

If cookies are selected, define secure cookie, CSRF, session rotation and cross-origin policy. If tokens are selected, define issuer/audience/expiry checks and renewal/storage policy. Do not invent a provider or homemade password system before D-02. Revocation/deactivated memberships must take effect according to an explicit policy.

RLS session values alone are not a defense against arbitrary SQL execution. Parameterized access, minimal DB permissions, restricted runtime credentials and trusted transaction setup remain necessary. Pool reuse and retry paths must clear tenant state even after errors. Superuser/table-owner tests cannot establish runtime RLS safety.

## Production gate

Before production, review network exposure, secret management, dependency updates, rate/resource controls, incident access, backup/restore evidence, data retention/deletion and privacy needs. Exact operational targets are D-18/D-19. These are milestone requirements and do not imply that production deployment has been requested now.

## Core requirements
- Every tenant-owned record must have an organization/tenant relationship.
- Enforce tenant membership and role permissions on every API operation.
- Use PostgreSQL RLS as defense in depth, not as a substitute for application authorization.
- Fail closed when tenant context is missing.
- Ensure background workers establish the correct tenant context for every job.
- Private object storage; validate files and use short-lived signed access where needed.
- Store secrets outside source control; use separate dev/test/prod credentials.
- Do not expose development endpoints without authentication outside local-only development.
- Audit sensitive operations: publishing, permission changes, question edits, exports, and data deletion.
- Rate-limit uploads and AI endpoints; set file size/page limits.
- Use safe logging; avoid logging credentials, full sensitive content, or signed URLs.
- Define backups, restoration tests, retention, and deletion policy before production.

## Verification tests
- Tenant A cannot read, update, or delete tenant B's records.
- Tenant A cannot link a question to tenant B's source or version.
- Background jobs cannot cross tenant boundaries.
- Missing tenant context denies access.
- Application DB role cannot bypass RLS; migration owner role is separate.
- Published versions cannot be updated/deleted through normal application paths.
- Authorization tests cover creator/reviewer/approver/admin actions.

## Review-driven permission and taxonomy controls

Admin-defined approval and publication grants must be enforced independently. Creator/upload rights confer neither action. AI taxonomy maintenance must preserve organization scope, validated relationships and audit; immediate provisional activation with admin notification/revocation is confirmed. Catalogue changes/revocation must not rewrite historical published snapshots or silently remove question content.

## Confirmed AI and original-source lifecycle update

AI directly fills validated editable metadata without a per-field approval gate. New concepts may be added and used immediately with AI-added/admin-review-pending status. Notify admin for later approve/edit/merge/revoke; revocation stops new automatic use and preserves published snapshots. This supersedes the earlier approval-first rule; question approve/publish permissions remain separate.

Retain original source files until admin chooses deletion. Only admin can see storage analytics and delete originals; faculty can view their organization's originals. Original deletion must preserve saved questions and independently retained required diagrams/assets, show source-unavailable status honestly and record the deletion. No automatic expiry has been selected. See [source lifecycle](SOURCE_STORAGE_AND_RETENTION.md).

## First-release login methods — confirmed

User-confirmed: Google login, email/password and mobile OTP are all required in the first release as alternative sign-in methods. Identity provider/session implementation, account linking, OTP delivery and onboarding remain open. Authentication does not grant organization membership or action permissions. See [identity and access](IDENTITY_AND_ACCESS.md).

## Admin-only faculty onboarding — confirmed

User-confirmed: faculty accounts are created/invited only by admin; public self-signup is not the faculty onboarding route. Authentication alone cannot enroll an uninvited user or grant organization permissions. Preserve organization-scoped invitation/membership and audit. Owner/platform bootstrap, invitation delivery and verified account linking remain separate design questions.

## Single-coaching faculty account — confirmed

User-confirmed: each faculty account belongs to only one coaching organization and cannot switch between multiple coaching memberships. The platform remains multi-tenant, with separate faculty accounts/data for different organizations and runtime isolation. Enforce the single-coaching account scope server-side; hiding a switcher is not sufficient. This faculty rule does not define platform-owner/admin scope or whether the same human may hold separately provisioned accounts; do not silently infer identity-provider/account-merging behavior.

## Faculty sees the complete coaching question bank — confirmed

User-confirmed: faculty can view the complete question bank of their own coaching organization, not only questions they created or uploaded. Do not apply a creator-only filter to ordinary faculty question-bank visibility. Organization ownership, single-coaching account scope and cross-tenant denial remain unchanged. Viewing the full bank does not itself grant editing, approval/publication, original-file deletion or storage-dashboard rights. Detailed staging/review-state access and edit permissions remain separate policy questions.

## Admin controls cross-author editing — confirmed

User-confirmed: admin decides whether a user may edit questions created/uploaded by other faculty in the same coaching. Complete bank visibility does not grant cross-author edit permission. Enforce this independently from approval/publication grants and tenant scope. Published content is never overwritten: authorized corrections create a new version under the existing question code and retain audit/source history. Own-draft editing, exact default grants and edit/approval invalidation details remain governed by the final permission/lifecycle design.

## Default faculty upload, manual entry and AI access — confirmed

User-confirmed after clarification: upload, manual entry and AI tools are available to all faculty by default, without separate per-user admin enable permissions. Enforce active single-coaching membership, tenant scope, configured models/resource limits and existing operation-state rules. Approval, publication, editing another faculty's question and admin-only storage/deletion remain separately controlled. Default AI access does not authorize protected writes to another question. See [confirmed access matrix](PERMISSIONS_MATRIX.md).

## Admin-granted review/QC permission — confirmed

User-confirmed: formal question review/QC requires a separate permission granted by admin. Default faculty bank/source viewing, upload/manual entry and AI access do not grant formal review authority. Review, approval and publication are independent grants. A user may perform their own review/approval/publication only when holding the corresponding permissions; no different person is universally mandated. Review permission authorizes reviewed-state decisions/correction-return within the workflow, not protected content edits without the required edit permission. Preserve actor/revision-bound QC evidence and deny unauthorized review transitions.

## Coaching-owned AI API keys — confirmed

User-confirmed: each coaching supplies its own AI provider API keys instead of using centrally shared platform keys. Resolve secrets per organization for all API/worker operations, preserve credential-reference provenance without secret exposure, and never fall back to another coaching's/shared key. Provider billing belongs to the configured coaching account; application usage/budgets cover recorded app calls. Provider catalogue, secret manager, rotation/validation UX and fallback ordering/attempt limits remain design work; automatic fallback uses only the same coaching's configured keys. See [coaching-owned credentials](TENANT_AI_CREDENTIALS.md).

## Admin and creator question archival — confirmed

User-confirmed: archive removes a question from the active bank while retaining content/history. Admin may archive questions in their own coaching, and creator faculty may archive their own question. Complete-bank view or cross-author edit permission alone does not grant archive authority over other creators' questions. Preserve code, immutable published versions, assets, sources/audit and historical references; archival is not physical deletion or admin-only original-file deletion. Restore behavior remains open. See [question archival](QUESTION_ARCHIVAL.md).

## Multiple admins per coaching — confirmed

A coaching organization may have more than one admin. Represent administration through individual authenticated identities and organization-scoped memberships/authority; do not impose a one-admin-per-organization constraint or require a shared login. Attribute every administrative action to the actual actor and preserve organization ownership of questions and audit history.

Multiple admins do not imply access to other coaching organizations. Each coaching has a principal Owner/Admin who can appoint and remove its other admins. Ordinary admin status does not itself grant admin-appointment/removal authority. The current Owner may transfer principal ownership to another admin in the same coaching. After transfer, the former Owner remains a regular admin in that coaching and loses principal-owner authority. When removing another admin, Owner chooses either conversion to normal faculty or removal from the coaching app with no remaining coaching access. Platform admin creates the coaching and first Owner; onboarding delivery/identity mechanics, owner recovery and exact transfer/removal mechanics remain design work. Existing independent question QC/approve/publish grants and admin-only catalogue/storage/AI configuration policies remain; do not infer that the numeric admin count changes their semantics.

## All admins may remove ordinary faculty — confirmed

Any active coaching admin (including Owner) may remove an ordinary faculty member from that same coaching's app, revoking coaching access while preserving organization questions/assets, attribution, usage and audit history. Check actor and target current membership/role at commit. Ordinary admins cannot use this action on another admin or Owner; admin demotion/removal remains Owner-only. Session/job/asset-access revocation and identity-cleanup mechanics remain design work. See [identity and access](IDENTITY_AND_ACCESS.md).

## Platform-admin onboarding of coaching and first Owner — confirmed

Platform admin creates each coaching organization and its first principal Owner/Admin. Coaching public self-signup is not available. Coaching Owner/admin and faculty membership do not confer platform-level onboarding authority, and a normal Google/password/OTP login cannot self-assign it. After onboarding, the coaching's Owner controls its other admins under the confirmed policy.

Design direction: keep platform authority separate from tenant membership, validate the intended first-owner identity and record platform actor, organization, owner and outcome. Provision the organization/initial-owner relationship consistently, with safe partial-failure/retry handling and no duplicate organizations or extra principal owners from replay. Invitation delivery/acceptance, verified identity linking and initial platform-admin provisioning remain implementation design.

Platform admin now has full cross-coaching application authority, including all question and tenant-administration capabilities, as defined in [platform access](PLATFORM_ADMIN_ACCESS.md). Earlier limited onboarding/read scope is superseded; preserve workflow, version, tenant-reference, secret-handling and audit rules. No organization or real account has been created.

## Explicit platform question-bank read scope — confirmed

Platform admin can view all coaching question banks using explicit platform-read authorization. Ordinary coaching users retain own-coaching isolation; show coaching ownership/context and audit platform reads. Server-side API/RLS/storage/cache rules must distinguish authorized question reads (including retained content assets needed to display them) from unrestricted tenant-data access. No owner/migration-credential or global RLS bypass is implied. The later full-access decision includes originals/storage, credential administration, edits/QC/approve/publish and supported AI/other application actions; this read-path description is not a limit on the platform role. See [identity and access](IDENTITY_AND_ACCESS.md).

## Explicit platform question editing — confirmed

Platform admin may edit questions in all coaching organizations through explicit platform-edit authorization and target-coaching context. Enforce type/content validation, current revision and tenant-consistent references, and record platform actor plus before/after evidence without transferring coaching ownership/creator attribution. Published corrections create an editable new version under the same master/code; preserve the existing published version and revision-bound QC/approval rules. The later full-access decision also grants QC/approve/publish, supported archive/delete, original-source/credential administration and supported AI/other app actions; the edit-path description is not a limit on platform authority. Use a reviewed restricted API/RLS write policy rather than unrestricted database bypass. See [identity and access](IDENTITY_AND_ACCESS.md).

## Current platform authority — full access

Platform admin has full application access across all coachings, including question QC/approve/publish, originals/storage, users/Owners/roles, taxonomy, AI credentials/configuration/budgets/jobs and analytics. Earlier limited platform read/edit exclusions are superseded. Coaching roles retain their own-coaching boundaries. Validation, published-version preservation, current authority checks, coaching data ownership, secret handling and audit remain required. Full authority covers supported features and does not move deferred test/student features into release one. See [the platform access specification](PLATFORM_ADMIN_ACCESS.md).

## Pattern and later teaching boundaries

Patterns/examples require explicit scope, provenance and validated configuration; do not execute AI pattern text as arbitrary code or treat document instructions as authorization. Patterns are separate per coaching; explicit platform-admin dataset sharing can make specified data/patterns available to another coaching. Private examples/answers cannot cross silently; sharing creates an independent initial copy with no continuing source access or synchronization. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md).

Later courses/enrollment/live/recorded and personalized teaching/video need student/event/media contracts before implementation. Current documentation does not authorize app coding. See [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).

## Coaching-specific patterns and platform dataset sharing - confirmed

Each coaching keeps its data/pattern library separate. Platform admin may explicitly share the complete dataset, patterns and associated material with another coaching. Ordinary coaching roles cannot initiate cross-coaching sharing. Preserve an explicit source/target manifest, complete dependency mapping, question-code/version integrity and platform actor history. Sharing creates a one-time independent initial copy with no ongoing updates in either direction; destination may use/change its own copy. Preserve mapped independent identities/new globally unique codes for new question masters and source provenance. Destination users and API keys are set up separately, not copied; keep source actor/model evidence as provenance, not active memberships/secrets. Source-published questions retain published status without mandatory local re-review on copy; preserve imported QC evidence and immutable snapshots, with later edits using normal new-version review. Destination conflict/failure and operational-reference details remain design work. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).
