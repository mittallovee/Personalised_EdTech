# Project Master Context

## Current authoritative status — 17 October 2026

- **User-confirmed:** no prior application source code has been created. Source recovery is no longer the next task.
- **User instruction:** understand requirements and prepare proper project documents before application implementation begins.
- **Verified locally:** the starting folder contained the handover ZIP and an empty Git repository with no commits or tracked application files.
- The current repository contains documentation prepared from that ZIP. No application has been built or tested.
- The implementation-stack list below remains proposed. Presence of tools on the local machine does not establish deployment readiness.
- This update supersedes the earlier source-recovery assumption preserved in the original ZIP.

## Requirements boundary

The user confirmed initial rollout for **one coaching institute**, with support for **many coaching organizations** retained in the architecture from the start. Multi-tenant ownership, membership and data isolation remain mandatory. The exact commercial meaning of "multi-SaaS" beyond this remains open; do not infer independent products, billing, white-label domains or separate deployments.

Requirements review proceeds **one question at a time**, as requested by the user.

**Confirmed permission policy:** admin defines approval and publication permissions independently for each user. Creator can act on own content only with the corresponding grants; creating/uploading grants neither. Human QC, valid transitions, audit and published immutability remain required.

Manual entry belongs in the initial faculty question workflow even though the first file-extraction prototype uses PDF/DOCX. Billing, a complete student app, advanced analytics, and production deployment are outside that prototype.

Use [the requirement register](REQUIREMENTS_TRACEABILITY.md) for acceptance criteria and [the decision register](PRODUCT_DECISION_REGISTER.md) for unanswered choices. Published immutability is agreed; whether draft revisions are append-only is not settled.

## Project
Build a multi-tenant, multi-SaaS Question Bank and Test Creation Platform for coaching organizations, initially focused on IIT-JEE/NEET and Physics teaching, but designed to support other subjects, curricula, and exams later.

## Product direction
- Faculty/admin question-bank entry/upload/review and database saving are first-release scope. Test creation and test-paper export follow later.
- Student-facing test delivery, attempt tracking, analytics, and personalized suggestions are later phases.
- Questions belong to the organization/tenant, not to an individual creator.
- A question has a stable master identity, immutable version history, and explicit relationships to variants, translations, and duplicates.
- A human-readable permanent question code should be 8 alphanumeric characters, generated securely and protected by a platform-wide global unique constraint across all organizations. Keep this distinct from internal UUIDs and version IDs.
- The system must support PDF/Word ingestion and manual question entry through the same downstream question-processing pipeline.
- AI may suggest metadata, translations, diagrams, and duplicate/variation matches; human QC remains authoritative where required.
- Faculty should be able to choose from a fixed supported list of AI models, with sensible defaults and per-operation selection where supported. The system should record model/prompt provenance.
- Published question versions must remain historically stable for tests already assembled against them. Changes should create a new version under controlled permissions rather than silently altering old content.

## Proposed technology stack
- Faculty frontend: Next.js, React, TypeScript
- Backend: Python, FastAPI
- ORM/migrations: SQLAlchemy 2.x, Alembic
- Database: PostgreSQL with JSONB and tenant isolation/RLS
- Object storage: S3-compatible storage for originals and extracted assets
- Background processing: Celery + Redis (or revisit if deployment requirements justify another queue)
- PDF extraction: PyMuPDF
- DOCX extraction: python-docx
- OCR: Tesseract as an initial self-hostable option; benchmark on real files
- AI gateway: LiteLLM plus a project-owned AI orchestration layer, subject to validation
- Local development: Docker Compose
- Testing: pytest and integration tests

These are proposed implementation choices from the conversation, not proof that the stack has been installed or deployed.

## Product metadata previously discussed
- Question type: Single Option Correct, Multiple Option Correct, Numerical, Integer, Single Digit, Match the Column, Assertion–Reason, Multiple Statement, Passage-based variants
- Class, subject, chapter, topic
- Primary concept and multiple secondary concepts; no fixed limit of two secondary concepts. Detailed hierarchy supports class, subject, chapter, topic and subtopic.
- Difficulty level 1–10
- Bloom's taxonomy level
- Exam, PYQ year/date/code/slot/batch and source name
- Optional video-solution metadata
- Language/translation metadata (Hindi, Bengali, Gujarati were examples)
- AI-verified indicator, only when verification criteria are actually met

## Roles and workflow
- Creator
- Reviewer/validator
- Approver/admin
- States discussed: Draft → Content QC/Review → Approved → Published
- Published content is locked against casual editing; admin-authorized change should create a new version and preserve audit history.

## Current implementation status

- Requirements and broad architecture have been discussed; detailed product review is pending.
- The user confirmed that no application code exists. The documentation ZIP is the source of project context, not a working scaffold.
- No application services, migrations, authentication, RLS policies, upload APIs, OCR or AI tagging have been implemented or verified in this repository.
- Historical scaffold/syntax-check claims from the earlier conversation are not current implementation evidence.
- Next step: review requirements, resolve decisions affecting the first slice and align schemas/contracts/acceptance criteria before implementation.

## Continuity instructions
Read this package before proposing changes. Do not re-open settled product decisions without explaining the reason. Clearly label facts as confirmed, proposed, or unverified. Avoid claiming tests pass unless actually executed and report the command and output.

## Additional confirmed requirements from review

All nine question formats are required in the first release; see [type specification](QUESTION_TYPES_SPECIFICATION.md). PDF, Word and images are included, with accepted per-file limits of 50 MB/document and 10 MB/image. See [upload policy](UPLOAD_AND_ASSET_POLICY.md).

Taxonomy supports detailed hierarchy and primary/multiple secondary concepts. AI primarily tags from an AI-created/maintained catalogue and can extend it when concepts are missing. The user confirmed immediate provisional AI addition with admin notification and later approve/edit/merge/revoke, replacing the earlier approval-first rule. See [taxonomy design](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Confirmed AI and original-source lifecycle update

AI directly fills validated editable metadata without a per-field approval gate. New concepts may be added and used immediately with AI-added/admin-review-pending status. Notify admin for later approve/edit/merge/revoke; revocation stops new automatic use and preserves published snapshots. This supersedes the earlier approval-first rule; question approve/publish permissions remain separate.

Retain original source files until admin chooses deletion. Only admin can see storage analytics and delete originals; faculty can view their organization's originals. Original deletion must preserve saved questions and independently retained required diagrams/assets, show source-unavailable status honestly and record the deletion. No automatic expiry has been selected. See [source lifecycle](SOURCE_STORAGE_AND_RETENTION.md).

## Language catalogue and metadata display review update

English, Hindi and Gujarati were explicitly requested, plus three or four widely used regional languages. Initial four regional defaults are Bengali, Marathi, Telugu and Tamil, selected under that criterion. Admin may add more languages. See [language support](LANGUAGE_SUPPORT.md) for source basis and capability verification. Display one language at a time; each translation has a new master/code linked to the source; detailed QC remains open and generation is faculty-requested after source review.

The normal question view shows final/current metadata. Internal audit and AI provenance remain required; a per-field change timeline is not a required normal-screen feature.

## Metadata language decision

AI fills user-facing metadata in the question language. English is not an additional required metadata language. Stable concept identities must remain consistent across localized labels. Translation generation is on faculty request; translation identity is a distinct master/new code; detailed review rules remain open.

## On-demand question translation — confirmed

Faculty requests generation in a supported target language only after the source question has completed review. Requests before review completion are not permitted. Review completion is the confirmed gate; do not silently replace it with a requirement for prior publication. Do not automatically translate every uploaded question into all languages. Keep the source-version link, output language and model/prompt provenance; translation generation does not itself publish the result. Translation gets a distinct master/new permanent code and its own versions; detailed permission/QC semantics remain under review.

## Independent source/translation updates — confirmed

The user confirmed that original and translated questions may be updated independently. Do not require simultaneous edits or automatically overwrite a translation when its source changes. Each master keeps its own stable code and version history; preserve the translation-of link and exact originating source version. Published corrections create a new version for the affected master. This does not authorize silent mutation of either published version.

## Distinct identity for practice variants — confirmed

User-confirmed: a new practice variant made by changing values or conditions receives its own permanent, globally unique eight-character alphanumeric question code. It is a distinct question master with its own version history, explicitly linked as variant-of to the original. Preserve source-version and creation/AI provenance where applicable. This does not change the correction policy: correcting an existing question creates a new version under that existing master/code. Automatic variant generation, inheritance of review status and generation permissions are not established by this answer.

## First-release login methods — confirmed

User-confirmed: Google login, email/password and mobile OTP are all required in the first release as alternative sign-in methods. Identity provider/session implementation, account linking, OTP delivery and onboarding remain open. Authentication does not grant organization membership or action permissions. See [identity and access](IDENTITY_AND_ACCESS.md).

## Single-coaching faculty account — confirmed

User-confirmed: each faculty account belongs to only one coaching organization and cannot switch between multiple coaching memberships. The platform remains multi-tenant, with separate faculty accounts/data for different organizations and runtime isolation. Enforce the single-coaching account scope server-side; hiding a switcher is not sufficient. This faculty rule does not define platform-owner/admin scope or whether the same human may hold separately provisioned accounts; do not silently infer identity-provider/account-merging behavior.

## Coaching onboarding — confirmed review update

Platform admin creates new coaching organizations and their first principal Owner/Admin; coaching public self-signup is excluded. Each coaching supports multiple admins, managed by its Owner; all coaching admins can invite/create and remove ordinary faculty. Owner may transfer ownership to another same-coaching admin and remains a regular admin afterward. Platform admin has full application access across every coaching, including QC/approve/publish, users/Owners/roles, originals/storage, protected AI credential/configuration/job administration and analytics; preserve explicit target context, validation, immutable published versions, coaching ownership and audit. Supported later features remain in their delivery phases. See [identity and access](IDENTITY_AND_ACCESS.md) and [the decision checkpoint](SESSION_CHECKPOINT.md) for current authority details.

## Coaching display branding — confirmed

Each coaching can show its own name and logo in the first-release app. Branding does not change organization identity, data/question ownership, question codes or tenant isolation. Custom domains/theme/white-label behavior remain separate. Only platform admin can configure/change coaching display name and logo; coaching Owner/admin/faculty cannot edit these settings.

## Shared app entry — confirmed

All coachings use one common website/app entry link. No per-coaching domain/subdomain is required for release one; authenticated membership resolves coaching data and name/logo, while platform admin selects a target coaching under full authority. This changes neither one-coaching faculty scope nor tenant isolation, and does not determine the physical deployment/database arrangement or actual domain.

## Coaching subscription/payment collection deferred — confirmed

Collecting subscription/payment from coachings belongs in a later phase, not the initial question-bank release. Future pricing/commercial/payment requirements remain open until that milestone. AI usage/cost tracking and coaching-key provider charges are separate and remain part of the confirmed first-release AI controls.

## Initial faculty usage expectation — confirmed, 18 October 2026

The first coaching is expected to have very few faculty users initially. No numeric faculty count, simultaneous-user target or hard account cap has been selected. Preserve the multi-coaching/growth architecture, confirmed first-release features and nonblocking background jobs; small initial use does not narrow permissions or scope.

## Question-bank scale — confirmed, 18 October 2026

Expected question-bank volume is in lakhs, despite a small initial faculty group. Preserve full first-release scope and multi-coaching readiness; data access/duplicate retrieval and background imports must be designed and evaluated at representative scale. Exact counts, upload rate/storage distribution and speed guarantees are uncommitted. See [capacity and performance](CAPACITY_AND_PERFORMANCE.md).

## Adaptive extraction and future teaching — confirmed, 18 October 2026

First-release ingestion learns reusable document-layout patterns through initial AI extraction, saves/versions them and automatically reuses compatible files, aiming at faster processing/lower extraction tokens with validation/fallback. Support different layout families and handwritten questions/solutions. Samples will arrive later. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md).

Later phases include faculty-created courses, live classes, recorded sessions and AI teaching/concept videos personalized to student need/current level. These future modules do not enlarge the initial external-video-link-only question-bank scope. See [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).

## Separate patterns and explicit complete-dataset sharing

Coaching data and extraction patterns are separate by default. Platform admin may share the complete dataset, including patterns and associated material, with another coaching. Sharing creates an independent initial copy that the receiving coaching can use/change under its own permissions, with no synchronization either way. New destination masters need new globally unique codes with source provenance; exact identity/configuration categories, import state and conflicts remain design work. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).


## Initial AI provider scope - confirmed 18 October 2026

User-confirmed (18 October 2026): first-release AI provider support includes Google, Anthropic, OpenAI and OpenRouter, with an extensible adapter/catalogue design for adding more providers later. Each coaching configures its own credentials; existing enabled-model/default selection, compatible automatic fallback with visible failure, usage provenance and budget controls continue. Provider selection does not mean credentials are available or integrations tested. Specific API products, model identifiers, operation capabilities, data handling, prices and routing/attribution details require current official-source verification during design. Adding a provider later requires an implemented and validated adapter/catalogue entry; it is not arbitrary endpoint execution.


## Local development hosting - confirmed 18 October 2026

User-confirmed (18 October 2026): the development app will be hosted on this PC. Production hosting is deferred; do not infer public PC hosting, remote faculty access, a purchased cloud account or a production deployment. The assistant should propose a local development setup with persistent data/assets, background jobs and configuration boundaries compatible with later hosting. Stack/runtime/resource compatibility and representative performance are not verified. No dependencies have been installed and no server or application has been started.

The monthly hosted-server/storage budget question is deferred with production hosting; this is a planning consequence, not an approved zero-cost or unlimited budget. Coaching-owned AI APIs and their usage/budget controls remain separate. The current interview has no further required user questions; design consolidation and document review must precede code.
