# Decisions and Open Questions

## Current review protocol — 17 October 2026

The user confirmed no code exists and requested documentation before implementation. Do not initiate application scaffolding merely because a proposed stack appears here.

The user also confirmed one coaching institute at launch with support for many institutes retained from the start. Rollout scope and per-coaching name/logo display are confirmed; a shared app entry link is confirmed without separate coaching domains/subdomains; extended branding, actual common domain, future commercial packaging and physical deployment topology remain separate decisions. Coaching subscription/payment collection is explicitly deferred beyond release one; required AI usage/cost and spending controls remain in scope. Ask remaining review questions one at a time.

A creator may approve/publish own content only with the corresponding admin-defined permissions; creation/upload grants neither. Human QC, valid transitions and audit remain required.

The [product decision register](PRODUCT_DECISION_REGISTER.md) gives each unresolved choice an ID, proposal where helpful, and the milestone it affects. Entries are open until an answer is explicitly recorded. A recommendation is not approval.

When an answer arrives, record its date, rationale, and affected requirement/document IDs. Update conflicting passages instead of leaving two competing current policies. Keep earlier handover context identifiable as historical.

Two ambiguities require explicit resolution:

- The documents mention immutable version rows but also permit updating drafts. Published versions are definitely immutable; draft revision storage and the lock point for approved versions are open.
- User confirmed global public-code uniqueness across the platform. This supersedes the earlier tenant-scoped preference; codes remain distinct from UUID/version IDs and do not grant cross-tenant access.

## Decisions previously stated as agreed
- Product is a multi-SaaS/multi-tenant question bank and test creation platform.
- Organization owns questions; not individual creators.
- Manual entry and file ingestion converge on one processing pipeline.
- Stable 8 character alphanumeric question code, distinct from database UUID and version ID.
- Master question and immutable versions are separate concepts.
- Published content should not be silently mutated; preserve old versions for tests.
- Variants, translations, and duplicates are explicit relationships.
- Faculty can choose from a fixed supported AI model list; defaults also exist.
- AI model/prompt provenance should be recorded.
- Start with modular monolith + background workers rather than premature microservices.
- Initial ingestion prototype focuses on PDF/DOCX, staging, and review.

## Proposed but not yet verified in code
- Next.js/React/TypeScript frontend.
- FastAPI + SQLAlchemy 2.x + Alembic backend.
- PostgreSQL/JSONB and RLS.
- S3-compatible object storage.
- Celery + Redis.
- PyMuPDF, python-docx, Tesseract.
- LiteLLM plus project-owned AI orchestration.
- Docker Compose local development.

## Open questions to resolve from the actual repository/product decisions
- What authentication provider and session strategy?
- Exact roles/permissions and whether custom roles are needed?
- Public question-code uniqueness is resolved: global across the platform. Exact alphabet/case and lifecycle details remain open; length is confirmed as eight characters.
- Exact question content JSON schema for passages, match-the-column, assertion-reason, multiple statements, equations, and diagrams.
- Taxonomy schema: normalized tables vs flexible hierarchy.
- Object storage provider and file retention policy.
- Supported file limits and upload formats.
- OCR language packs and benchmark corpus.
- Initial AI providers are Google, Anthropic, OpenAI and OpenRouter, with later extension. Exact API/model catalogue, capability mapping and implementation of confirmed budget/operation policies remain design work.
- Review rejection/changes-requested states and who can publish.
- Duplicate thresholds and human confirmation policy.
- Required export formats and initial test builder scope.
- Student data/privacy requirements before analytics.
- Development target is this PC (confirmed 18 October 2026). Propose local configuration; production hosting/budget, monitoring, backup and recovery targets remain later deployment design/review work, not current interview blockers.

## Guardrails
Do not silently change a prior decision. If a requirement conflicts with security, feasibility, or maintainability, explain the trade-off and ask before changing product direction.

## Latest product-review resolutions

Admin defines each user's approval and publication permissions independently. Creation/upload is not a grant; authorized creator actions on own content are supported. First release saves/reviews questions; tests and test-paper exports are later. All nine question formats are included, with confirmed numeric constraints in the type specification. PDF/Word/images are included; 50 MB/document and 10 MB/image limits are accepted.

Detailed AI-managed taxonomy supports primary/multiple secondary concepts. Immediate provisional AI concept addition with admin notification and later approve/edit/merge/revoke is confirmed, superseding the earlier approval-first choice.

## Confirmed coaching/first-Owner onboarding authority

Platform admin creates each coaching and first Owner; no coaching public self-signup. Multiple coaching admins, Owner-managed admin appointment/removal, owner transfer with former Owner remaining admin, and all-admin ordinary-faculty removal are confirmed. Exact onboarding invitation/identity verification, first platform-admin provisioning, recovery and platform enforcement/secret/operation details remain implementation design. Full platform-admin application access across all coachings is confirmed, superseding earlier read/edit-only scope, with validation/version/audit rules; ordinary coaching users remain isolated. See [identity and access](IDENTITY_AND_ACCESS.md).

## D-21/D-22 — latest scope additions

First-release AI extraction learns/saves reusable layout patterns and automatically reuses compatible files, including handwritten questions/solutions. Sharing scope, lifecycle/validation and savings evidence remain open. Samples arrive later; current documentation continues. Later faculty courses/live/recorded and AI teaching/student-level personalized concept videos are confirmed future modules. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md) and [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).

## Separate patterns and complete dataset sharing

Each coaching has separate data/extraction patterns. Platform admin may explicitly share a coaching's complete dataset, including patterns and associated material, with another coaching. One-time independent copy is confirmed: the receiving coaching uses/changes its copy without ongoing synchronization. Identity/dependency/configuration, import-state and destination-conflict details remain design work. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).
