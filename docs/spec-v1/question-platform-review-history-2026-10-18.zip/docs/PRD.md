# Product Requirements Document (Draft)

## Review baseline — 17 October 2026

The user requested requirements/documentation before coding. No implementation exists. This PRD expresses the agreed product direction; detailed proposals require review through [D-01–D-23](PRODUCT_DECISION_REGISTER.md).

**Confirmed rollout:** begin with one coaching institute and a small initial faculty group while designing for multiple coaching organizations. Exact faculty count/concurrency is not specified; this is a usage expectation, not an account limit or measured capacity guarantee. Multi-tenant ownership and isolation are required from the foundation; initial onboarding of one organization does not narrow the architectural requirement. Per-coaching display name and logo are confirmed. All coachings share the same website/app entry link; separate coaching domains/subdomains are not required. Coaching subscription/payment collection is deferred beyond release one. Theme customization, the actual common domain and deployment topology remain separate design/product decisions.

**Confirmed permissions:** admin decides each user's approval and publication permissions independently. Creator may approve/publish own content only if granted the corresponding permission. Creating/uploading grants neither. Required QC, valid states and audit still apply.

### Scope by delivery layer

| Layer | Included direction | Explicit boundary |
| --- | --- | --- |
| Foundation | Organization ownership, membership, authorization, tenant isolation, audit framework and repeatable local environment | Identity provider, stack and hosting choice remain open |
| Initial faculty workflow | PDF/Word/images, manual entry, asynchronous processing, staging correction, all nine formats, question identities and human QC | 50 MB/document, 10 MB/image accepted; exact extensions, schema and permission configuration need review |
| Question-bank completion | Structured metadata, exact version preservation, relationships and searchable content | Taxonomy/content schema needs examples and validation rules |
| AI assistance in first usable release | AI-managed taxonomy/tagging, adaptive extraction-pattern learning/reuse, controlled model selection, provenance and validated suggestions | Actual providers, supported models, budgets and catalogue schema details remain open |
| Test creation — later release | Eligible question filters/counts, pinned versions, duplicate controls and history | Deferred; marks, sections, batch definition and export formats reviewed before that milestone |
| Later student product | Delivery, attempts, analytics, recommendations, faculty courses/live/recorded sessions and personalized AI teaching/concept videos | Requires separate privacy/event specifications; outside first ingestion prototype |

First release is question-bank entry/upload, review and database saving; test creation/test-paper exports are deferred. All nine discussed formats are required from release one, with schema detail still under review. AI-driven taxonomy/tagging is required; exact provider/model choices remain open; immediate provisional concept activation is confirmed.

### End-to-end success journey

An authorized faculty member uploads a representative document or enters a question manually, inspects source-linked candidates, corrects structural/answer errors, and submits content for the permitted QC process. An authorized publisher publishes an immutable version. A test author can later find and select that exact eligible version; correction of the master does not alter saved tests. Every action stays inside the active organization and leaves the required provenance/audit evidence.

### Publication readiness versus draft completeness

Drafts must support incomplete work without presenting it as ready to publish. Each initial question type needs explicit validation for required content/answer structure, and publication needs an agreed metadata/QC policy. A numeric difficulty label, extracted answer key or AI suggestion is not evidence of correctness by itself.

### Requirements governance

[R-01–R-39](REQUIREMENTS_TRACEABILITY.md) are the consolidated requirement IDs. [AT-01–AT-48](ACCEPTANCE_TEST_PLAN.md) define planned validation scenarios. Numeric quality, performance and recovery targets are uncommitted until decided. The presence of a requirement in this document does not mean it has been built or tested.

## 1. Vision
Provide coaching organizations with a reliable, searchable, versioned question bank and a workflow for creating high-quality tests from curated questions.

## 2. Users
- Organization owner/admin
- Faculty/question creator
- Reviewer/validator
- Approver/publisher
- Future: students and academic analysts

## 3. Goals
- Reduce manual work in ingesting and tagging questions.
- Maintain high-quality structured questions with review history.
- Prevent duplicate/near-duplicate questions in a test or configured batch.
- Support multiple organizations with strong tenant isolation.
- Make question versions reproducible for historical tests.
- Allow configurable AI assistance without hard-coding a single provider.

## 4. Core functional requirements
1. Organizations/tenants and membership.
2. Authentication and role-based authorization.
3. Upload PDF, Word and images in the first release, subject to reviewed parser support. Later consider XLSX and additional formats.
4. Validate uploads and store originals securely.
5. Create asynchronous ingestion jobs with progress, errors, retry, and idempotency.
6. Extract text and OCR scanned pages as needed.
7. Segment source documents into candidate questions and options, preserving page/source references.
8. Stage extracted candidates for human review before publishing.
9. Support manual entry through the same processing and review pipeline.
10. Maintain master questions, immutable versions, and stable public question codes.
11. Store structured content: stem, options, answer/key, solution, figures/assets, and format-specific fields.
12. AI directly fills taxonomy, difficulty, question type, language and exam metadata from a managed catalogue, with validation, provenance and later correction.
13. Record AI model, prompt/version, timestamp, and output provenance.
14. Detect exact and semantic duplicates/variants, with reviewer confirmation.
15. Support translations and explicit relationships between language versions.
16. Review, approve, publish, and preserve audit logs.
17. Build tests with filters and available-question counts.
18. Prevent configured duplicate question use within the same test/batch.
19. Future: student test delivery, time tracking, response analytics, and personalized recommendations.

## 5. Non-functional requirements
- Tenant isolation enforced server-side and, where appropriate, by PostgreSQL RLS.
- Secure file validation and storage; no public access to uploaded source files by default.
- Auditability and reproducibility.
- Idempotent retries and recoverable background jobs.
- Good observability: structured logs, job errors, processing timings.
- Automated unit, integration, and migration tests.
- Accessibility and responsive faculty UI.
- Scalable module boundaries without premature microservices.
- Secrets in environment/secret management, never committed.
- Backups, retention, and recovery policy before production.

## 6. Success measures to define
- Question extraction accuracy by source type/layout
- Percentage of candidate questions accepted without structural correction
- AI-populated metadata correction rate and reviewed quality
- Duplicate detection precision/recall
- Processing time per page/question
- Ingestion job success and retry rates
- Reviewer time per question
- Tenant-isolation test coverage
- Test assembly time and duplicate-prevention effectiveness

Set numerical targets only after building a representative evaluation corpus.

## 7. Out of scope for first ingestion prototype
Test creation and test-paper exports are deferred. Coaching subscription/payment collection is explicitly deferred as well; required AI usage/cost reporting and spending controls remain in release one. Full student delivery, advanced student analytics and production-deployment planning remain under their separate milestones.

## Detailed question-bank scope

First release supports all nine formats in [the type specification](QUESTION_TYPES_SPECIFICATION.md). Document uploads are limited to 50 MB/file; images to 10 MB/file. Detailed taxonomy includes class, subject, chapter, topic, subtopic and primary/multiple secondary concepts. AI creates the catalogue and primarily tags from it, with missing concepts handled by the reviewed update workflow. Student recommendation logic is later scope; stable concept identities are needed now.

## Confirmed AI and original-source lifecycle update

AI directly fills validated editable metadata without a per-field approval gate. New concepts may be added and used immediately with AI-added/admin-review-pending status. Notify admin for later approve/edit/merge/revoke; revocation stops new automatic use and preserves published snapshots. This supersedes the earlier approval-first rule; question approve/publish permissions remain separate.

Retain original source files until admin chooses deletion. Only admin can see storage analytics and delete originals; faculty can view their organization's originals. Original deletion must preserve saved questions and independently retained required diagrams/assets, show source-unavailable status honestly and record the deletion. No automatic expiry has been selected. See [source lifecycle](SOURCE_STORAGE_AND_RETENTION.md).

## Language catalogue and metadata display review update

English, Hindi and Gujarati were explicitly requested, plus three or four widely used regional languages. Initial four regional defaults are Bengali, Marathi, Telugu and Tamil, selected under that criterion. Admin may add more languages. See [language support](LANGUAGE_SUPPORT.md) for source basis and capability verification. Display one language at a time; each translation has a new master/code linked to the source; detailed QC remains open and generation is faculty-requested after source review.

The normal question view shows final/current metadata. Internal audit and AI provenance remain required; a per-field change timeline is not a required normal-screen feature.

## Metadata language requirement

Metadata follows the question language; an English copy is not mandatory. Stable taxonomy identities support localized labels while retaining shared concept meaning.

## On-demand question translation — confirmed

Faculty requests generation in a supported target language only after the source question has completed review. Requests before review completion are not permitted. Review completion is the confirmed gate; do not silently replace it with a requirement for prior publication. Do not automatically translate every uploaded question into all languages. Keep the source-version link, output language and model/prompt provenance; translation generation does not itself publish the result. Translation gets a distinct master/new permanent code and its own versions; detailed permission/QC semantics remain under review.

## Optional solution at publication — confirmed

User-confirmed: a question may be published with a correct answer even if no solution/explanation is provided. Solution is optional, not a publication prerequisite. Type-valid answer, complete question content, applicable review/metadata checks and admin-defined publication permission remain required; this answer does not waive them. If a solution is supplied, preserve it as part of the version and apply relevant QC.

## Primary concept required for publication — confirmed

User-confirmed: a question must have a primary concept tag before publication. Missing primary concept blocks publication, while incomplete drafts remain editable. AI may assign the primary concept directly from the catalogue or create an immediately usable AI-added/admin-review-pending concept under the confirmed policy; catalogue admin approval is not a new prerequisite. Validate concept existence and organization scope. Secondary concepts remain optional unless a later decision explicitly requires them; primary-tag presence alone does not prove content correctness.

## Required publication classification — confirmed

User-confirmed: class, subject, chapter and topic are mandatory before publication, in addition to the previously required primary concept and type-valid correct answer. Incomplete drafts remain saveable. Validate organization scope and hierarchy consistency for selected catalogue entries; merely nonempty text does not establish a valid assignment. AI directly fills metadata under the existing policy. Subtopic and other metadata completeness are separate decisions still under review; solution remains optional.

## Subtopic optional at publication — confirmed, 17 October 2026

User-confirmed: subtopic is optional. Its absence must not block publication if class, subject, chapter, topic, primary concept, correct answer and other applicable requirements are met. If a subtopic is assigned, validate its hierarchy and tenant scope. Do not invent a subtopic solely to satisfy a completeness check.

## Difficulty required for publication — confirmed

User-confirmed: a valid difficulty level on the agreed 1–10 scale is required before publication. AI may fill it directly with provenance and authorized users may correct it. Missing or out-of-scale difficulty blocks publication, while incomplete drafts may be saved. Calibration/definitions and any finer numeric granularity remain design work; presence of a difficulty label alone does not establish correctness.

## Bloom level required for publication — confirmed

User-confirmed: a valid Bloom taxonomy level is required before publication. AI directly fills the field with model/prompt provenance and authorized users may correct it. Missing or invalid catalogue values block publication; incomplete drafts remain saveable. Preserve a stable level identity with localized labels and version-scoped metadata. This does not turn an AI-assigned label into evidence of educational quality; calibration/examples remain design work.

## PYQ exam and year required — confirmed

User-confirmed: if a question is marked as a previous-year examination question (PYQ), exam name and exam year are required before publication. Incomplete PYQ drafts may be saved but cannot publish without both fields. This conditional requirement does not force non-PYQ questions to carry exam/year values. Retain source provenance and do not fabricate missing exam/year to pass validation. Date, paper code, slot/shift and other PYQ metadata completeness remain separate decisions.

## Optional PYQ detail fields — confirmed, 17 October 2026

User-confirmed: PYQ date, shift/slot and paper code are optional. Populate them when known, retain provenance and leave unknown values absent rather than inventing them. Their absence does not block publication. Exam name and year remain mandatory when PYQ is selected. See the consolidated [publication requirements](PUBLICATION_REQUIREMENTS.md).

## Return for correction and resubmit — confirmed

User-confirmed: when review finds an issue, the question can be returned to its creator for correction and submitted for review again. Preserve content/source identity and review history; returning work is not deletion or automatic creation of a new master. Represent a changes-requested correction loop alongside the existing draft/content-QC/approved/published flow. Authorize return/edit/resubmit actions and bind review decisions to the reviewed revision; published versions remain immutable. Exact role grants, reason/comment requirements, reassignment and separate rejection/withdrawal policies remain open.

## Global permanent question code — confirmed

Question codes are unique platform-wide across organizations, not only inside one coaching institute. Organization ownership and access controls remain enforced; knowing a code does not grant access to another tenant. Internal UUID and version identities stay separate.

## Distinct identity for practice variants — confirmed

User-confirmed: a new practice variant made by changing values or conditions receives its own permanent, globally unique eight-character alphanumeric question code. It is a distinct question master with its own version history, explicitly linked as variant-of to the original. Preserve source-version and creation/AI provenance where applicable. This does not change the correction policy: correcting an existing question creates a new version under that existing master/code. Automatic variant generation, inheritance of review status and generation permissions are not established by this answer.

## AI variants in first release — confirmed

User-confirmed: AI generation of practice variants is included in the first release. Generated variants receive separate masters/new global eight-character codes and variant-of/source-version provenance; they follow normal question QC and authorized approval/publication. Original content remains unchanged. Faculty request is the confirmed trigger; no automatic per-question generation. Source eligibility, generation count/controls and operation permissions remain open. See [AI variant generation](AI_VARIANT_GENERATION.md).

## Variant generation before source review — confirmed, 17 October 2026

User-confirmed: original-question review completion is not required to generate a variant. Faculty may request a variant from an accessible draft/unreviewed source. Preserve the exact source content/version and its review status; source approval is not inherited. Generated variants still enter normal candidate/draft QC and require valid publication fields and admin-granted approve/publish permissions. Translation retains its separate post-review gate; do not apply that gate to variants.

## Variant count, target type and difficulty — confirmed

User-confirmed: faculty chooses variant count, can change the target question type, and needs target difficulty selection (1–10). Preserve these controls in the generation plan and AI provenance. Validate output against the target format and reassess answer/options/concepts/difficulty rather than copying source fields. A target setting is not proof of achieved difficulty. Source review completion remains unnecessary. Mixed-target batches are confirmed; practical limits/defaults and operation permissions still need design.

## Mixed-target variant requests — confirmed, 17 October 2026

User-confirmed: one faculty request may generate a mixture of question types and target difficulty levels. The accepted example is two SCQ variants at difficulty 4 plus one numerical at difficulty 7. Store each group/item target and requested count, derive a consistent total and bind output provenance to its requested plan. Validate each output against its own target format. Partial failures must identify affected plan entries rather than silently substituting another type/difficulty or duplicating successful outputs.

## Variants preserve the primary concept — confirmed, 17 October 2026

User-confirmed: practice variants must keep the original primary concept. Question type, requested difficulty and values/conditions may change without changing that main concept. Preserve the stable concept ID and source-version provenance. Validate semantic fidelity rather than merely copying the concept label onto unrelated generated content. Source review is not required; if source primary metadata is missing, resolve it through the existing AI/candidate metadata workflow rather than introducing a new review prerequisite. Other concept/quality checks still apply.

## Additional faculty instructions for variants — confirmed, 17 October 2026

User-confirmed: faculty may enter additional instructions for AI variant generation, such as changing only numerical values or reducing calculation. Keep them with the requested count/type/difficulty plan and AI provenance. Interpret them within the confirmed same-primary-concept and target-format requirements; surface conflicts instead of silently changing requested targets. Instructions do not grant permissions, cross tenant boundaries or bypass QC/publication checks. Exact shared/per-item instruction controls and length limits remain design details.

## First-release AI diagram creation/editing — confirmed

User-confirmed: first release includes AI generation of question diagrams and modification of existing diagrams when needed. Keep reviewable asset output, provenance, same-tenant attachment, preserved originals and version-safe references. Human QC checks diagram/question/answer consistency; no automatic verification or publication. Invocation controls, supported representation/providers/models and evaluation remain open. See [AI diagram assistance](AI_DIAGRAM_ASSISTANCE.md).

## Faculty-requested diagram generation/editing — confirmed, 17 October 2026

User-confirmed: AI diagram generation and editing run only on faculty request. Do not automatically create or modify diagrams during every upload/ingestion/new-question workflow, and do not replace source figures without the requested editing action. Preserve input/output assets, provenance, tenant access, published snapshots and normal QC. Detailed operation permissions, input controls, providers and output representation remain design work.

## First-release login methods — confirmed

User-confirmed: Google login, email/password and mobile OTP are all required in the first release as alternative sign-in methods. Identity provider/session implementation, account linking, OTP delivery and onboarding remain open. Authentication does not grant organization membership or action permissions. See [identity and access](IDENTITY_AND_ACCESS.md).

## Admin-only faculty onboarding — confirmed

User-confirmed: faculty accounts are created/invited only by admin; public self-signup is not the faculty onboarding route. Authentication alone cannot enroll an uninvited user or grant organization permissions. Preserve organization-scoped invitation/membership and audit. Owner/platform bootstrap, invitation delivery and verified account linking remain separate design questions.

## Single-coaching faculty account — confirmed

User-confirmed: each faculty account belongs to only one coaching organization and cannot switch between multiple coaching memberships. The platform remains multi-tenant, with separate faculty accounts/data for different organizations and runtime isolation. Enforce the single-coaching account scope server-side; hiding a switcher is not sufficient. This faculty rule does not define platform-owner/admin scope or whether the same human may hold separately provisioned accounts; do not silently infer identity-provider/account-merging behavior.

## Faculty sees the complete coaching question bank — confirmed

User-confirmed: faculty can view the complete question bank of their own coaching organization, not only questions they created or uploaded. Do not apply a creator-only filter to ordinary faculty question-bank visibility. Organization ownership, single-coaching account scope and cross-tenant denial remain unchanged. Viewing the full bank does not itself grant editing, approval/publication, original-file deletion or storage-dashboard rights. Detailed staging/review-state access and edit permissions remain separate policy questions.

## Admin controls cross-author editing — confirmed

User-confirmed: admin decides whether a user may edit questions created/uploaded by other faculty in the same coaching. Complete bank visibility does not grant cross-author edit permission. Enforce this independently from approval/publication grants and tenant scope. Published content is never overwritten: authorized corrections create a new version under the existing question code and retain audit/source history. Own-draft editing, exact default grants and edit/approval invalidation details remain governed by the final permission/lifecycle design.

## Default faculty upload, manual entry and AI access — confirmed

User-confirmed after clarification: upload, manual entry and AI tools are available to all faculty by default, without separate per-user admin enable permissions. Enforce active single-coaching membership, tenant scope, configured models/resource limits and existing operation-state rules. Approval, publication, editing another faculty's question and admin-only storage/deletion remain separately controlled. Default AI access does not authorize protected writes to another question. See [confirmed access matrix](PERMISSIONS_MATRIX.md).

## Admin-granted review/QC permission — confirmed

User-confirmed: formal question review/QC requires a separate permission granted by admin. Default faculty bank/source viewing, upload/manual entry and AI access do not grant formal review authority. Review, approval and publication are independent grants. A user may perform their own review/approval/publication only when holding the corresponding permissions; no different person is universally mandated. Review permission authorizes reviewed-state decisions/correction-return within the workflow, not protected content edits without the required edit permission. Preserve actor/revision-bound QC evidence and deny unauthorized review transitions.

## Shared pending-review access — confirmed

User-confirmed: any faculty member with review/QC permission may review pending questions in their own coaching. Mandatory per-question reviewer assignment is not required. Present a shared pending-review queue scoped to that organization and enforce the independent review grant. Preserve revision-bound decisions, actor/history and correction-return/resubmission. Concurrent decisions need transactional conflict handling rather than silently overwriting each other. Optional assignment is not a required feature by this answer; default faculty without the review grant cannot complete formal QC.

## Bulk mixed-source upload — confirmed

User-confirmed: first release supports bulk upload of multiple PDF, Word and image files in one submission. Preserve per-file validation, source identity/checksum, tenant scope and observable progress/errors; existing 50 MB/document and 10 MB/image limits remain per file. Bulk upload does not bypass staging/QC or imply automatic publication. Exact maximum file count, aggregate bytes, resumable transport and handling of separate paper/answer-key associations remain design work.

## Link separate paper, answer key and solution sources — confirmed

User-confirmed: question papers and their answer keys/solutions may be separate files and must be linkable for joint processing in the first release. Preserve group identity and independent question/answer/solution source locations; candidates may reference multiple files. Ambiguous/missing/conflicting matches remain reviewable, not fabricated or silently dropped. Manual versus AI pairing and detailed matching policy remain open. See [linked multi-file ingestion](MULTI_FILE_INGESTION.md).

## AI file pairing with faculty correction — confirmed

User-confirmed: AI identifies and directly links related paper/key/solution files; faculty may correct the pairing afterward. Do not require manual group selection or confirmation before AI pairing runs. Retain model/matching/source provenance, distinguish file grouping from answer alignment and re-evaluate affected candidate associations when pairing is corrected. Ambiguities remain visible for review; protected question edits and published history still follow existing permissions/version rules.

## Faculty-requested solving of missing answers — confirmed

User-confirmed: when an imported question has no answer, faculty can request AI to solve it and fill the answer. On-demand only; no automatic solving for every upload. Preserve model/prompt/source-revision provenance and distinguish AI output from an extracted key. Validate answer format and retain normal QC; generation alone grants neither verified status nor publication. Solutions remain optional. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Faculty-wise AI usage/cost for admin — confirmed

User-confirmed: admin needs faculty-wise AI usage and cost reporting. Record tenant, faculty/requester, operation, model/provider and available usage/cost evidence. Separate provider-reported actual cost, calculated estimates and unavailable values; do not show unknown as zero. Dashboard visibility does not itself define budgets or per-user feature gates. See [AI usage/cost dashboard](AI_USAGE_AND_COST.md).

## Monthly per-faculty AI budgets — confirmed

User-confirmed: admin can configure a monthly AI spending limit for each faculty member. Keep tenant/faculty attribution, budget amount/currency/period and auditable admin changes. This is spending control, not a reversal of default faculty AI tool access. Whether exceeding the limit only warns or blocks new AI work, exact monthly reset semantics, concurrency reservations and cost-reconciliation policy remain open; do not assume a numerical default or threshold behavior.

## Budget thresholds — 80% warning, 100% stop

User-confirmed: issue a warning when a faculty member reaches 80% of their configured monthly AI budget, and stop new AI work at 100%. Enforce the stop at provider dispatch/service boundaries, not only a disabled UI button. Preserve completed results, saved questions and non-AI work. Do not assume in-flight requests are cancelled or final provider bills can never exceed a cap when usage arrives late; define reservation, reconciliation and in-flight handling explicitly. Warning delivery/deduplication and exact monthly reset semantics remain design work.

## Calendar-month usage reset — confirmed

User-confirmed: monthly budget usage starts afresh on the first day of every calendar month. Preserve prior-month usage/cost and audit history; reset the current-period counter, not historical records. Apply the configured faculty limit to the new period. This is not a rolling 30-day window. Exact organization timezone, in-flight request attribution at month boundaries and cost-reconciliation rules remain implementation design work.

## Coaching-owned AI API keys — confirmed

User-confirmed: each coaching supplies its own AI provider API keys instead of using centrally shared platform keys. Resolve secrets per organization for all API/worker operations, preserve credential-reference provenance without secret exposure, and never fall back to another coaching's/shared key. Provider billing belongs to the configured coaching account; application usage/budgets cover recorded app calls. Provider catalogue, secret manager, rotation/validation UX and fallback ordering/attempt limits remain design work; automatic fallback uses only the same coaching's configured keys. See [coaching-owned credentials](TENANT_AI_CREDENTIALS.md).

## Coaching-admin enabled models and default — confirmed

User-confirmed: each coaching admin can enable/select which models from the platform-supported catalogue are available in that coaching and set its default model. Faculty choose from that coaching's enabled, supported, operation-compatible models; default is available for quick use. Resolve only that coaching's provider keys. Tenant configuration cannot introduce arbitrary untested models or bypass capabilities/resource budgets. Automatic fallback with a visible error is confirmed; per-operation default details, fallback order/attempt limits, catalogue updates and UI remain design work.

## Automatic model fallback with visible error — confirmed

User-confirmed: when the selected AI model fails, show a safe, understandable error/failure status and automatically try another enabled, operation-compatible model for the same coaching. Record original selection, failure, fallback attempt and actual model/provider used; do not hide the failure because fallback succeeds. Use only that coaching's configured credentials. Respect supported capabilities, bounded retry/fallback policy and budget reservations; never bypass missing authorization, tenant checks or the 100% budget stop. Preserve successful partial outputs and idempotency. If alternatives fail/unavailable, show an actionable terminal error without fabricating output. Exact fallback order, attempt limits and detailed UI remain design work.

## Automatic own-coaching duplicate checks — confirmed

User-confirmed: every new question is automatically checked against its own coaching's existing question bank for duplicates. Shared downstream rules cover manual/import/generated candidates. Preserve tenant-safe candidate evidence and sources; human QC confirms duplicate/variant/translation disposition before canonical/merge decisions. Do not silently reject/delete uncertain candidates or collapse distinct variants/translations. Exact matching policy/thresholds and final confirmed-duplicate treatment remain open. See [duplicate policy](DUPLICATE_AND_VARIANT_POLICY.md).

## Exact duplicate attaches source without new code — confirmed

User-confirmed: after human review confirms an intake candidate is exactly an existing question, link the new source/provenance to the existing question instead of creating a new master/code. Keep the existing permanent code and matching-version evidence; preserve source/candidate records and review audit. Appending source evidence must not silently overwrite content, answer, solution or published metadata. Conflicting keys or non-identical content require visible review rather than forced duplicate treatment. Existing published duplicate masters/canonical merge policy remains separate; variants/translations retain their confirmed distinct codes.

## Legacy DOC and DOCX inputs — confirmed

User-confirmed: first release supports both legacy .doc and modern .docx Word inputs. Apply the accepted 50 MB/document per-file limit and shared bulk/staging workflow. Keep uploaded original bytes; any conversion/extraction artifact needs source/tool/version provenance and visible warnings. Choose and verify an appropriate legacy parser/converter rather than assuming the proposed DOCX extractor covers legacy files. Preserve equations, tables, figures and source anchors where possible; uncertain/lost structure must remain visible for correction. No converter has been selected, installed or tested.

## Handwritten question photos/scans — first release

User-confirmed: handwritten question photos/scans are included in the first release. Use shared extraction/staging/QC with original/source preservation; flag uncertain text, equations, units and diagrams instead of inventing or silently dropping content. OCR/vision engines, per-language quality, corpus and targets must be evaluated; no accuracy is claimed. Source-figure extraction is distinct from faculty-requested diagram generation/editing. See [OCR and handwriting](OCR_AND_HANDWRITING.md).

## Background jobs, concurrent app use and own-job cancel — confirmed

User-confirmed: faculty may cancel their own running file-processing job. Jobs run in the background; faculty can upload new files and perform other app work while earlier processing continues. Use durable independently traceable job/stage state with resource/budget limits, not a blocking UI request. Cancellation is not source deletion or silent removal of published/reviewed content. Partial-output retention, in-flight acknowledgement and completion races need detailed semantics. See [background jobs/cancellation](BACKGROUND_JOBS_AND_CANCELLATION.md).

## Cancelled jobs retain extracted drafts — confirmed

User-confirmed: cancelling a processing job keeps questions already extracted as draft work. Preserve source/candidate identity, progress, warnings and audit; do not discard completed output or alter already reviewed/published states. Cancellation stops further work according to the acknowledged stage contract, not deletion of originals or saved questions. Retry/resume behavior must not duplicate retained candidates/masters; exact cancelled-job restart UX remains open.

## Admin and creator question archival — confirmed

User-confirmed: archive removes a question from the active bank while retaining content/history. Admin may archive questions in their own coaching, and creator faculty may archive their own question. Complete-bank view or cross-author edit permission alone does not grant archive authority over other creators' questions. Preserve code, immutable published versions, assets, sources/audit and historical references; archival is not physical deletion or admin-only original-file deletion. Restore behavior remains open. See [question archival](QUESTION_ARCHIVAL.md).

## Admin and creator may restore archived questions — confirmed

User-confirmed: both admin and creator may restore archived questions. Admin acts within their coaching; creator acts on their own question. Keep the existing code, content/versions/provenance and archive/restore audit. Restoring availability is not automatic approval/publication of an unreviewed draft or authority to overwrite published content. Detailed state/eligibility and concurrency handling remain design work.

## Video solution link only — confirmed

User-confirmed: video solutions use a stored external video link; video-file upload/hosting is not required for the first release. Video solution metadata remains optional under the handover. Validate safe URL structure and preserve the link in version-scoped metadata; do not fabricate a video URL or claim external content is hosted/archived by this platform. Existing edit permissions and published-version rules apply to link changes. Link/player UI details remain design work; no streaming service or provider has been selected.

## Visual, LaTeX and MathML equation editing — confirmed

User-confirmed: manual equation entry/editing supports visual controls, LaTeX code and MathML code in the first release. Apply shared rich content to relevant stem/options/solution/passage/statements/matching fields, preserving original expression source, preview meaning, multilingual text and version history. Canonical storage, supported syntax/conversion and editor/renderer libraries remain design work; do not claim lossless interchange or silently discard unsupported markup. See [question content editor](QUESTION_CONTENT_EDITOR.md).

## One chapter and one topic per question — confirmed

User-confirmed: a question has only one chapter tag and one topic tag, not multiple chapters/topics. Required chapter/topic classification at publication means one valid selected value of each; incomplete drafts can still omit required values until ready. Preserve optional subtopic and the separately confirmed primary plus multiple secondary concept associations. Multiple concepts do not authorize hidden extra chapter/topic tags. Cross-branch concept association rules remain design work; do not silently remove the multiple-concept requirement.

## Faculty-requested AI correctness checking — confirmed

User-confirmed: the first release includes faculty-requested AI checking of an existing answer and available solution. Keep reviewable findings, reasons/uncertainty and exact input-revision/model provenance; answer-only questions remain eligible because solutions are optional. Checking does not silently replace content or grant QC, approval, publication or an AI-verified badge. Use the existing tenant credentials, enabled-model, budget and background-job policies. Flagging, correction suggestions and explicit opt-in direct correction with visible before/after changes are confirmed; verification-badge criteria remain design/review work. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Opt-in AI corrections with visible changes — confirmed

AI must flag suspected errors and show corrected answer/solution suggestions. Faculty may opt in to direct application, and the interface must still show the old/new values and reason. Without opt-in, the operation leaves existing answers/solutions unchanged. Enforce current same-tenant edit permissions and revision conflict/type-validation checks on actual writes, including background completion; never silently overwrite a concurrent edit. Keep source values and actor/model/input/application provenance. Correcting published content creates an editable new version under the same master/code, retaining the existing published snapshot and normal revision-bound QC/approval/publication controls. Direct-correction opt-in applies to one question at a time, selected separately for that question; no batch-wide or carried-over opt-in. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Matching permits unused right items — confirmed

Match the Column allows right-column items that are unused in the correct answer and serve as distractors. Validation must not require every right item to be selected. Keep one-or-more matches per left item, no right-item sharing across different left items in the correct mapping, variable column counts and four combination options with exactly one correct. Preserve unused item content in storage, extraction, editing and rendering. Example: A→P, B→Q, C→R with right-side S,T unused is valid. See [question types](QUESTION_TYPES_SPECIFICATION.md).

## First-release AI prerequisite relationships — confirmed

AI creates concept-to-concept prerequisite links in release one: which concept should be understood before another. Keep directed stable concept IDs, same-coaching/same-subject endpoints, relationship provenance and graph change history, separate from question tags and taxonomy hierarchy. Cross-subject prerequisite links are not allowed, including AI creation and admin corrections. Cross-class links within the same subject/coaching are allowed, including Class 11 prerequisite → Class 12 dependent; different classes alone must not block such links. Personalized student suggestions/mastery analytics remain later. AI links are immediately usable with AI-added/admin-review-pending status and admin notification; admin can later approve, correct or revoke them. Detailed cycle disposition and educational validation remain design work. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Faculty knowledge graph navigation in release one — confirmed

Faculty can view their coaching's knowledge tree as a graph and click a concept to open linked questions. Query by stable concept ID against primary/secondary question assignments, preserving existing bank access and tenant scope for graph nodes, edges, counts and question navigation. Viewing grants no graph-write, question-edit or QC/approve/publish authority. Show provisional AI/admin-review-pending status and current active links accurately. This is faculty bank navigation; student recommendations/mastery analytics remain later. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Numerical answer cardinality — confirmed

A numerical question supports one exact answer value or one inclusive accepted range, not multiple separate ranges. There is no separate numerical-answer unit field or unit-field publication requirement; preserve units in original evidence, question/equation/solution content without silently converting numeric values. Keep the 0.00–999.00 domain, two-decimal precision, ordered inclusive endpoints and existing precision-flag policy. Imported/AI multi-range evidence must remain visible for authorized correction; do not silently select one interval or bridge the gap by widening it. Incomplete/flagged drafts remain recoverable, but an invalid multi-range key cannot pass type validation for publication. Concrete storage/API representation remains schema design. See [question formats](QUESTION_TYPES_SPECIFICATION.md).

## Concept creation authority — confirmed

Only admin and the authorized AI taxonomy workflow can add new concepts. Faculty cannot manually create concept identities, including through question-tag inputs; they may select existing concepts and correct question assignments within existing edit permissions. AI may add missing concepts during faculty processing under the immediate provisional/admin-notification policy. Enforce trusted actor/tenant checks in the API/service/worker, not a user-supplied AI flag; retain initiating user and actual AI/admin creation provenance. Creation of class, subject, chapter, topic and subtopic entries is also restricted to admin and the authorized AI taxonomy workflow; faculty selects existing entries and cannot create them through free-text tagging or a direct API call. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Multiple admins per coaching — confirmed

A coaching organization may have more than one admin. Represent administration through individual authenticated identities and organization-scoped memberships/authority; do not impose a one-admin-per-organization constraint or require a shared login. Attribute every administrative action to the actual actor and preserve organization ownership of questions and audit history.

Multiple admins do not imply access to other coaching organizations. Each coaching has a principal Owner/Admin who can appoint and remove its other admins. Ordinary admin status does not itself grant admin-appointment/removal authority. The current Owner may transfer principal ownership to another admin in the same coaching. After transfer, the former Owner remains a regular admin in that coaching and loses principal-owner authority. When removing another admin, Owner chooses either conversion to normal faculty or removal from the coaching app with no remaining coaching access. Platform admin creates the coaching and first Owner; onboarding delivery/identity mechanics, owner recovery and exact transfer/removal mechanics remain design work. Existing independent question QC/approve/publish grants and admin-only catalogue/storage/AI configuration policies remain; do not infer that the numeric admin count changes their semantics.

## All admins may remove ordinary faculty — confirmed

Any active coaching admin (including Owner) may remove an ordinary faculty member from that same coaching's app, revoking coaching access while preserving organization questions/assets, attribution, usage and audit history. Check actor and target current membership/role at commit. Ordinary admins cannot use this action on another admin or Owner; admin demotion/removal remains Owner-only. Session/job/asset-access revocation and identity-cleanup mechanics remain design work. See [identity and access](IDENTITY_AND_ACCESS.md).

## Platform-admin onboarding of coaching and first Owner — confirmed

Platform admin creates each coaching organization and its first principal Owner/Admin. Coaching public self-signup is not available. Coaching Owner/admin and faculty membership do not confer platform-level onboarding authority, and a normal Google/password/OTP login cannot self-assign it. After onboarding, the coaching's Owner controls its other admins under the confirmed policy.

Design direction: keep platform authority separate from tenant membership, validate the intended first-owner identity and record platform actor, organization, owner and outcome. Provision the organization/initial-owner relationship consistently, with safe partial-failure/retry handling and no duplicate organizations or extra principal owners from replay. Invitation delivery/acceptance, verified identity linking and initial platform-admin provisioning remain implementation design.

Platform admin now has full cross-coaching application authority, including all question and tenant-administration capabilities, as defined in [platform access](PLATFORM_ADMIN_ACCESS.md). Earlier limited onboarding/read scope is superseded; preserve workflow, version, tenant-reference, secret-handling and audit rules. No organization or real account has been created.

## Explicit platform question-bank read scope — confirmed

Platform admin can view all coaching question banks using explicit platform-read authorization. Ordinary coaching users retain own-coaching isolation; show coaching ownership/context and audit platform reads. Server-side API/RLS/storage/cache rules must distinguish authorized question reads (including retained content assets needed to display them) from unrestricted tenant-data access. No owner/migration-credential or global RLS bypass is implied. The later full-access decision includes originals/storage, credential administration, edits/QC/approve/publish and supported AI/other application actions; this read-path description is not a limit on the platform role. See [identity and access](IDENTITY_AND_ACCESS.md).

## Explicit platform question editing — confirmed

Platform admin may edit questions in all coaching organizations through explicit platform-edit authorization and target-coaching context. Enforce type/content validation, current revision and tenant-consistent references, and record platform actor plus before/after evidence without transferring coaching ownership/creator attribution. Published corrections create an editable new version under the same master/code; preserve the existing published version and revision-bound QC/approval rules. The later full-access decision also grants QC/approve/publish, supported archive/delete, original-source/credential administration and supported AI/other app actions; the edit-path description is not a limit on platform authority. Use a reviewed restricted API/RLS write policy rather than unrestricted database bypass. See [identity and access](IDENTITY_AND_ACCESS.md).

## Current platform authority — full access

Platform admin has full application access across all coachings, including question QC/approve/publish, originals/storage, users/Owners/roles, taxonomy, AI credentials/configuration/budgets/jobs and analytics. Earlier limited platform read/edit exclusions are superseded. Coaching roles retain their own-coaching boundaries. Validation, published-version preservation, current authority checks, coaching data ownership, secret handling and audit remain required. Full authority covers supported features and does not move deferred test/student features into release one. See [the platform access specification](PLATFORM_ADMIN_ACCESS.md).

## Coaching name and logo in the app — confirmed

Each coaching may display its own name and logo in the application. Include per-coaching branding in the first-release tenant configuration and show it consistently in that coaching's app context. This is display branding, separate from internal organization identity, question ownership and the globally unique question-code scheme. Renaming or replacing a logo does not move data, change question codes or rewrite historical attribution.

Design direction: store a display name and a coaching-owned logo asset reference; validate name/content and image assets through the supported upload/rendering policy. Avoid cross-coaching asset links or cached branding leakage. A missing/unavailable logo should have a clear usable fallback, not prevent question-bank work. Use accessible labeling and preserve the selected coaching context in platform-admin views.

Only platform admin may create/change coaching display name/logo settings. Coaching Owner/admin/faculty cannot change these branding settings; there is no tenant-side branding edit grant. Exact image formats/dimensions/limits, settings UI and public/pre-login placement remain implementation design. Custom domains, color themes, hiding platform identity and later export branding are not established by this name/logo confirmation. No app UI or logo asset has been created.

## One shared app website/link for all coachings — confirmed

All coaching organizations use the same app website/entry link. Do not require a separate domain, subdomain or coaching-specific entry link for each organization in the first release. Ordinary question/detail links may still exist within the shared application; this decision is about a common entry point, not eliminating resource routes.

After sign-in, resolve a coaching user's organization and branding from their trusted identity/membership. Faculty remains bound to one coaching with no cross-coaching switcher. Never use the shared URL or a client-supplied tenant value as business-access authority. Platform admin may select an explicit coaching context under the full platform role, retaining actor/target audit.

Use tenant-safe API, private-asset, session and cache context so the shared entry cannot mix coaching names/logos, questions or sources. Platform admin alone changes coaching branding. Missing/unavailable logo behavior remains usable; exact anonymous/pre-login branding and routes are UI design. The chosen common domain, hosting, physical database/deployment arrangement and commercial billing remain separate decisions. Shared website does not weaken data ownership/isolation or create public coaching signup. No website or domain has been created.

## Coaching subscription/payment collection — later phase

Coaching subscription and payment collection are explicitly deferred beyond the first release. Initial coaching onboarding and question-bank workflows do not depend on creating a subscription, plan or payment record. Future pricing, commercial plans, invoicing, payment gateway, renewal/expiry and subscription enforcement need their own approved specification before implementation; this is not a commitment to permanent free access.

First-release AI usage/cost reporting, coaching-owned provider credentials and monthly faculty spending controls remain required. Provider charges associated with a coaching's own API keys and application AI-budget accounting are separate from the platform collecting subscription payments. Keep 80% warning/100% new-AI-work stop and monthly reset/history under the existing policy. No payment system, plan or billing integration has been created.

## Expected bank size — confirmed, 18 October 2026

The question bank is expected to contain lakhs of questions, with only a small initial faculty group. This is a corpus-scale requirement rather than an exact count, account/storage cap or speed guarantee. Search/filter/count, concept-linked navigation, duplicate checks and nonblocking imports need representative scale validation. Exact initial-load timing, files/assets, concurrency and numerical performance targets remain open. See [capacity and performance](CAPACITY_AND_PERFORMANCE.md).

## Adaptive ingestion now; learning delivery later — confirmed

First release includes AI discovery/saving of reusable document-layout patterns and automatic reuse for compatible files, targeting fewer extraction tokens/faster processing with validation/fallback. Include handwritten questions and solutions. Samples will arrive later; no savings/quality benchmark exists. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md).

Later phases include faculty courses, live classes, recorded sessions and AI teaching/concept videos personalized to a student's need/current level. These are future modules, not first-release video hosting or a change to the optional external video-solution link. See [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).

## Coaching-specific patterns and platform dataset sharing - confirmed

Each coaching keeps its data/pattern library separate. Platform admin may explicitly share the complete dataset, patterns and associated material with another coaching. Ordinary coaching roles cannot initiate cross-coaching sharing. Preserve an explicit source/target manifest, complete dependency mapping, question-code/version integrity and platform actor history. Sharing creates a one-time independent initial copy with no ongoing updates in either direction; destination may use/change its own copy. Preserve mapped independent identities/new globally unique codes for new question masters and source provenance. Destination users and API keys are set up separately, not copied; keep source actor/model evidence as provenance, not active memberships/secrets. Source-published questions retain published status without mandatory local re-review on copy; preserve imported QC evidence and immutable snapshots, with later edits using normal new-version review. Destination conflict/failure and operational-reference details remain design work. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## Published status in independent coaching copies - confirmed

When platform admin copies an existing coaching dataset, source-published question snapshots remain published in the destination without mandatory re-review merely for copying. Preserve source QC/publication provenance, the platform copy actor and exact version/dependency mapping; do not invent destination reviewer identities. New destination question masters still receive new globally unique codes. Validate complete snapshot/reference integrity; do not promote source drafts/unreviewed content. Later destination edits create a new editable version under the destination code and follow normal QC/approval/publication; copied published snapshots stay immutable. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## AI concept/prerequisite alerts: in-app only - current rule

AI-added concepts and prerequisite links notify all active admins in the originating coaching, including Owner, inside the app only. Email notifications are cancelled for the current release. There is no notification-email provider, delivery queue, email digest or separate mandatory admin email-contact requirement for these alerts. Existing Google/email-password/mobile-OTP login choices and their identity requirements remain unchanged.

Preserve immediate provisional use: alerts/review do not add a prior approval gate or block valid AI tagging. Store tenant/entity/version-correct events and per-recipient notification/read state, with AI provenance and authenticated review links. Deduplicate event/recipient records on retry; read/dismiss and shared concept/link review outcomes are distinct. Recheck active admin membership on notification access so removed/demoted users cannot rely on stale recipient records. No other-coaching broadcast is introduced.

Notification persistence/recovery must not duplicate taxonomy additions or falsely report completed review. Detailed in-app presentation, retention and newly appointed admin access to old alerts remain implementation design. No message or application notification has been sent.

## One user account across linked login methods - confirmed

Google, email/password and mobile OTP can be linked to the same canonical application user account. After linking, any configured method opens the same account with the same coaching membership, grants, creator/reviewer attribution, usage/budget identity and history. Do not create a separate app account or independent permissions merely because the sign-in method changes.

This is support for alternative linked methods, not a requirement to complete all three on every login or force every user to configure every method. Email/password credentials are needed only when that method is configured; the separate notification-email requirement remains withdrawn and alerts remain in-app only.

Design direction: verify control of the existing identity and added sign-in method using the chosen provider. Matching email/phone labels alone cannot merge accounts, expand membership, recover another user's account or grant admin/platform authority. Existing identity/link collisions require an explicit safe resolution, not silent data/role union. Current membership/role checks remain server-side for every method; revoked membership stays revoked. Exact provider, contact change/unlink/recovery and multi-device/session policy remain design work. No identities/accounts have been linked.

## Simultaneous mobile and laptop sessions - confirmed

A user may stay signed in on mobile and laptop at the same time. Signing in through another configured linked method/device does not automatically replace the first valid session. Both resolve to the same canonical account/coaching grants, history, notification state and AI usage/budget identity.

Design direction: maintain distinct session/device identifiers and current server-side identity/role checks. Role/membership revocation must take effect across devices, and no session may retain former Owner/platform authority solely from stale login state. Shared job/idempotency and revision-conflict rules still apply to simultaneous uploads/actions/edits; two sessions cannot create separate AI budgets or duplicate a charged operation by replay.

The user has not selected an exact device cap, session duration or an unlimited-session guarantee. No user-facing logged-in-device list or remote per-device logout manager is required in this release. Normal sign-out on the current device remains; simultaneous mobile/laptop sessions and server-side authorization/revocation checks remain. Exact cookie/token/provider/session implementation remains design work. No sessions/accounts have been created.

## No device-list or remote-device logout UI - confirmed

The current release does not include a screen listing logged-in devices or letting a user select another device to log it out. Keep normal sign-out for the current session and the confirmed simultaneous mobile/laptop access. This does not remove technical session expiry/revocation or current membership/role checks on all devices; account removal, demotion and ownership/platform-role changes cannot leave stale authority active merely because there is no device-management UI. Exact provider/session lifetime/cap mechanics remain design work. No sessions or account data have changed.


## Initial AI provider scope - confirmed 18 October 2026

User-confirmed (18 October 2026): first-release AI provider support includes Google, Anthropic, OpenAI and OpenRouter, with an extensible adapter/catalogue design for adding more providers later. Each coaching configures its own credentials; existing enabled-model/default selection, compatible automatic fallback with visible failure, usage provenance and budget controls continue. Provider selection does not mean credentials are available or integrations tested. Specific API products, model identifiers, operation capabilities, data handling, prices and routing/attribution details require current official-source verification during design. Adding a provider later requires an implemented and validated adapter/catalogue entry; it is not arbitrary endpoint execution.


## Local development hosting - confirmed 18 October 2026

User-confirmed (18 October 2026): the development app will be hosted on this PC. Production hosting is deferred; do not infer public PC hosting, remote faculty access, a purchased cloud account or a production deployment. The assistant should propose a local development setup with persistent data/assets, background jobs and configuration boundaries compatible with later hosting. Stack/runtime/resource compatibility and representative performance are not verified. No dependencies have been installed and no server or application has been started.

The monthly hosted-server/storage budget question is deferred with production hosting; this is a planning consequence, not an approved zero-cost or unlimited budget. Coaching-owned AI APIs and their usage/budget controls remain separate. The current interview has no further required user questions; design consolidation and document review must precede code.
