# Upload and Asset Policy — First-Release Baseline

Status: user-confirmed upload categories and per-file size limits, 17 October 2026. Detailed extensions/parser support and resource controls remain design work. No upload implementation exists.

## Confirmed decisions

- PDF, Word documents and images are included in the first release.
- Faculty may upload multiple files in one bulk submission, including a mix of supported PDF, Word and image sources.
- Maximum document size: **50 MB per file**.
- Maximum image size: **10 MB per file**.
- The user delegated selecting sensible initial size limits and then explicitly accepted these values. These are project defaults, not a claim of an industry standard.
- User-visible size labels and exact byte conversion must be specified consistently in the eventual API/UI. Proposed decimal interpretation: 50,000,000 and 10,000,000 bytes; not yet a separately approved product requirement.

## Supported categories versus exact formats

| Category | Current scope | Remaining design work |
| --- | --- | --- |
| PDF | Original source document, text extraction or OCR where needed | Page/encryption/corrupt-file policy and parser limits |
| Word | Both DOCX and legacy DOC are confirmed for first release | Choose/verify legacy parsing or conversion path; preserve originals, assets and conversion provenance |
| Images | Standalone image ingestion/OCR and question/source assets are now in release scope | Exact raster extensions, dimensions, multipage handling and unsupported formats |

"All" was stated in response to the categories PDF, Word and images. It does not establish support for arbitrary executable/archive/other file types. Final extension lists, MIME/signature validation and parser/decoder support must be explicit. Rich vector/animated formats need separate review if required.

## Processing and ownership

Originals are private, organization-owned and immutable with checksum and source metadata. Authorization applies to uploads, source previews, embedded assets, downloads and AI inputs. Image-origin candidates retain source-image references rather than invented PDF page numbers. Whether an image is a complete question source or an illustration attachment must be represented explicitly.

All accepted sources join the same staging/review workflow. Upload success does not imply parsing success or publication. Human checks, type validation and admin-granted approval/publication permissions still apply.

## Controls to finalize

Per-job file count, aggregate bytes, PDF page count, decoded image pixels/frames, decompressed DOCX resources, processing time and organization storage quotas need bounded policies. A small compressed file can consume much larger parser resources; per-file limits do not replace those controls. Choose these during implementation design/corpus evaluation without claiming they are approved numerical targets now.

## Acceptance checks

Verify document/image boundary sizes after byte semantics are finalized, over-limit rejection, mismatched MIME/signatures, malformed input, tenant isolation, observable decoding/OCR failure and source preservation. Test image question extraction separately from embedded-asset handling. Do not report image support complete merely because bytes can be stored.

## Confirmed AI and original-source lifecycle update

AI directly fills validated editable metadata without a per-field approval gate. New concepts may be added and used immediately with AI-added/admin-review-pending status. Notify admin for later approve/edit/merge/revoke; revocation stops new automatic use and preserves published snapshots. This supersedes the earlier approval-first rule; question approve/publish permissions remain separate.

Retain original source files until admin chooses deletion. Only admin can see storage analytics and delete originals; faculty can view their organization's originals. Original deletion must preserve saved questions and independently retained required diagrams/assets, show source-unavailable status honestly and record the deletion. No automatic expiry has been selected. See [source lifecycle](SOURCE_STORAGE_AND_RETENTION.md).

## Bulk mixed-source upload — confirmed

User-confirmed: first release supports bulk upload of multiple PDF, Word and image files in one submission. Preserve per-file validation, source identity/checksum, tenant scope and observable progress/errors; existing 50 MB/document and 10 MB/image limits remain per file. Bulk upload does not bypass staging/QC or imply automatic publication. Exact maximum file count, aggregate bytes, resumable transport and handling of separate paper/answer-key associations remain design work.

## Link separate paper, answer key and solution sources — confirmed

User-confirmed: question papers and their answer keys/solutions may be separate files and must be linkable for joint processing in the first release. Preserve group identity and independent question/answer/solution source locations; candidates may reference multiple files. Ambiguous/missing/conflicting matches remain reviewable, not fabricated or silently dropped. Manual versus AI pairing and detailed matching policy remain open. See [linked multi-file ingestion](MULTI_FILE_INGESTION.md).

## Legacy DOC and DOCX inputs — confirmed

User-confirmed: first release supports both legacy .doc and modern .docx Word inputs. Apply the accepted 50 MB/document per-file limit and shared bulk/staging workflow. Keep uploaded original bytes; any conversion/extraction artifact needs source/tool/version provenance and visible warnings. Choose and verify an appropriate legacy parser/converter rather than assuming the proposed DOCX extractor covers legacy files. Preserve equations, tables, figures and source anchors where possible; uncertain/lost structure must remain visible for correction. No converter has been selected, installed or tested.

## Handwritten question photos/scans — first release

User-confirmed: handwritten question photos/scans are included in the first release. Use shared extraction/staging/QC with original/source preservation; flag uncertain text, equations, units and diagrams instead of inventing or silently dropping content. OCR/vision engines, per-language quality, corpus and targets must be evaluated; no accuracy is claimed. Source-figure extraction is distinct from faculty-requested diagram generation/editing. See [OCR and handwriting](OCR_AND_HANDWRITING.md).

## Video solution link only — confirmed

User-confirmed: video solutions use a stored external video link; video-file upload/hosting is not required for the first release. Video solution metadata remains optional under the handover. Validate safe URL structure and preserve the link in version-scoped metadata; do not fabricate a video URL or claim external content is hosted/archived by this platform. Existing edit permissions and published-version rules apply to link changes. Link/player UI details remain design work; no streaming service or provider has been selected.
