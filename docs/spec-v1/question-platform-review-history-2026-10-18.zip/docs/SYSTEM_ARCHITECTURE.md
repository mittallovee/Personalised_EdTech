# System Architecture (Proposed)

## Design details for review

No application exists. Module boundaries below are architectural proposals; the agreed approach is a modular monolith with workers. Stack selection remains D-04.

### Trusted request and worker boundaries

1. Authenticate identity using the selected strategy.
2. Resolve active organization and validate current membership/action permission.
3. Open a database transaction and establish trusted tenant context for that transaction.
4. Load/write tenant-scoped resources with tenant-aware relationships.
5. Commit the business action and required audit data consistently; clear context before the connection is reused.

A worker receives a minimal job reference rather than trusting arbitrary queued tenant/content data. It validates the tenant/job relationship, establishes its own scoped DB context and object access, and uses least-privileged runtime credentials. A queue message is not proof of authorization.

### Upload, transaction and queue consistency

Object storage, PostgreSQL and a broker do not share a single database transaction. The design must handle objects stored before DB failure and jobs committed before enqueue failure. **Proposed:** pending object lifecycle plus a transactional outbox/dispatcher or equivalently recoverable enqueue mechanism, with reconciliation of orphaned objects and undispatched jobs. This mechanism is not yet selected or implemented. A job must never appear accepted and then disappear silently due to a crash between commit and enqueue.

### Module contracts

- Files owns storage metadata and validated original access; extraction uses the adapter rather than public URLs.
- Ingestion owns attempts/stages and delegates extraction/parsing without owning publication decisions.
- Staging owns candidates, warnings and source references. Question bank creates/links masters and versions through authorized, idempotent actions.
- Review owns transitions and decision evidence, not a second editable copy of published content.
- AI owns suggestions/provenance; business modules validate and explicitly accept allowed changes.
- Test builder stores exact version links and immutable snapshots according to the chosen test policy.
- Audit records actor/action/context while minimizing logged content and secrets.

### Concurrency and recovery

Concurrent draft edits, duplicate confirmation and publication require a reviewed conflict strategy, such as optimistic revision tokens with transactional state checks. Queue delivery may repeat; each stage must tolerate at-least-once execution. Long work should avoid holding request transactions open. A worker crash must leave a diagnosable/retryable state rather than marking the job successfully completed.

### Deployment planning

Local development should use disposable isolated dependencies, separate runtime/migration credentials and no production connection assumptions. API and worker share versioned contracts and migrations. Remote deployment, scale targets, network exposure and production recovery are D-18. No service-splitting, provider or performance claim is approved by this design draft.

## Approach
Start with a modular monolith for the API plus separate background worker processes. Keep module boundaries clear so services can be split later based on measured scaling needs.

## Logical flow
Faculty UI → FastAPI → validation and job creation → object storage + PostgreSQL → queue → worker → extraction/OCR → segmentation → structured parsing → optional AI suggestions/duplicate candidates → staging/review UI → question bank/versioning → test builder.

## Modules
- organizations: tenant records and membership
- auth/access: identity, sessions/tokens, roles, permissions
- files: upload validation, object-storage adapter, checksums
- ingestion: jobs, retry, status, idempotency
- extraction: PDF/DOCX extraction and OCR
- segmentation: question boundary candidates
- parsing: options, answer, solution, tables/equations/assets
- taxonomy: classes, subjects, chapters, topics, concepts
- question_bank: master questions and versions
- relationships: variants, translations, duplicates
- review: reviewer queues, decisions, QC status
- ai_orchestrator: model catalogue, routing, provenance, usage controls
- test_builder: filters, test composition, pinned question versions
- audit/observability: audit events, logs, metrics

## Suggested repository layout
```text
question-platform/
  apps/
    faculty-web/
  services/
    api/
      app/
        modules/
        workers/
        core/
        main.py
      tests/
  infrastructure/
    docker/
  migrations/
  docs/
  docker-compose.yml
  README.md
```

## API design principles
- Version APIs (e.g. `/api/v1/...`).
- Use explicit schemas and validation.
- Long-running work returns a job ID; clients poll or subscribe for status.
- Use idempotency keys/checksums to prevent accidental duplicate jobs.
- Do not expose unauthenticated development endpoints outside local development.
- Keep file storage behind an adapter and use signed URLs where appropriate.

## Operational principles
- Keep original file immutable.
- Store processing outputs and errors by stage.
- Retry transient failures; do not endlessly retry malformed inputs.
- Keep worker tasks idempotent.
- Add tracing/correlation IDs across API, queue, and worker.
- Do not adopt full microservices until operational need is demonstrated.

## Release-one scope alignment

The first usable release includes question-bank entry/upload/review/database saving, all nine formats, PDF/Word/images, and AI-managed taxonomy/tagging. Test creation/export and student delivery remain later. Admin configures approval/publication grants independently. Stable catalogue/concept identities support later recommendations without implementing student analytics now.

## Confirmed AI and original-source lifecycle update

AI directly fills validated editable metadata without a per-field approval gate. New concepts may be added and used immediately with AI-added/admin-review-pending status. Notify admin for later approve/edit/merge/revoke; revocation stops new automatic use and preserves published snapshots. This supersedes the earlier approval-first rule; question approve/publish permissions remain separate.

Retain original source files until admin chooses deletion. Only admin can see storage analytics and delete originals; faculty can view their organization's originals. Original deletion must preserve saved questions and independently retained required diagrams/assets, show source-unavailable status honestly and record the deletion. No automatic expiry has been selected. See [source lifecycle](SOURCE_STORAGE_AND_RETENTION.md).

## First-release login methods — confirmed

User-confirmed: Google login, email/password and mobile OTP are all required in the first release as alternative sign-in methods. Identity provider/session implementation, account linking, OTP delivery and onboarding remain open. Authentication does not grant organization membership or action permissions. See [identity and access](IDENTITY_AND_ACCESS.md).

## Bulk mixed-source upload — confirmed

User-confirmed: first release supports bulk upload of multiple PDF, Word and image files in one submission. Preserve per-file validation, source identity/checksum, tenant scope and observable progress/errors; existing 50 MB/document and 10 MB/image limits remain per file. Bulk upload does not bypass staging/QC or imply automatic publication. Exact maximum file count, aggregate bytes, resumable transport and handling of separate paper/answer-key associations remain design work.

## Coaching-owned AI API keys — confirmed

User-confirmed: each coaching supplies its own AI provider API keys instead of using centrally shared platform keys. Resolve secrets per organization for all API/worker operations, preserve credential-reference provenance without secret exposure, and never fall back to another coaching's/shared key. Provider billing belongs to the configured coaching account; application usage/budgets cover recorded app calls. Provider catalogue, secret manager, rotation/validation UX and fallback ordering/attempt limits remain design work; automatic fallback uses only the same coaching's configured keys. See [coaching-owned credentials](TENANT_AI_CREDENTIALS.md).

## Legacy DOC and DOCX inputs — confirmed

User-confirmed: first release supports both legacy .doc and modern .docx Word inputs. Apply the accepted 50 MB/document per-file limit and shared bulk/staging workflow. Keep uploaded original bytes; any conversion/extraction artifact needs source/tool/version provenance and visible warnings. Choose and verify an appropriate legacy parser/converter rather than assuming the proposed DOCX extractor covers legacy files. Preserve equations, tables, figures and source anchors where possible; uncertain/lost structure must remain visible for correction. No converter has been selected, installed or tested.

## Handwritten question photos/scans — first release

User-confirmed: handwritten question photos/scans are included in the first release. Use shared extraction/staging/QC with original/source preservation; flag uncertain text, equations, units and diagrams instead of inventing or silently dropping content. OCR/vision engines, per-language quality, corpus and targets must be evaluated; no accuracy is claimed. Source-figure extraction is distinct from faculty-requested diagram generation/editing. See [OCR and handwriting](OCR_AND_HANDWRITING.md).

## Background jobs, concurrent app use and own-job cancel — confirmed

User-confirmed: faculty may cancel their own running file-processing job. Jobs run in the background; faculty can upload new files and perform other app work while earlier processing continues. Use durable independently traceable job/stage state with resource/budget limits, not a blocking UI request. Cancellation is not source deletion or silent removal of published/reviewed content. Partial-output retention, in-flight acknowledgement and completion races need detailed semantics. See [background jobs/cancellation](BACKGROUND_JOBS_AND_CANCELLATION.md).

## Visual, LaTeX and MathML equation editing — confirmed

User-confirmed: manual equation entry/editing supports visual controls, LaTeX code and MathML code in the first release. Apply shared rich content to relevant stem/options/solution/passage/statements/matching fields, preserving original expression source, preview meaning, multilingual text and version history. Canonical storage, supported syntax/conversion and editor/renderer libraries remain design work; do not claim lossless interchange or silently discard unsupported markup. See [question content editor](QUESTION_CONTENT_EDITOR.md).

## First-release AI prerequisite relationships — confirmed

AI creates concept-to-concept prerequisite links in release one: which concept should be understood before another. Keep directed stable concept IDs, same-coaching/same-subject endpoints, relationship provenance and graph change history, separate from question tags and taxonomy hierarchy. Cross-subject prerequisite links are not allowed, including AI creation and admin corrections. Cross-class links within the same subject/coaching are allowed, including Class 11 prerequisite → Class 12 dependent; different classes alone must not block such links. Personalized student suggestions/mastery analytics remain later. AI links are immediately usable with AI-added/admin-review-pending status and admin notification; admin can later approve, correct or revoke them. Detailed cycle disposition and educational validation remain design work. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Explicit platform question-bank read scope — confirmed

Platform admin can view all coaching question banks using explicit platform-read authorization. Ordinary coaching users retain own-coaching isolation; show coaching ownership/context and audit platform reads. Server-side API/RLS/storage/cache rules must distinguish authorized question reads (including retained content assets needed to display them) from unrestricted tenant-data access. No owner/migration-credential or global RLS bypass is implied. The later full-access decision includes originals/storage, credential administration, edits/QC/approve/publish and supported AI/other application actions; this read-path description is not a limit on the platform role. See [identity and access](IDENTITY_AND_ACCESS.md).

## Explicit platform question editing — confirmed

Platform admin may edit questions in all coaching organizations through explicit platform-edit authorization and target-coaching context. Enforce type/content validation, current revision and tenant-consistent references, and record platform actor plus before/after evidence without transferring coaching ownership/creator attribution. Published corrections create an editable new version under the same master/code; preserve the existing published version and revision-bound QC/approval rules. The later full-access decision also grants QC/approve/publish, supported archive/delete, original-source/credential administration and supported AI/other app actions; the edit-path description is not a limit on platform authority. Use a reviewed restricted API/RLS write policy rather than unrestricted database bypass. See [identity and access](IDENTITY_AND_ACCESS.md).

## Current platform authority — full access

Platform admin has full application access across all coachings, including question QC/approve/publish, originals/storage, users/Owners/roles, taxonomy, AI credentials/configuration/budgets/jobs and analytics. Earlier limited platform read/edit exclusions are superseded. Coaching roles retain their own-coaching boundaries. Validation, published-version preservation, current authority checks, coaching data ownership, secret handling and audit remain required. Full authority covers supported features and does not move deferred test/student features into release one. See [the platform access specification](PLATFORM_ADMIN_ACCESS.md).

## One shared app website/link for all coachings — confirmed

All coaching organizations use the same app website/entry link. Do not require a separate domain, subdomain or coaching-specific entry link for each organization in the first release. Ordinary question/detail links may still exist within the shared application; this decision is about a common entry point, not eliminating resource routes.

After sign-in, resolve a coaching user's organization and branding from their trusted identity/membership. Faculty remains bound to one coaching with no cross-coaching switcher. Never use the shared URL or a client-supplied tenant value as business-access authority. Platform admin may select an explicit coaching context under the full platform role, retaining actor/target audit.

Use tenant-safe API, private-asset, session and cache context so the shared entry cannot mix coaching names/logos, questions or sources. Platform admin alone changes coaching branding. Missing/unavailable logo behavior remains usable; exact anonymous/pre-login branding and routes are UI design. The chosen common domain, hosting, physical database/deployment arrangement and commercial billing remain separate decisions. Shared website does not weaken data ownership/isolation or create public coaching signup. No website or domain has been created.

## Initial usage and sizing boundary

Launch is one coaching with a small initial faculty group. Question-bank size is expected in lakhs; exact corpus count, active/concurrent users, upload volume and latency/throughput targets remain unquantified. Do not translate “very few” into a fabricated account cap or performance claim. Keep the agreed modular monolith/background-worker architecture and tenant isolation, with representative measurements and resource sizing when implementation/evaluation exists. No load test or sizing benchmark has run.

## Lakh-scale bank with few faculty — confirmed

Size question-bank data access and duplicate candidate retrieval for lakhs of stored questions, while keeping the initial small-user rollout and existing architecture. Use bounded query/graph result loading and recoverable background work; indexing, resources and numerical targets require representative measurements. See [capacity and performance](CAPACITY_AND_PERFORMANCE.md).

## Adaptive extraction and later learning boundaries

Add a versioned pattern registry/selector and AI-bootstrap/reuse/fallback stages within ingestion/background workers. Record pattern/configuration, coverage/validation, model/token/cost evidence and drift failures. Patterns are validated configuration, not executable model-generated code. Handwritten questions/solutions require fresh recognition; patterns are coaching-specific with explicit platform-managed complete-dataset sharing; sharing is an independent initial copy without continuing synchronization. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md).

Future courses/live/recorded media and personalized AI teaching/videos use tenant identity, concepts, audit, jobs and media access. No extra deployment, live-media provider or future production schema is selected now. See [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).

## Coaching-specific patterns and platform dataset sharing - confirmed

Each coaching keeps its data/pattern library separate. Platform admin may explicitly share the complete dataset, patterns and associated material with another coaching. Ordinary coaching roles cannot initiate cross-coaching sharing. Preserve an explicit source/target manifest, complete dependency mapping, question-code/version integrity and platform actor history. Sharing creates a one-time independent initial copy with no ongoing updates in either direction; destination may use/change its own copy. Preserve mapped independent identities/new globally unique codes for new question masters and source provenance. Destination users and API keys are set up separately, not copied; keep source actor/model evidence as provenance, not active memberships/secrets. Source-published questions retain published status without mandatory local re-review on copy; preserve imported QC evidence and immutable snapshots, with later edits using normal new-version review. Destination conflict/failure and operational-reference details remain design work. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).


## Local development hosting - confirmed 18 October 2026

User-confirmed (18 October 2026): the development app will be hosted on this PC. Production hosting is deferred; do not infer public PC hosting, remote faculty access, a purchased cloud account or a production deployment. The assistant should propose a local development setup with persistent data/assets, background jobs and configuration boundaries compatible with later hosting. Stack/runtime/resource compatibility and representative performance are not verified. No dependencies have been installed and no server or application has been started.

The monthly hosted-server/storage budget question is deferred with production hosting; this is a planning consequence, not an approved zero-cost or unlimited budget. Coaching-owned AI APIs and their usage/budget controls remain separate. The current interview has no further required user questions; design consolidation and document review must precede code.
