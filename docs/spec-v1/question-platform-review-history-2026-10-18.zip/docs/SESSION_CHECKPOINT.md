# Requirements Review — Continuation Checkpoint

Last updated: 18 October 2026. Requirements review has resumed in text after the voice session. **No application code has been started.** Continue requirements review before implementation and ask one question at a time.

## Current confirmed decisions

1. Start with one coaching institute; support many organizations in the architecture from the beginning with tenant isolation.
2. First release: question bank, manual entry/upload, review and database storage. Test creation and test-paper export come later; student delivery/analytics are later still.
3. Admin defines approval and publication permissions for each user independently. Creator may act on own content only with the corresponding grants. Creation/upload alone grants neither.
4. All nine question formats belong in release one. SCQ has four options and one correct answer; multiple-correct has four options. Integer range is 0–999; single digit 0–9; numerical 0.00–999.00 with two decimal places. Matching, assertion–reason, passage and multiple-statement are included. See the type specification for open structural details.
5. PDF, Word and images are included. Accepted limits: 50 MB/document and 10 MB/image. Exact extension support, byte interpretation and parser resource limits remain design work.
6. Detailed taxonomy includes class/subject/chapter/topic/subtopic and primary plus multiple secondary concepts. No fixed maximum of two secondary concepts was approved.
7. AI creates/maintains the taxonomy and fills metadata directly after validation. Existing concepts are reused; missing concepts may be created and used immediately with AI-added/admin-review-pending status. Notify admin, who can approve/edit/merge/revoke later. This supersedes approval-first. Human question QC, authorization and published immutability remain required.
8. Normal question view shows final/current metadata, not a required per-field history. Internal audit and model/prompt provenance remain.
9. Retain original ingestion files until admin chooses deletion using storage analytics. Storage dashboard and original deletion are admin-only. Faculty may view originals within their organization. Saved questions and required assets survive original deletion.
10. Explicit initial languages: English, Hindi, Gujarati. Four additional defaults selected under the user's prevalence criterion: Bengali, Marathi, Telugu, Tamil. Admin may add languages. See the language document for the historical data basis and capability-verification requirements.
11. Display one question language at a time. Metadata follows the question language; an English metadata duplicate is not mandatory.
12. Faculty requests translation after source-question review completes. No automatic translation into every language. Prior source publication was not made a requirement.
13. A translated question has a new permanent question code/distinct master, its own versions, and a translation-of link to the original and reviewed source version.
14. Original and translated questions may be updated independently. No mandatory simultaneous update or automatic overwrite. Published corrections still create a new version under the affected question's stable code.

15. In Match the Column, a left-column item may match one or multiple right-column items.
16. Matching questions present exactly four options containing matching combinations, rather than direct match-entry as the selected response format.
17. Exactly one matching-combination option is correct; a left item can still have multiple right matches.
18. Column item counts may change according to the question; do not fix both columns at four items. Exactly four response options remains a separate requirement.
19. Confirmed: in the correct matching, a right-column item cannot match multiple different left-column items. One left item may still match multiple right items. Practical limits and labels remain open; unused right items are confirmed in decision 84 below.

20. Assertion–Reason has exactly four options and exactly one correct answer.
21. Confirmed: Assertion–Reason option text can change by question; no mandatory fixed option-text template. Detailed semantic QC/examples remain to be specified.

22. Multiple Statement questions have exactly four response options and exactly one correct answer.
23. Confirmed: the number of statements varies by question; no fixed statement count. Practical count limits and labels remain design details.

24. One passage can have mixed child types, such as SCQ, numerical and integer, each with its own format/answer rules.
25. Confirmed: each passage subquestion gets its own permanent question code and remains linked to the shared passage. Passage sharing/versioning and exact allowed child-type catalogue remain design work.

26. Confirmed: Multiple Option Correct may have a single correct option; one or more of its four options may be correct. Do not require at least two or reclassify it automatically as SCQ.

27. Confirmed: numerical answers with extra decimal places are flagged for review, preserving the original value; no automatic rounding (e.g. 12.345 must not silently become 12.35).

28. Numerical answer keys may be an exact value or an accepted range; endpoints follow the existing domain/precision.
29. Confirmed: both endpoints of a numerical answer range are included; 9.79–9.81 accepts 9.79 and 9.81. Multiple accepted ranges are disallowed by decision 90 below.

30. Confirmed: a correct answer is sufficient without a solution/explanation for publication. Solution is optional; other question validation, review, required metadata and publication permissions still apply.

31. Confirmed: primary concept tagging is required before publication. Missing primary concept blocks publication; drafts can remain incomplete. AI-added review-pending concepts remain immediately usable under the existing policy.

32. Class, subject, chapter and topic are required before publication, alongside primary concept and correct answer. Drafts can be incomplete.
33. Confirmed: subtopic is optional, including at publication; validate it if supplied. Other metadata completeness remains under review.

34. Confirmed: difficulty level on the agreed 1–10 scale is required before publication; missing/out-of-range values block publication, while drafts may remain incomplete.

35. Confirmed: Bloom taxonomy level is mandatory before publication; AI fills it directly and authorized users can correct it. Missing/invalid level blocks publication; drafts may be incomplete.

36. PYQ-marked questions require exam name and year before publication. Non-PYQ questions are not forced to carry them; incomplete drafts may be saved.
37. Confirmed: PYQ date, shift/slot and paper code are optional; their absence must not block publication. Current field requirements are consolidated in PUBLICATION_REQUIREMENTS.md.

38. Confirmed: review may return a question to its creator for correction; the creator can correct and resubmit for review. Preserve identity/history and authorize transitions; final rejection, reasons and reassignment details remain open.

39. Confirmed: permanent question codes are globally unique across the whole platform, including different coaching organizations. This supersedes the original tenant-scoped preference; tenant ownership/access boundaries remain unchanged.

40. Confirmed: permanent question codes are exactly eight alphanumeric characters, globally unique across the platform. Exact alphabet/case and lifecycle details remain design work.

41. Confirmed: a new practice variant created by changing values/conditions gets a distinct permanent code/master and explicit variant-of link to the original. Corrections remain new versions under the existing code. AI generation is now included in first release; invocation/source-state/permission details remain open.

42. AI generation of new practice variants is required in the first release, with normal QC and new-code identity.
43. Generate variants only when faculty requests them; no automatic generation for each uploaded/new question.
44. Confirmed: original review completion is not required for variant generation; draft/unreviewed questions may be sources. New variants still need their own normal QC/publication checks. Translation remains post-review only.

45. Faculty selects variant count, may change question type, and specifies target difficulty (1–10); preserve targets/provenance and validate target output.
46. Confirmed: a single request can mix types/difficulties, such as two SCQ at difficulty 4 and one numerical at difficulty 7. Count limits/defaults and operation permissions remain open.

47. Confirmed: variant primary concept stays the same as the original, even when type/difficulty changes. Preserve its stable ID and validate content remains relevant; do not force an unrelated question to carry the original tag.

48. Confirmed: faculty may provide extra instructions for AI variants (e.g. only change numerical values, reduce calculation). Preserve instructions/provenance within the same-primary-concept and target-format rules; do not silently bypass them.

49. Confirmed: first release includes AI diagram generation and editing. Preserve source/asset provenance and published history; check diagram/question/answer consistency in normal QC. Invocation/representation/provider controls remain open.

50. Confirmed: AI diagram generation/editing is faculty-requested only, not automatic per upload/question. Extracted source figures remain preserved. Exact operation permissions and representation/provider controls remain open.

51. Confirmed: Google login, email/password and mobile OTP are all included in the first release. Provider, onboarding, verified linking/recovery and session details remain open.

52. Confirmed: faculty accounts are admin invite/create only; no public faculty self-signup. Login alone cannot grant membership; owner/bootstrap and account-linking details remain open.

53. Confirmed: a faculty account belongs to one coaching only, with no multi-coaching membership or switching. Platform multi-tenancy remains required; server enforces the account organization.

54. Confirmed: faculty may view their coaching's complete question bank across creators/uploaders, not just their own questions. Cross-tenant denial remains; editing/approval/publication/deletion rights are separate.

55. Confirmed: editing another faculty's questions requires permission granted by admin. Full bank viewing does not grant edits; published correction remains a new version with audit.

56. Confirmed: all faculty receive upload, manual entry and AI tool access by default; no per-user admin enable permissions. Existing approve/publish/cross-author-edit grants and admin-only storage actions remain. Review/QC now has a separate admin grant; queue/assignment UI details remain open. See PERMISSIONS_MATRIX.md.

57. Confirmed: formal review/QC requires a separate admin grant. Review, approve, publish and cross-author editing grants are independent; default faculty tools/viewing confer no review authority. Shared review without mandatory assignment is confirmed; detailed queue/concurrency UI remains design work.

58. Confirmed: any faculty with QC permission may review pending questions in their own coaching; mandatory reviewer assignment is not required. Shared pending-review queue, actor/revision history and concurrency protection apply.

59. Confirmed: bulk upload of multiple PDF/Word/image files in one submission is required. Keep per-file source/progress/error visibility and 50 MB/document, 10 MB/image limits; total count/aggregate bounds remain design work.

60. Separate question-paper, answer-key and solution files can be linked and jointly processed with group/multi-file provenance; unresolved matches remain reviewable.
61. Confirmed: AI identifies and links related files directly; faculty can correct pairing afterward. Preserve provenance and re-evaluate affected staging associations without silently overwriting reviewed/published data.

62. Confirmed: faculty may request AI to solve/fill a missing source answer. On-demand, not automatic for every upload; preserve AI provenance, format checks and normal QC without automatic verified status or publication.

63. Admin needs faculty-wise AI usage and cost dashboard with operation/model attribution and actual/estimated/unavailable cost labels.
64. Admin may set a monthly AI spending limit for each faculty member.
65. Warn at 80% budget consumption and stop new AI work at 100%.
66. Confirmed: usage starts afresh on the first day of each calendar month; preserve prior-month cost/history. Timezone, accounting/reservations and in-flight month-boundary handling remain design work.

67. Confirmed: each coaching adds its own AI provider API keys. No centrally shared/cross-tenant credential fallback. Resolve keys per tenant in API/workers; catalogue, secret management/rotation and detailed administration remain design work.

68. Coaching admin chooses enabled supported models/default; faculty select enabled compatible models with that coaching's keys.
69. Confirmed: on selected-model failure show an error and automatically try another enabled compatible model, using only same-coaching keys and budget. Preserve original/fallback/actual-model provenance; exact order/attempt limits remain design work.

70. Duplicate checks run automatically for every new question against its own coaching's existing bank; human QC confirms relationship/disposition.
71. Confirmed: exact duplicate intake attaches the new source to the existing question instead of making a new master/code. Preserve source/candidate/audit and published snapshots; thresholds and existing duplicate-master/canonical handling remain open.

72. Confirmed: first release supports old .doc alongside .docx. Keep originals and any conversion provenance/warnings; converter/decoder implementation must be verified. 50 MB/document limit remains.

73. Confirmed: handwritten question photos/scans are included in release one. Preserve sources and flag uncertain content for correction; OCR/vision engines, per-language evaluation and targets remain design work.

74. Faculty can cancel own processing jobs; background work allows new uploads and other app use.
75. Confirmed: already extracted questions remain saved as draft work after cancellation. Preserve sources/history; do not demote reviewed/published content. In-flight cancellation/races and cancelled-job restart UX remain design work.

76. Admin may archive own-coaching questions; creator faculty may archive their own question while preserving identity/history.
77. Confirmed: both admin and creator may restore archived questions (creator only own). Keep existing code, versions/content/history; restore does not automatically publish unreviewed drafts or grant cross-author writes.

78. Confirmed: video solution is an optional external link; first release does not need video upload/hosting. Preserve safe URL/version metadata and existing edit/publication rules.

79. Confirmed: equation editor must support visual controls, LaTeX code and MathML code. Preserve source/meaning/version rendering; canonical representation, syntax/conversion and libraries remain design work.

80. Confirmed: a question has one chapter and one topic only, not multi-chapter/topic tags. Primary plus multiple secondary concepts remain supported; cross-branch concept rules are not settled by this answer.

81. Confirmed: first release includes faculty-requested AI correctness checking of existing answers and available solutions. Findings remain advisory/revision-bound; no automatic content replacement, human QC completion, publication or verified badge. Solution remains optional. Correction-suggestion behavior is resolved by decision 82 below; badge criteria remain open.

82. Confirmed: AI checking must flag issues and show corrected answer/solution suggestions; faculty may explicitly opt in to direct application, with visible before/after changes and reasons. No opt-in means no content change. Apply current tenant/edit/revision/type checks and preserve source/history; published corrections use a new editable version under the same code and normal QC/approval/publication. Direct-correction opt-in scope is resolved by decision 83 below.

83. Confirmed: choose direct AI correction separately for one question at a time. No batch-wide correction opt-in or automatic carry-over to another question. This does not change bulk upload or other AI-operation scope.

84. Confirmed: Match the Column may leave some right-column items unused in the correct mapping as distractors, for example three left/five right with two unused. Left items still match one or more right items, no right item is shared across different left items in the correct mapping, and four response options/exactly one correct combination remain.

85. Confirmed: first release includes AI-created directed prerequisite links between concepts, identifying what should be understood before another concept. Keep stable tenant-scoped endpoints/provenance and graph history separate from question tags/hierarchy. Personalized student suggestions and mastery analytics remain later. Edge activation/admin-review is resolved by decision 86 below; detailed cycle/quality rules remain design work.

86. Confirmed: AI prerequisite links become immediately usable with AI-added/admin-review-pending status and admin notification; admin can later approve, correct or revoke them. No prior approval blocks validated link creation/processing. Keep graph/history and tenant/structural validation; student recommendations stay later.

87. Confirmed: faculty can view the knowledge tree as a graph in release one and click a concept to open linked own-coaching questions. Use primary/secondary concept assignments and existing bank/status access; graph viewing grants no graph-write/question-edit/QC authority. Show direction and provisional status; student recommendations remain later.

88. Confirmed: prerequisite links are limited to concepts within the same subject; cross-subject links are not allowed. Same-coaching/same-stable-subject checks apply to AI additions and admin corrections. Cross-class links are resolved by decision 89 below; broader cross-chapter details and question multi-concept assignment scope are separate.

89. Confirmed: prerequisite links can connect different classes within the same subject/coaching, including Class 11 → Class 12. Do not reject links for differing class IDs or rewrite endpoint/question classification; graph navigation must support them. Cross-subject links remain disallowed and existing provisional/admin-control/history policies apply.

90. Confirmed: numerical questions support one exact answer or one inclusive accepted range only, not multiple separate ranges. Preserve/flag multi-range source/AI output for correction without silently selecting/widening; keep domain/precision/endpoints and normal publish validation.

91. Confirmed: no separate numerical-answer unit field. Keep numeric exact/range answers; units in sources/question text/equations/solutions remain preserved. Do not require a unit attribute at publication or silently convert/rescale values.

92. Confirmed: only admin and authorized AI taxonomy workflow may create new concepts; faculty cannot create concepts manually. Existing concept selection/authorized question-tag corrections remain allowed, and AI can still add missing concepts during faculty processing under provisional activation/admin notification. Other hierarchy-node creation permissions are resolved by decision 93 below.

93. Confirmed: only admin and authorized AI workflow may create class, subject, chapter, topic and subtopic entries. Faculty selects existing entries under question-edit permissions; no manual or implicit editor/API creation. Tenant/parent checks and provenance apply; subtopic remains optional and existing concept/prerequisite policies remain.

94. Confirmed: one coaching can have multiple admins. Use individual identities/memberships with actor audit and no singleton-admin constraint; tenant/question ownership policies remain. Principal owner/admin hierarchy and authority to appoint/remove admins are resolved by decision 95 below.

95. Confirmed: each coaching has a principal Owner/Admin who can add/remove the other admins. Ordinary admin/faculty status alone does not grant this authority. Preserve same-coaching checks, per-actor role-change history and existing question permission/version rules. Owner transfer scope is resolved by decision 96 below; bootstrap/recovery, exact transfer/removal mechanics and residual roles remain open.

96. Confirmed: the principal Owner/Admin may transfer ownership to another same-coaching admin. Keep one principal owner through an atomic, current-owner/active-target checked handover and record old/new owner audit; coaching data/questions and earlier attribution stay unchanged. Former-owner residual role is resolved by decision 97 below; acceptance/reauthentication details and bootstrap/recovery remain open.

97. Confirmed: after ownership transfer the former Owner remains a regular admin in the same coaching, losing principal-owner-only authority. The new Owner manages admins and future transfer. Keep the handover atomic with role/audit history and organization data; a later admin-removal action is resolved by decision 98 below.

98. Confirmed: Owner chooses whether another admin becomes normal faculty or is removed from the coaching app. Demotion preserves faculty membership under existing grants but removes admin rights; app removal leaves no coaching access. Preserve organization questions/assets, historical attribution, completed usage/cost and audit. Session/job/identity cleanup mechanics remain design work; ordinary faculty-removal authority is resolved by decision 99 below.

99. Confirmed: all coaching admins, including Owner, may remove ordinary faculty from their own coaching app. Validate current same-coaching actor/target roles and revoke access while preserving organization content/attribution/usage/audit. Do not allow this route to remove another admin/Owner; other-admin removal/demotion remains Owner-only. Session/job/asset/identity cleanup mechanics remain design work.

100. Confirmed: platform admin creates each coaching and its first principal Owner; no public coaching self-signup. Keep platform authority separate from tenant roles/normal login and retain actor/organization/owner audit. Initial platform-admin provisioning, first-owner invitation/identity mechanics and platform question-bank read access is resolved by decision 101 below; other platform content/secret/write scope remains separate.

101. Confirmed: (Prior limited-scope record; platform exclusions superseded by decision 103.) platform admin may view all coaching question banks through explicit platform-read authority, with coaching context and audit. Ordinary tenant users remain isolated. Viewing alone grants no edits/QC/approve/publish/delete, original ingestion-file/API-key access, export/copy or tenant AI work; use restricted API/RLS/storage/cache policy, not blanket DB bypass.

102. Confirmed: (Prior limited-scope record; platform exclusions superseded by decision 103.) platform admin may edit questions across all coachings through explicit platform-edit authorization and target scope. Apply current-revision/type validation and same-tenant references; preserve coaching ownership/creator attribution and platform editor audit. Published corrections create a new editable version under the same code, without inherited approval/verification or auto-publication. QC/approve/publish and other source/secret/delete/export/AI rights are not granted by edit scope alone.

103. Confirmed: platform admin has full access to all supported app capabilities across all coachings, including QC/approve/publish, originals/storage, user/Owner/role administration, taxonomy/languages, AI credentials/configuration/budgets/jobs and analytics. This supersedes prior limited platform exclusions. Coaching roles retain own-coaching restrictions; validation, published history, ownership/attribution, credential handling and audit still apply. Deferred test/student features remain later. See PLATFORM_ADMIN_ACCESS.md.

104. Confirmed: each coaching can display its own name and logo in the app. Keep tenant-owned branding/assets/cache separate from stable organization/question identities; platform admin can manage settings via full access. Branding-edit permission is resolved by decision 105 below; domains/themes/platform-brand removal/export branding remain separate.

105. Confirmed (18 October 2026): coaching admins cannot change their own name/logo. Only platform admin manages coaching branding; coaching Owner/admin/faculty writes, including generic organization updates or logo replacement, must fail. Preserve organization/question identity and change audit; domains/themes remain separate.

106. Confirmed (18 October 2026): all coachings use the same website/app entry link; no separate coaching domain/subdomain is required. Coaching identity/branding follows trusted authenticated membership; faculty remains single-coaching, platform admin may select a target under full authority. Tenant-safe sessions/cache/assets remain required. Actual common domain and physical deployment remain separate; subscription/payment timing is resolved by decision 107 below.

107. Confirmed (18 October 2026): coaching subscription/payment collection is deferred beyond the first release. Initial onboarding/question-bank workflows must not require a subscription/payment record. Future pricing/gateway/invoicing/access policy remain uncommitted; first-release AI usage/cost, coaching-owned keys and monthly 80% warning/100% stop controls remain required.

108. Confirmed (18 October 2026): initial faculty usage will be very low/a small group. No exact count, concurrency target or hard user cap is confirmed. Keep multi-coaching growth support, agreed feature scope and background jobs; question-bank scale is resolved qualitatively by decision 109 below; upload rate/exact counts and numeric performance targets remain open.

109. Confirmed (18 October 2026): expected question-bank volume is in lakhs, alongside few initial faculty. Design/evaluate bounded search/filter/count/concept navigation, same-coaching duplicate retrieval and background imports at representative scale. No exact count, corpus/user cap, storage sizing or speed guarantee is confirmed; initial bulk-load timing/file distribution remains open. See CAPACITY_AND_PERFORMANCE.md.

110. Confirmed (18 October 2026): user has existing question sources in PDF/Word/image form. Source availability is reported, not an inspected/uploaded/extracted full corpus or a verified lakh-scale count. Actual format/scan/handwriting/layout/answer-key distribution, initial import rate and extraction quality remain unverified; representative inventory is needed.

111. Confirmed (18 October 2026): source material includes both selectable/text-based files and scanned PDFs/photos. Keep both text extraction/OCR paths, with original/source anchors and shared correction/QC. Ratios, mixed-page/handwriting prevalence, quality and throughput remain unverified; representative source inspection is next evidence needed.

112. Confirmed first-release requirement (18 October 2026): samples will be shared later; continue documentation now. Initial AI extraction learns unknown document-layout families, saves reusable versioned patterns and automatically reuses compatible new files to reduce repeated extraction tokens/time. Support multiple patterns and handwritten questions/solutions; preserve coverage/QC, detect drift/fallback, never reuse old answers or promise zero handwriting recognition cost. Pattern scope is resolved by decision 114 below; sharing mode is the next open question. See ADAPTIVE_EXTRACTION_PATTERNS.md (D-21/R-36).

113. Confirmed future scope (18 October 2026): faculty can later create courses, conduct live classes and provide recorded sessions; AI can teach and generate concept videos personalized to student need/current level. Keep later learner/enrollment/media/quality/cost contracts separate from the first-release external question-video-link scope. See FUTURE_LEARNING_AND_AI_TEACHING.md (D-22/R-37–R-38).

114. Confirmed (18 October 2026): data and extraction patterns remain separate per coaching by default. Platform admin may explicitly share a coaching's complete database/dataset, patterns and associated material with another coaching. Tenant roles cannot initiate cross-coaching sharing. Independent initial-copy mode is resolved by decision 115 below; exact category/configuration, import-state and target-conflict contracts remain open. No data has been shared. See CROSS_COACHING_DATA_SHARING.md (D-23/R-39).

115. Confirmed (18 October 2026): platform sharing creates an independent initial copy; receiving coaching may use/change it under its own roles. No future automatic synchronization in either direction. Preserve source provenance and independent destination question/pattern/taxonomy/asset identities; new copied question masters receive new globally unique codes. Keep source/destination edits/deletions independent, including asset retention; no actual copy has run. Users/API-key inclusion is resolved by decision 116 below; imported publication, operational-reference and nonempty-target conflict details remain open.

116. Confirmed (18 October 2026): independent initial copy includes educational questions/sources/taxonomy/patterns; receiving coaching users and API keys are set up separately. No source auth/session/membership grants or provider keys are copied. Preserve source actor/model evidence only as provenance; destination uses own credentials/budgets and keeps its own Owner/branding. Published-copy eligibility is resolved by decision 117 below; target-conflict/operational details remain open. No actual copy/user/key setup has occurred.

117. Confirmed (18 October 2026): published source questions remain published in the independent destination copy with no mandatory local re-review. Preserve imported source QC/publication provenance, platform copy audit, complete version/assets/reference mapping and new destination global codes. Draft/unreviewed source work is not promoted. Later destination edits create a new editable version under its destination code and follow normal QC/approval/publication; copied snapshots remain immutable. No real copy/publication has occurred.

118. Prior channel decision (email component superseded by decision 121): AI-created concepts/prerequisite links notify coaching admin in both app and email. Preserve immediate-use processing and authenticated review even if email fails; persist per-channel delivery state/deduplication with entity/AI provenance. Recipients are resolved by decision 119 below; timing/provider and contact-address requirements remain open. No real notification was sent.

119. Prior notification decision (all-admin recipients retained; email component superseded by decision 121): notify all active admins in the originating coaching, including Owner, of AI-added concepts/prerequisite links through app and email. No automatic other-coaching/platform-wide email broadcast. Keep current-role checks, per-recipient delivery/read states and deduplication, distinct from shared review state. Mandatory admin contact is resolved by decision 120 below; verification/timing/provider mechanics remain open; no notification was sent.

120. Prior notification-contact decision (superseded by decision 121): every coaching admin including Owner must have an email contact for notifications. This does not force email/password login; Google and mobile OTP remain supported. Validate required contact on onboarding/promotion/active-admin updates; email matching cannot auto-merge/grant roles. Verification/change/recovery and email timing/provider remain design work. No account or message was created.

121. Confirmed correction (18 October 2026): no notification emails now; app notifications only for all active admins of the same coaching including Owner. Email channel/digest/outbox/provider requirements and the extra mandatory admin/Owner notification-email contact requirement are withdrawn. Existing Google/email-password/mobile-OTP authentication requirements remain. Keep current-role checks, per-user read state, shared review/provenance and idempotency; no real notifications/accounts changed. The pending per-event-versus-email-summary question is cancelled.

122. Confirmed (18 October 2026): Google/email-password/mobile OTP can be linked to one canonical app account, preserving the same membership/grants/creator history/AI usage-budget identity whichever configured method is used. Verified linking is required, no automatic contact-match merge/privilege union or revoked-access bypass. All methods are alternative, not required together. Notification email remains cancelled; provider/linking/change/recovery and multi-device/session details remain design work. No account linking has occurred.

123. Confirmed (18 October 2026): user may remain logged in simultaneously on mobile/laptop. Both sessions resolve to one account/coaching grants/history/notifications/AI budget, including different linked login methods. Do not invalidate the first solely for a second login; enforce current roles, shared accounting/idempotency and revision conflicts. Device-list/remote-logout UI scope is resolved by decision 124 below; exact device cap and lifetime remain design work. No real sessions created.

124. Confirmed answer (18 October 2026):** no logged-in-device list or user-facing remote per-device logout manager in the current release. Retain normal current-session logout and simultaneous mobile/laptop sessions. Backend expiry/current-role/membership revocation must still apply across sessions; device cap/lifetime/provider mechanics remain design work. No real sessions changed.

125. Confirmed answer (18 October 2026):** initial AI providers are Google, Anthropic, OpenAI and OpenRouter, with more providers addable later through supported adapters/catalogue updates. Coaching-owned credentials, model enable/default controls and same-coaching compatible fallback/budgets remain. No keys have been collected or integrations verified. The closure interview now has two inputs left: hosting destination and infrastructure budget.

126. **Latest confirmed answer (18 October 2026):** development app hosting is on this PC. Production hosting is not selected. Use this as the local-development planning target; no install, server startup, public exposure, hardware capability or implementation is authorized/verified by this answer. The monthly hosted-infrastructure budget question is deferred to production planning because local development does not require selecting paid hosting now; AI cost controls remain. No required user questions remain in the current closure round; consolidated design and document review still remain.

## Continuation guidance

The independent-update decision does not remove translation relationships or authorize silent mutation of published versions. Keep source-version provenance even when original and translation evolve separately. Original corrections may be shown as information for later translation review, but automatic propagation/mandatory synchronization was not requested.

Do not reopen settled decisions as unanswered questions. Explain terms using concrete examples. The user wants suggestions on design choices and one focused question at a time.

## Important remaining decisions

- Matching/list structure: practical item-count limits and labels. Unused right items are allowed as distractors. Variable column counts, one/multiple right matches per left item, no right-item reuse across left items in the correct mapping, four combination options and one correct option are confirmed.
- Assertion–Reason detailed semantic QC/examples; Multiple Statement practical count limits/labels; passage exact child-type catalogue and sharing/versioning; mixed child types and separate permanent subquestion codes are confirmed. Multiple Statement has variable statement count, four options and one correct answer. Assertion–Reason has four question-specific options and one correct; no mandatory fixed wording.
- Numerical shorter-input formatting and review-resolution UX. One exact value or one inclusive range is supported; multiple ranges are not allowed; extra precision is flagged, not auto-rounded. Multiple-correct permits one correct option with four total options.
- Detailed taxonomy/prerequisite semantics, broader cross-chapter details, cycle handling and educational validation (first-release AI prerequisite creation and immediate use/admin notification/later correction or revocation are confirmed). Publication metadata requirements are confirmed below. Class, subject, chapter, topic, primary concept, correct answer, valid 1–10 difficulty and Bloom level are required; PYQ-marked questions also require exam name/year; subtopic and solution are optional. Incomplete drafts can be saved.
- Exact QC states beyond the confirmed return-for-correction/resubmit loop, edit/approval invalidation, translated-content review and permission UI.
- Permanent code alphabet/case and lifecycle policy. Exactly eight alphanumeric characters, global uniqueness, secure generation and separate identities are confirmed.
- Identity provider, session strategy, invitation delivery, platform-admin bootstrap, first-owner activation/recovery, platform full-access enforcement/credential-display details, exact owner-transfer flow, admin-removal session/job/identity mechanics, faculty-removal session/job/asset/identity mechanics and account linking/recovery. Ordinary faculty removal is allowed for all coaching admins. Owner chooses admin-to-faculty or app removal. Principal owner manages other admins and may transfer ownership to another same-coaching admin; multiple admins per coaching are confirmed. Faculty onboarding is confirmed admin invite/create only. All three login methods (Google, email/password, mobile OTP) are confirmed. Stack, deployment and object storage provider remain open.
- Independent educational-copy mapping/dependency/operational-history/failure/target-conflict contracts (one-time copy/no synchronization and separate destination users/API keys are confirmed); adaptive pattern lifecycle/drift/coverage/savings evidence; exact image extensions, legacy DOC conversion, OCR/sample corpus, job recovery/limits and source deletion. Samples are explicitly deferred: do not repeat upload requests or block current documentation.
- Initial providers are Google, Anthropic, OpenAI and OpenRouter with later extension; exact API/model catalogue, protected-write/role interactions, budget/accounting, data handling and verification criteria remain design work. Upload/manual entry/AI tools are confirmed available to all faculty by default; no per-user enable flags.
- Production retention/backup/recovery/privacy and later test/student/course/live/recorded/AI-teaching/concept-video specifics before their milestones.

These are review topics, not a questionnaire to deliver at once. The documents remain a review baseline rather than an approved final implementation specification.

## Files and evidence

Interview closure audit (18 October 2026): the user asked how many questions remain. See [the review closure plan](REVIEW_CLOSURE_PLAN.md): originally three user inputs; initial providers and local development on this PC are now answered. Production hosting/infrastructure budget is deferred, so zero required user questions remain in this round. Routine technical decisions belong in assistant proposals; later-phase discovery and deferred source samples do not extend the current questionnaire. This is a work plan, not a newly confirmed product decision or implementation authorization. Consolidation and final document review remain.

The original handover archive is preserved. Working Markdown documents are indexed in README in this folder. The review ZIP is refreshed after confirmed decisions. Documentation checks verify local links and requirement/decision/scenario references; no application tests, migrations or provider/OCR capability checks have been run.
