# Identity and Access — Review Specification

Status: all three login methods confirmed for the first release on 17 October 2026. Faculty onboarding is admin invite/create only; one linked user identity across these methods is confirmed; provider selection, verified linking/recovery flow and session design remain open. No authentication has been implemented or tested.

## Confirmed login scope

- Google login.
- Email and password login.
- Mobile-number OTP login.

The user selected all methods, not a requirement to complete all three during each sign-in. Present them as supported authentication choices. Exact OTP delivery provider/channel and provider capabilities need verification before implementation.

## Identity and organization access

Authentication establishes a user identity; it does not by itself grant organization membership or publishing rights. Verify active membership and action permission for the requested organization. Admin controls approval/publication permissions independently, and source storage analytics/deletion remain admin-only. Faculty can view authorized original sources.

Users signing in through different methods must not silently obtain separate organization privileges or have unrelated accounts merged by an unverified matching email/phone. Choose explicit verified linking and recovery behavior with the selected provider. The product must support Google, email/password and mobile OTP linked to one canonical user account, preserving the same permissions/history. Secure linking, conflict resolution, contact changes and recovery UX remain design work.

## Open product decisions

- Platform admin creates every coaching and its first Owner, with no coaching self-signup; exact first-owner invitation/acceptance and initial platform-admin provisioning remain design work. Faculty invitation/account creation remains coaching-admin-only.
- Verified linking/change/unlink/recovery and collision handling for the confirmed single account across Google/email-password/mobile OTP; no automatic merging solely from a matching contact.
- Simultaneous mobile/laptop sessions are confirmed; a device-list/remote-logout UI is excluded from current scope, while session duration, device-count policy and technical revocation remain design details.
- Password recovery and OTP delivery/recovery UX, with identity proof defined through the chosen provider.
- Exact provider and identity/account-linking rules. A faculty account is limited to one coaching; no multi-organization faculty membership or organization switcher.

## Proposed technical safeguards

Use a reviewed identity-provider/session design rather than treating a frontend login success message as authorization. Validate identity evidence server-side. Password/OTP/provider secrets must not be logged or committed. OTP expiry, single use, request/attempt limits and safe recovery need explicit implementation contracts; numerical settings are not decided here. If cookies are used, define secure session and CSRF handling; if tokens are used, validate the selected issuer/audience and renewal/revocation behavior.

## Acceptance direction

Exercise successful and failed Google, email/password and mobile OTP login with the actual chosen integration. Deny organization/business access without active membership; test recovery, linking and revocation once policy exists. Invalid/replayed/expired OTPs must not authenticate, and repeated attempts must follow configured limits. These are planned checks, not test results.

## Faculty onboarding — confirmed

Only admin invites or creates faculty accounts for the organization. Public self-signup does not enroll faculty or grant membership. A valid Google/OTP/password sign-in by an uninvited identity must not bypass membership restrictions. Invitation acceptance and authentication establish access only to the intended organization with configured permissions; no cross-organization privilege inheritance. Exact invitation contact method, expiry/resend/revoke mechanics and account linking are design work. Platform-admin creation of the coaching and first Owner is confirmed below; verified invitation/activation mechanics remain design work.

## Single-coaching faculty account — confirmed

User-confirmed: each faculty account belongs to only one coaching organization and cannot switch between multiple coaching memberships. The platform remains multi-tenant, with separate faculty accounts/data for different organizations and runtime isolation. Enforce the single-coaching account scope server-side; hiding a switcher is not sufficient. This faculty rule does not define platform-owner/admin scope or whether the same human may hold separately provisioned accounts; do not silently infer identity-provider/account-merging behavior.

## Faculty sees the complete coaching question bank — confirmed

User-confirmed: faculty can view the complete question bank of their own coaching organization, not only questions they created or uploaded. Do not apply a creator-only filter to ordinary faculty question-bank visibility. Organization ownership, single-coaching account scope and cross-tenant denial remain unchanged. Viewing the full bank does not itself grant editing, approval/publication, original-file deletion or storage-dashboard rights. Detailed staging/review-state access and edit permissions remain separate policy questions.

## Default faculty upload, manual entry and AI access — confirmed

User-confirmed after clarification: upload, manual entry and AI tools are available to all faculty by default, without separate per-user admin enable permissions. Enforce active single-coaching membership, tenant scope, configured models/resource limits and existing operation-state rules. Approval, publication, editing another faculty's question and admin-only storage/deletion remain separately controlled. Default AI access does not authorize protected writes to another question. See [confirmed access matrix](PERMISSIONS_MATRIX.md).

## Admin-granted review/QC permission — confirmed

User-confirmed: formal question review/QC requires a separate permission granted by admin. Default faculty bank/source viewing, upload/manual entry and AI access do not grant formal review authority. Review, approval and publication are independent grants. A user may perform their own review/approval/publication only when holding the corresponding permissions; no different person is universally mandated. Review permission authorizes reviewed-state decisions/correction-return within the workflow, not protected content edits without the required edit permission. Preserve actor/revision-bound QC evidence and deny unauthorized review transitions.

## Multiple admins per coaching — confirmed

A coaching organization may have more than one admin. Represent administration through individual authenticated identities and organization-scoped memberships/authority; do not impose a one-admin-per-organization constraint or require a shared login. Attribute every administrative action to the actual actor and preserve organization ownership of questions and audit history.

Multiple admins do not imply access to other coaching organizations. Each coaching has a principal Owner/Admin who can appoint and remove its other admins. Ordinary admin status does not itself grant admin-appointment/removal authority. The current Owner may transfer principal ownership to another admin in the same coaching. After transfer, the former Owner remains a regular admin in that coaching and loses principal-owner authority. When removing another admin, Owner chooses either conversion to normal faculty or removal from the coaching app with no remaining coaching access. Platform admin creates the coaching and first Owner; onboarding delivery/identity mechanics, owner recovery and exact transfer/removal mechanics remain design work. Existing independent question QC/approve/publish grants and admin-only catalogue/storage/AI configuration policies remain; do not infer that the numeric admin count changes their semantics.

## Principal coaching Owner/Admin — confirmed

Each coaching has a principal Owner/Admin, who can add and remove the coaching's other admins. This is an application role scoped to one organization, not a platform-wide or database-owner privilege. Faculty and ordinary admin membership alone do not authorize admin promotion/removal. Principal-owner authority does not waive question validation, published-version immutability or independently defined review/approve/publish checks.

Design direction: persist the owner's stable identity/membership and explicit admin role changes with actor, target, organization, before/after roles and timestamp. Validate active owner authority and same-coaching target server-side for every write; direct API calls cannot self-promote or change another organization's admins. Revoking admin authority must affect subsequent protected operations and preserve questions, original attribution and historical audit. Owner explicitly chooses normal-faculty conversion or removal from the coaching app. Exact session/pending-job and underlying identity-retention mechanics need a contract before implementation; neither option deletes organization questions or their attribution.

Owner-initiated transfer to another same-coaching admin is confirmed below; bootstrap, recovery and detailed transfer mechanics remain design/review work. Do not allow ordinary admin-management actions to silently remove or replace the principal owner or leave ownership ambiguous. No owner account or admin promotion has been created; this is requirements documentation.

## Ownership transfer to another admin — confirmed

The current principal Owner/Admin may transfer ownership to another admin of the same coaching. This transfers the principal application role, not organizational question ownership, data between tenants, historical attribution, provider keys between organizations or the recipient's login credentials.

Design direction: validate the initiator is still the current active owner and the target is a different active admin in that coaching at completion. Apply the ownership handover atomically, retaining exactly one principal owner and rejecting stale/concurrent/replayed transfers. Failure leaves existing ownership intact. Preserve initiating identity, prior/new owner, organization, time and outcome; subsequent owner-only operations use the current owner. Ordinary admin appointment/removal cannot serve as an alternate ownership takeover path.

Reauthentication, target acceptance, invitation/recovery and detailed UX are implementation/security design work. The former Owner remains a regular admin after transfer; the new Owner holds the principal-owner capabilities. The handover does not delete the former Owner's account, questions or audit history. No actual ownership or account changes have been performed.

## Former Owner remains admin — confirmed

On successful ownership transfer, the outgoing Owner retains regular admin membership in the same coaching. The incoming Owner alone holds the principal-owner role, including managing other admins and initiating the next ownership transfer. The outgoing Owner can continue ordinary admin actions under the established admin policy, but cannot use their former status, stale session or historical owner identifier for owner-only actions.

Design direction: commit new principal ownership and retained ordinary-admin membership together. If the transfer fails, preserve the prior roles. Keep old/new role evidence and actor attribution; do not erase questions, sources or previous audit events. Independent question QC/approve/publish and edit rules still apply. A later separate admin-removal action lets Owner choose normal faculty or removal from the coaching app, as confirmed below. No real account or role changes have been made.

## Owner chooses admin demotion or app removal — confirmed

For another admin in their coaching, Owner chooses one of two distinct outcomes:

- **Convert to normal faculty:** keep active coaching membership and normal faculty access, remove admin/owner-only authority, and apply the established separate QC/approve/publish/cross-author-edit grant policy.
- **Remove from app:** remove the user's coaching app account/access rather than retain faculty access. Subsequent coaching reads/writes, source access and new AI/job requests must fail. This is not merely hiding the admin badge.

This decision is specific to Owner managing other admins. It does not grant ordinary admins authority to remove admins/Owner; the following confirmation allows all admins to remove ordinary faculty only. The principal-owner transfer path remains separate; completing a transfer still retains the outgoing Owner as regular admin unless the new Owner later explicitly takes one of these actions.

Design direction: require an explicit disposition with target identity, current role revision and same-coaching Owner authorization; apply role/membership changes atomically and audit actor, selected outcome and before/after status. Pending jobs and sessions must recheck current authority before protected writes/dispatch; define in-flight behavior and private-asset access revocation before implementation. Account removal must not delete organization-owned questions/assets, source provenance, completed usage/cost or historical creator/reviewer attribution. Underlying record/identity cleanup and recovery/reinvitation are design work; this does not authorize deleting a global identity-provider account or another coaching's records. No real user has been demoted or removed.

## Any coaching admin may remove ordinary faculty — confirmed

All admins, including Owner, may remove an ordinary faculty member from their own coaching's app. The removed faculty retains no coaching app access; organization-owned questions/assets, original attribution, QC history, completed AI usage/cost and audit remain. This is a coaching membership/account-removal capability, not permission to delete an unrelated global identity or another coaching's records.

A user who currently holds admin or Owner authority cannot be removed through this ordinary-faculty action, even if they also have faculty capabilities. Other-admin demotion/removal remains Owner-only; principal-owner transfer remains separate. Validate the acting user's current same-coaching admin membership and the target's current ordinary-faculty role at commit, not only the role displayed when a page was loaded. A stale request against a recently promoted target must fail rather than bypass Owner authority.

Design direction: record actor, target, organization, outcome and time; enforce membership revocation on subsequent reads/writes, private-source access and new AI requests, and recheck access before protected background effects. Session, signed-link, in-flight job, recovery/reinvitation and record-cleanup mechanics remain implementation design. No real faculty member has been removed.

## Platform-admin onboarding of coaching and first Owner — confirmed

Platform admin creates each coaching organization and its first principal Owner/Admin. Coaching public self-signup is not available. Coaching Owner/admin and faculty membership do not confer platform-level onboarding authority, and a normal Google/password/OTP login cannot self-assign it. After onboarding, the coaching's Owner controls its other admins under the confirmed policy.

Design direction: keep platform authority separate from tenant membership, validate the intended first-owner identity and record platform actor, organization, owner and outcome. Provision the organization/initial-owner relationship consistently, with safe partial-failure/retry handling and no duplicate organizations or extra principal owners from replay. Invitation delivery/acceptance, verified identity linking and initial platform-admin provisioning remain implementation design.

Platform admin now has full cross-coaching application authority, including all question and tenant-administration capabilities, as defined in [platform access](PLATFORM_ADMIN_ACCESS.md). Earlier limited onboarding/read scope is superseded; preserve workflow, version, tenant-reference, secret-handling and audit rules. No organization or real account has been created.

## Platform admin may view all coaching question banks — confirmed

Authenticated platform admin may view the question banks of all coaching organizations. This is explicit platform-level reading authority; a coaching Owner/admin/faculty cannot gain it through their tenant role or by knowing a globally unique question code. Questions and historical attribution remain owned by the originating coaching.

Design direction: provide a platform-authorized read path with clear coaching identity, target scope and question/version context. Platform read permission must be checked server-side for list, search/count and question-detail requests, independently of ordinary coaching membership. Required retained question figures/equations render under question-read scope; the full platform role also has original-file access and protected credential administration as specified below. Record platform actor, target organization, operation and relevant IDs without copying entire content or secrets into logs.

Do not turn off tenant isolation globally. Ordinary tenant routes, workers, storage references and relationships retain their checks; use an explicit reviewed application/RLS read policy or restricted read service rather than reuse owner/migration credentials or a general bypass. Missing/revoked platform authority fails closed. Separate view caches/context by actor and coaching, including after switching back to tenant work.

The later full-access decision supersedes the earlier read/edit-only scope and grants all supported application capabilities; see the current platform access specification below. No platform account or data access has been exercised.

## Platform admin may edit all coaching questions — confirmed

Platform admin may edit questions across coaching organizations as an explicit platform-level capability in addition to bank viewing. It does not require pretending to be a coaching faculty member or gaining another user's credentials. Coaching Owner/admin/faculty still require their own organization membership and established edit grants; they cannot inherit this platform capability.

Apply ordinary content/type validation and revision-conflict checks to platform edits. For an editable draft, store the new revision and platform actor; for published content, create a new editable version under the same question master/code, preserving the previous published snapshot. The changed revision must not silently inherit approval or verification evidence from different content. Platform edit authority does not waive QC or automatically approve/publish.

Design direction: require current trusted platform-edit authority, an explicit target-coaching context and current question revision at API/service/transaction and storage boundaries. Record actor, target coaching/question/version, before/after evidence and outcome. Keep question ownership and creator attribution with the original coaching; record the platform actor as editor. Cross-tenant concept/asset/source relationships remain invalid even when the actor may edit both coachings.

Use narrowly authorized application/RLS writes rather than migration/owner credentials, disabled RLS or a generic tenant bypass. Missing/revoked authority and stale revisions fail safely. The current full platform role also includes formal QC, approve/publish, supported archive/delete, original-source/credential administration and AI operations. These use the same validation, target-coaching, provenance and lifecycle rules. No question has been edited in an application.

## Current platform authority — full access

Platform admin has full application access across all coachings, including question QC/approve/publish, originals/storage, users/Owners/roles, taxonomy, AI credentials/configuration/budgets/jobs and analytics. Earlier limited platform read/edit exclusions are superseded. Coaching roles retain their own-coaching boundaries. Validation, published-version preservation, current authority checks, coaching data ownership, secret handling and audit remain required. Full authority covers supported features and does not move deferred test/student features into release one. See [the platform access specification](PLATFORM_ADMIN_ACCESS.md).

## One shared app website/link for all coachings — confirmed

All coaching organizations use the same app website/entry link. Do not require a separate domain, subdomain or coaching-specific entry link for each organization in the first release. Ordinary question/detail links may still exist within the shared application; this decision is about a common entry point, not eliminating resource routes.

After sign-in, resolve a coaching user's organization and branding from their trusted identity/membership. Faculty remains bound to one coaching with no cross-coaching switcher. Never use the shared URL or a client-supplied tenant value as business-access authority. Platform admin may select an explicit coaching context under the full platform role, retaining actor/target audit.

Use tenant-safe API, private-asset, session and cache context so the shared entry cannot mix coaching names/logos, questions or sources. Platform admin alone changes coaching branding. Missing/unavailable logo behavior remains usable; exact anonymous/pre-login branding and routes are UI design. The chosen common domain, hosting, physical database/deployment arrangement and commercial billing remain separate decisions. Shared website does not weaken data ownership/isolation or create public coaching signup. No website or domain has been created.

## Coaching-specific patterns and platform dataset sharing - confirmed

Each coaching keeps its data/pattern library separate. Platform admin may explicitly share the complete dataset, patterns and associated material with another coaching. Ordinary coaching roles cannot initiate cross-coaching sharing. Preserve an explicit source/target manifest, complete dependency mapping, question-code/version integrity and platform actor history. Sharing creates a one-time independent initial copy with no ongoing updates in either direction; destination may use/change its own copy. Preserve mapped independent identities/new globally unique codes for new question masters and source provenance. Destination users and API keys are set up separately, not copied; keep source actor/model evidence as provenance, not active memberships/secrets. Source-published questions retain published status without mandatory local re-review on copy; preserve imported QC evidence and immutable snapshots, with later edits using normal new-version review. Destination conflict/failure and operational-reference details remain design work. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## Notification-only email requirement withdrawn

Notifications are now in-app only. The separate coaching-admin/Owner email-contact mandate introduced for email alerts is superseded; otherwise valid admin onboarding/promotion is not blocked merely for lacking that notification contact. Google/email-password/mobile-OTP remain supported with their own required identity data. This does not remove actual login emails, disable authentication/recovery functions or merge accounts. No identity or account operation has occurred.

## One user account across linked login methods - confirmed

Google, email/password and mobile OTP can be linked to the same canonical application user account. After linking, any configured method opens the same account with the same coaching membership, grants, creator/reviewer attribution, usage/budget identity and history. Do not create a separate app account or independent permissions merely because the sign-in method changes.

This is support for alternative linked methods, not a requirement to complete all three on every login or force every user to configure every method. Email/password credentials are needed only when that method is configured; the separate notification-email requirement remains withdrawn and alerts remain in-app only.

Design direction: verify control of the existing identity and added sign-in method using the chosen provider. Matching email/phone labels alone cannot merge accounts, expand membership, recover another user's account or grant admin/platform authority. Existing identity/link collisions require an explicit safe resolution, not silent data/role union. Current membership/role checks remain server-side for every method; revoked membership stays revoked. Exact provider, contact change/unlink/recovery and multi-device/session policy remain design work. No identities/accounts have been linked.

## Simultaneous mobile and laptop sessions - confirmed

A user may stay signed in on mobile and laptop at the same time. Signing in through another configured linked method/device does not automatically replace the first valid session. Both resolve to the same canonical account/coaching grants, history, notification state and AI usage/budget identity.

Design direction: maintain distinct session/device identifiers and current server-side identity/role checks. Role/membership revocation must take effect across devices, and no session may retain former Owner/platform authority solely from stale login state. Shared job/idempotency and revision-conflict rules still apply to simultaneous uploads/actions/edits; two sessions cannot create separate AI budgets or duplicate a charged operation by replay.

The user has not selected an exact device cap, session duration or an unlimited-session guarantee. No user-facing logged-in-device list or remote per-device logout manager is required in this release. Normal sign-out on the current device remains; simultaneous mobile/laptop sessions and server-side authorization/revocation checks remain. Exact cookie/token/provider/session implementation remains design work. No sessions/accounts have been created.

## No device-list or remote-device logout UI - confirmed

The current release does not include a screen listing logged-in devices or letting a user select another device to log it out. Keep normal sign-out for the current session and the confirmed simultaneous mobile/laptop access. This does not remove technical session expiry/revocation or current membership/role checks on all devices; account removal, demotion and ownership/platform-role changes cannot leave stale authority active merely because there is no device-management UI. Exact provider/session lifetime/cap mechanics remain design work. No sessions or account data have changed.
