# Requirements review — पहले product स्पष्ट करें

स्थिति: 17 अक्टूबर 2026। यह review guide है; नीचे दिए विकल्प अभी स्वीकृत फैसले नहीं हैं। Application code शुरू नहीं हुआ है।

## अभी तक क्या तय है

यह coaching organizations के लिए question bank और test creation platform होगा। Questions organization के होंगे। अलग-अलग organizations का data अलग रहेगा। Faculty/admin वाला काम पहले बनेगा; students के tests और analytics बाद में आएँगे।

**आपका तय उत्तर:** शुरुआत में एक coaching institute इस्तेमाल करेगा; architecture में कई coachings का support शुरू से रहेगा। इसलिए data isolation और organization-wise users/permissions शुरू से design होंगे। बाकी review एक-एक सवाल करके होगा।

**Permissions पर स्पष्ट उत्तर:** Admin approve और publish की permissions अलग-अलग तय करेगा। Creator को भी संबंधित permission चाहिए; question बनाने/upload करने से अनुमति अपने-आप नहीं मिलेगी।

PDF/Word से निकले questions और manually बनाए questions एक ही review प्रक्रिया से गुजरेंगे। हर question का स्थायी 8 character code होगा। Published question की पुरानी copy बदले बिना correction की नई version बनेगी। पहले बने tests अपनी selected version ही दिखाएँगे।

AI tagging, translation और duplicate suggestions में मदद कर सकता है। Supported models की तय list से चुनाव होगा और उपयोग का record रहेगा। AI का जवाब अपने-आप final या verified नहीं माना जाएगा।

## चर्चा का पहला दौर: कौन उपयोग करेगा और क्या बनाएगा?

1. **Organizations — rollout तय:** पहले एक coaching, बाद में कई coachings का support। अलग branding/products और hosting arrangement अभी तय नहीं हैं।
2. **काम का बँटवारा — तय:** Approve/publish की permissions admin तय करेगा। संबंधित permission मिलने पर creator अपने content पर भी ये actions कर सकेगा।
3. **पहली release — तय:** Question bank में entry/upload, review और database saving पहले; test creation और test-paper export बाद में।
4. **Question formats — तय:** पहली release में सभी नौ formats। [विस्तृत specification](QUESTION_TYPES_SPECIFICATION.md) में option और numeric constraints दर्ज हैं।

## चर्चा का दूसरा दौर: question कैसा दिखेगा?

5. कौन से fields draft में optional और publication पर जरूरी होंगे—answer, solution, difficulty, concepts, PYQ/source, language और video link?
6. Passage, matching, numerical answers, units, equations और diagrams किस रूप में edit/review करने हैं? Numerical tolerance और answer-key rules क्या होंगे?
7. Translation अलग question होगी या उसी question की language version? Original में correction होने पर translation की review कैसे होगी?
8. Duplicate मिलने पर केवल warning चाहिए, selection रोकनी है, या authorized override भी चाहिए? Batch की सीमा क्या है?

## चर्चा का तीसरा दौर: files, AI और test paper

9. Files की सामान्य भाषा, page count, layouts और scans की quality क्या होती है? इससे upload/OCR limits और evaluation corpus तय होगा।
10. AI की शुरुआत tagging, translation, duplicate matching या किसी और काम से करनी है? Budget/model permission कौन तय करेगा?
11. Test में sections, marks, negative marking और automatic selection चाहिए? Export PDF, Word या दोनों? Printed paper और online delivery का क्रम क्या होगा?

## Technical review उसके बाद

Login/provider, database/backend/frontend stack, hosting, storage, backups, permanent code की uniqueness, version policy और permissions को product workflow के अनुसार review करेंगे। हर निर्णय [decision register](PRODUCT_DECISION_REGISTER.md) में दर्ज होगा।

## अगला ठोस परिणाम

आपके answers के बाद PRD, permissions, content examples, API contracts, schema और acceptance criteria एक ही policy के अनुसार update होंगे। जो बातें बाद के phases की हैं, उन्हें स्पष्ट रूप से defer करेंगे। संबंधित requirements review होने के बाद ही implementation का पहला छोटा scope तय होगा।

## अब तक के अतिरिक्त उत्तर

PDF, Word और images पहली release में होंगे। Document की सीमा 50 MB और image की 10 MB प्रति file स्वीकृत है।

Taxonomy में class, subject, chapter, topic, subtopic और primary के साथ कई secondary concepts होंगे। AI list बनाएगा और metadata सीधे भरेगा। Missing concept को AI review-pending पहचान के साथ जोड़कर तुरंत tagging में इस्तेमाल कर सकेगा; admin को सूचना मिलेगी और वह बाद में approve, edit, merge या revoke कर सकेगा। यह पहले approval की जरूरत वाले नियम की जगह तय हुआ है।

## Original files पर तय नियम

Ingestion में दी गई original PDF/Word/image files रखी जाएँगी। Admin को storage usage दिखेगा और वही जरूरत पर delete करेगा। Storage analytics और deletion केवल admin के पास रहेंगे; faculty original source देख सकेगा। Original हटने पर saved questions और जरूरी diagrams/assets सुरक्षित रहेंगे।

## Languages और metadata view पर तय बात

पहली release में English, Hindi, Gujarati और व्यापक उपयोग वाली चार regional languages रखेंगे। उस मानदंड से Bengali, Marathi, Telugu और Tamil का initial चयन किया है; admin आगे languages जोड़ सकेगा। सामान्य question view में final/current metadata दिखेगा; internal audit/provenance अलग record होगा। Question एक समय में एक ही भाषा में दिखेगा; साथ-साथ दो भाषाएँ दिखाना जरूरी नहीं है। Translation faculty के माँगने पर बनेगा; हर question का अपने-आप सभी भाषाओं में translation नहीं बनेगा।

## Metadata की भाषा पर तय उत्तर

AI metadata उसी भाषा में भरेगा जिस भाषा में question है। साथ में English metadata भरना जरूरी नहीं है। अलग भाषाओं के labels एक ही concept की स्थायी पहचान से जुड़ेंगे। यह उत्तर question translation कब बनानी है, उस अलग सवाल का उत्तर नहीं है।

## Translation कब बनेगा — तय

Faculty जब चाहे तब translation बनाएगा। Upload पर अपने-आप सभी भाषाओं में copies नहीं बनेंगी। Question एक समय में एक ही भाषा में दिखेगा; metadata उसी भाषा में होगा।

## Translation से पहले review — तय

Faculty translation तभी मँगवा सकेगा जब original question का review पूरा हो जाए। Review से पहले translation नहीं बनेगा। Published होना अलग condition है; उसे इस उत्तर से अनिवार्य नहीं मानेंगे। Translation उसी reviewed version से जुड़ा रहेगा।

## Translation का code — तय

हर translated question का नया स्थायी question code होगा। वह original और उसके reviewed version से translation के रूप में जुड़ा रहेगा। Translation की अपनी version history होगी; बाद की correction उसी translated question की नई version होगी।

## Original और translation में बदलाव — तय

दोनों अलग-अलग update हो सकेंगे। एक को बदलने पर दूसरे को साथ बदलना जरूरी नहीं है। Original/translation का संबंध और source-version record रहेगा; published content की correction नई version बनाकर होगी। User ने बाकी review बाद में जारी करने को कहा है। अगली बार [continuation checkpoint](SESSION_CHECKPOINT.md) से शुरू करें।

## Solution जरूरी नहीं — तय

सही answer होने और बाकी review/validation/permissions पूरी होने पर question publish कर सकेंगे। Solution/explanation optional रहेगा। Solution न होने के कारण अपने-आप publication नहीं रोकेंगे।

## Publish से पहले primary concept — तय

Question publish करने से पहले primary concept tag होना जरूरी है। Missing primary concept पर publication रुकेगा; draft बचाया जा सकेगा। AI का नया review-pending concept tagging में तुरंत इस्तेमाल हो सकता है, इसलिए catalogue approval का इंतजार अनिवार्य नहीं करेंगे।

## Publish से पहले hierarchy fields — तय

Publish करने से पहले class, subject, chapter और topic चारों जरूरी होंगे। Primary concept और सही answer पहले से जरूरी हैं। Missing fields के साथ draft बचा सकेंगे; publication से पहले उन्हें भरना होगा। Subtopic की अनिवार्यता अलग से तय करनी है।

## Subtopic optional — तय

Subtopic optional रहेगा; उसके न होने से publication नहीं रुकेगा। भरा हो तो सही topic/hierarchy से जुड़ा होना चाहिए। Class, subject, chapter, topic, primary concept और सही answer की अनिवार्यता कायम रहेगी।

## Difficulty जरूरी — तय

Publish करने से पहले 1–10 के बीच valid difficulty level जरूरी होगा। AI भर सकता है और authorized user सुधार सकता है। Missing/out-of-range difficulty पर publication रुकेगा; incomplete draft बचा सकेंगे।

## Bloom level जरूरी — तय

Publication से पहले valid Bloom level जरूरी होगा। AI metadata के साथ सीधे भरेगा और authorized user सुधार सकेगा। Missing/invalid Bloom level पर publication रुकेगा; draft बचाया जा सकेगा।

## PYQ के लिए exam/year — तय

Question को PYQ mark किया है तो publication से पहले exam का नाम और year दोनों जरूरी होंगे। Missing values के साथ draft बचा सकेंगे। यह अनिवार्यता non-PYQ questions पर लागू नहीं होगी; missing metadata अपने-आप गढ़कर नहीं भरेंगे।

## PYQ की अतिरिक्त details optional — तय

PYQ की date, shift/slot और paper code optional रहेंगे। मिलें तो भरेंगे; missing होने से publication नहीं रुकेगा। Exam और year की अनिवार्यता कायम रहेगी। [सभी publication rules](PUBLICATION_REQUIREMENTS.md) एक जगह संकलित हैं।

## सुधार करके दोबारा review — तय

Review में गलती मिलने पर question creator के पास सुधार के लिए वापस जाएगा। Creator सुधार करके दोबारा review में भेज सकेगा। Question की पहचान और review history बनी रहेगी; यह delete करने की action नहीं है।

## Question code पूरे platform में unique — तय

दो अलग coachings के अलग question masters का question code भी एक जैसा नहीं होगा। Database में global uniqueness enforce होगी। Code पता होने से दूसरे organization के question का access नहीं मिलेगा; tenant permissions कायम रहेंगी।

## नए variant का अलग code — तय

अभ्यास के लिए values/conditions बदलकर नया variant बनाने पर नया अलग 8-character globally unique code होगा। Original से variant का link रहेगा और उसकी अपनी versions होंगी। Existing question की गलती सुधारने पर उसी code की नई version बनेगी।

## AI से variant बनवाना — पहली release में

AI से नए practice variants बनवाने की सुविधा पहली release में रहेगी। नए code और original से link के साथ सामान्य QC/approval/publish workflow लागू होगा। अपने-आप publish या verified नहीं माना जाएगा। इसे कब और किस permission से चलाना है, वह अगला निर्णय है।

## Variants कब बनेंगे — तय

AI variants faculty को जरूरत होने और उसके माँगने पर ही बनेंगे। हर नए/uploaded question पर अपने-आप variants नहीं बनेंगे। Source question की eligibility और generation permissions अभी तय करनी हैं।

## Variant के लिए original का review जरूरी नहीं — तय

Faculty draft/unreviewed original से भी AI variant बनवा सकेगा। नए variant का अपना सामान्य QC/approval/publication होगा; original का approval inherit नहीं होगा। Translation के लिए पहले review वाला अलग नियम कायम रहेगा।

## Variant की संख्या, type और difficulty — तय

Faculty कितने variants बनाने हैं यह चुन सकेगा। Question type बदल सकेगा और target difficulty (1–10) चुन सकेगा। AI चुने हुए format के हिसाब से answer/options बनाएगा और metadata दोबारा evaluate करेगा। Generated question का अपना सामान्य QC होगा; माँगी गई difficulty और actual assessed difficulty को बिना जाँच एक जैसा नहीं मानेंगे।

## एक request में mixed variants — तय

एक request में अलग-अलग types/difficulty वाले variants बन सकेंगे—जैसे 2 SCQ difficulty 4 के और 1 numerical difficulty 7 का। हर group/item का requested count, type और difficulty record होगा। Output उसी plan से जुड़ा रहेगा और हर variant का अपना QC होगा।

## Variant का primary concept वही रहेगा — तय

Type, difficulty या values/conditions बदलने पर भी variant का primary concept original जैसा रहेगा। Concept की स्थायी पहचान रखेंगे और content में भी वही मुख्य concept होना जाँचेंगे। केवल label copy करके unrelated question को सही नहीं मानेंगे।

## Variants के लिए additional instructions — तय

Faculty AI को extra instructions दे सकेगा—जैसे केवल numerical values बदलें या calculation कम रखें। Instructions का record रहेगा और वे चुने हुए count/type/difficulty तथा original primary concept वाले नियम के अनुसार लागू होंगी। Conflicting instruction पर बिना बताए नियम नहीं बदलेंगे।

## AI diagrams — पहली release में

AI से question के diagrams बनवाना और बदलवाना पहली release में शामिल है। Original सुरक्षित रहेगा; generated/edited diagram का record और QC होगा। Published question में लगे पुराने diagram के bytes बदलकर इतिहास नहीं बदलेंगे।

## Diagrams भी faculty के कहने पर — तय

AI से diagram बनवाना/बदलवाना faculty की request पर ही होगा। Upload पर source diagrams अपने-आप regenerate या replace नहीं होंगे। Original और edited output का अलग record और सामान्य QC रहेगा।

## Login के तीनों तरीके — तय

पहली release में Google login, email/password और mobile OTP तीनों होंगे। User login के लिए इनमें से समर्थित तरीका चुन सकेगा; तीनों एक साथ करना जरूरी नहीं है। Login होने के बाद भी organization membership और action permissions अलग से जाँची जाएँगी। Provider, signup/invitation और account linking अभी तय करने हैं।

## Faculty onboarding admin के जरिए — तय

Faculty account केवल admin invite/create करेगा। Public self-signup से faculty membership नहीं मिलेगी। Google/email/OTP login हो जाने से organization access अपने-आप नहीं मिलेगा। Owner का पहला setup और verified account linking अलग design topics हैं।

## Faculty account एक coaching में — तय

एक faculty account केवल एक coaching से जुड़ा रहेगा। उसी account से दूसरी coaching में switch नहीं कर सकेगा। Platform में कई coachings और उनका अलग-अलग data support रहेगा; server दूसरे organization का access रोकेगा।

## Faculty को पूरा अपना question bank दिखेगा — तय

Faculty अपनी coaching के सभी creators/uploaders के questions देख सकेगा; केवल अपने बनाए questions तक सीमित नहीं होगा। दूसरी coaching का data नहीं दिखेगा। पूरा bank देखने से edit/approve/publish या source delete करने का अधिकार अपने-आप नहीं मिलेगा।

## दूसरे faculty के questions edit करना — admin की permission

अपनी coaching में दूसरे faculty के questions edit कर सकना admin की दी permission पर निर्भर होगा। केवल bank देखने से editing अधिकार नहीं मिलेगा। Published question की correction नई version में होगी; पुराना content सुरक्षित रहेगा।

## सभी faculty को default tools — तय

Upload, manual entry और AI tools सभी faculty को default मिलेंगे; हर user के लिए अलग admin enable permission नहीं चाहिए। Approve/publish और दूसरे faculty के questions edit करने की permissions अलग रहेंगी। Storage dashboard/deletion admin-only रहेंगे। AI tool होने से protected question में बिना edit permission बदलाव करने का अधिकार नहीं मिलेगा।

## Review/QC की अलग permission — तय

Formal review/QC करने के लिए admin की अलग permission चाहिए। Review, approve और publish स्वतंत्र grants होंगे। Bank/source देखने या AI tools चलाने से QC authority अपने-आप नहीं मिलेगी। संबंधित permissions मिलने पर creator अपने question का workflow भी कर सकता है।

## Pending review कोई भी permitted faculty कर सकेगा — तय

अपनी coaching की pending list में review/QC permission वाला कोई भी faculty review कर सकेगा। पहले किसी खास reviewer को assign करना जरूरी नहीं होगा। Permission के बिना formal QC नहीं हो सकेगा; review decisions और history record होंगे।

## Bulk upload — तय

Faculty एक submission में कई PDF/Word/images upload कर सकेगा। हर file का source, validation, progress और error अलग रहेगा। 50 MB/document और 10 MB/image की सीमा प्रति file कायम रहेगी। Batch में कुल files/bytes की सीमा design में तय करनी है।

## अलग paper/answer-key/solution files link होंगी — तय

Question paper एक file में और answer key/solutions दूसरी में हों तो उन्हें जोड़कर process कर सकेंगे। Question, answer और solution के अलग source references सुरक्षित रहेंगे। Ambiguous/missing/conflicting matches review में दिखेंगे; AI/file pairing का तरीका अगला निर्णय है।

## AI file pairing, faculty बाद में सुधार सकेगा — तय

AI पहचानेगा कि कौन-सा paper, answer key और solution आपस में जुड़े हैं और सीधे link करेगा। Faculty बाद में pairing बदल सकेगा। File grouping और question-answer matching का record अलग रहेगा; गलत pairing सुधारने पर प्रभावित candidate answers/solutions दोबारा जाँचे जाएँगे। Reviewed/published data बिना बताए overwrite नहीं होगा।

## Missing answer AI से भरवाना — तय

File में answer न मिले तो faculty के माँगने पर AI question solve करके answer भर सकेगा। यह हर upload पर अपने-आप नहीं होगा। Answer के AI-generated होने का record रहेगा, format validation और सामान्य QC होगा; अपने-आप verified/published नहीं माना जाएगा।

## Admin को faculty-wise AI usage/cost — तय

Admin को हर faculty के AI usage और खर्च का dashboard चाहिए। Operation/model और available usage/cost record होंगे। Actual, estimated और unavailable खर्च अलग दिखेंगे; unknown को zero नहीं मानेंगे। Budget/limits की policy अगला अलग निर्णय है।

## Faculty-wise monthly AI budget — तय

Admin हर faculty के लिए monthly AI खर्च की सीमा तय कर सकेगा। यह खर्च का control है; AI tools की default availability बनी रहेगी। सीमा पूरी होने पर warning देनी है या नया AI काम रोकना है, वह अगला निर्णय है।

## AI budget: 80% warning, 100% stop — तय

Faculty का monthly AI budget 80% इस्तेमाल होने पर warning मिलेगी। 100% पर नया AI काम रुकेगा। Saved questions/पूरा हो चुका काम और non-AI काम सुरक्षित रहेंगे। चालू provider requests और accounting का exact व्यवहार design में स्पष्ट करना है।

## Budget महीने की पहली तारीख से reset — तय

हर calendar month की पहली तारीख से नई usage गिनती शुरू होगी। पिछले महीनों का usage/cost और audit history नहीं मिटेगा। यह rolling 30-day window नहीं है। Exact timezone और month-boundary पर चल रही requests का accounting design में स्पष्ट होगा।

## हर coaching अपने AI API keys देगी — तय

AI providers की keys हर coaching अपनी जोड़ेगी। उस coaching के AI calls उसी की configured key से होंगे; दूसरी coaching या common platform key पर चुपचाप fallback नहीं होगा। Billing उसके provider account से जुड़ी होगी। Platform की usage reports/budgets app के recorded calls पर लागू होंगे।

## Coaching के enabled/default AI models — तय

हर coaching का admin supported list में से उपलब्ध models और default model तय कर सकेगा। Faculty उसी coaching के enabled और काम के compatible models में से चुन सकेगा। Provider keys, model settings और budgets coaching-wise अलग रहेंगे। Model fail होने पर fallback की policy अभी तय करनी है।

## Model fail होने पर auto fallback और error — तय

चुना model fail हो तो error/status दिखेगा और दूसरे enabled, compatible model पर automatic प्रयास होगा। Original failure और actual इस्तेमाल हुए model का record रहेगा। केवल उसी coaching की keys और budget लागू होंगे; 100% budget stop या permissions bypass नहीं होंगी। Alternatives भी fail हों तो स्पष्ट failure दिखेगा।

## हर नए question पर duplicate check — तय

अपनी coaching के existing bank से हर नए question का duplicate check अपने-आप चलेगा। Matches review में दिखेंगे; duplicate/variant/translation का अंतिम निर्णय human QC करेगा। दूसरी coaching का private bank नहीं दिखेगा और uncertain question अपने-आप हटेगा नहीं।

## Exact duplicate में नया code नहीं — तय

Review में बिल्कुल वही question पहले से confirm हो तो नया code/master नहीं बनेगा। नया source existing question से जुड़ेगा। Original code, published content और source/review history सुरक्षित रहेंगे। Values/conditions वाले intentional variants और translations के अलग codes वाला नियम कायम रहेगा।

## Word की DOC और DOCX दोनों — तय

पुरानी .doc और नई .docx दोनों files पहली release में होंगी। Original upload सुरक्षित रहेगा; conversion/extraction के outputs और warnings का record होगा। 50 MB प्रति document वाला नियम लागू रहेगा। Converter का चुनाव और वास्तविक file quality की जाँच implementation में करनी है।

## Handwritten photos/scans — पहली release में

हाथ से लिखे questions की photos/scans से extraction support रहेगा। अस्पष्ट handwriting, equations, units और figures original के साथ review में flag होंगे; content गढ़कर या छोड़कर success नहीं दिखाएँगे। OCR/vision की वास्तविक quality representative files पर जाँची जाएगी।

## Background processing और cancel — तय

Faculty अपना processing job cancel कर सकेगा। Jobs background में चलेंगे; पहले job के दौरान नई files upload करना और app के अन्य काम जारी रहेंगे। Cancel source delete करने की permission नहीं है। पहले से निकले drafts का क्या करना है और चालू provider request का व्यवहार अलग से स्पष्ट करना है।

## Cancel पर निकले हुए questions draft में रहेंगे — तय

Job cancel करने से पहले निकले unpublished questions draft में सुरक्षित रहेंगे। Source, warnings और history बनी रहेगी। पहले से reviewed/published content को वापस draft नहीं करेंगे या हटाएँगे नहीं। आगे retry/resume में duplicate records नहीं बनने चाहिए।

## Archive: admin और creator faculty — तय

Admin अपनी coaching के questions archive कर सकेगा। Creator faculty अपने बनाए question को archive कर सकेगा। Active bank से हटेगा, लेकिन code/content/versions/history/assets सुरक्षित रहेंगे। केवल दूसरे के questions edit करने की permission से उन्हें archive करने का अधिकार नहीं मिलेगा। Restore का व्यवहार अभी तय करना है।

## Restore: admin और creator दोनों — तय

Admin अपनी coaching के archived questions restore कर सकेगा और creator अपने archived question को। Code/content/versions/history वही रहेंगे। Draft को restore करने से अपने-आप approve/publish नहीं माना जाएगा; पुराना published content overwrite नहीं होगा।

## Video solution link-only — तय

Video solution के लिए केवल link जोड़ेंगे; video file upload/hosting पहली release में नहीं चाहिए। Link optional होगा। Link बदलना भी edit/version permissions के अनुसार होगा; external video को platform पर सुरक्षित hosted copy नहीं मानेंगे।

## Equation editor के तीन तरीके — तय

Visual editor, LaTeX code और MathML code तीनों होंगे। Relevant question fields में equations लिख/सुधार सकेंगे। Original expression/source और preview का अर्थ सुरक्षित रहेगा; unsupported conversion को चुपचाप सही मानकर नहीं बदलेंगे। Library और storage format design में तय करने हैं।

## Chapter/topic एक-एक — तय

एक question में एक ही chapter और एक ही topic होगा। कई chapters/topics के tags नहीं होंगे। Primary के साथ multiple secondary concepts वाला नियम कायम रहेगा; concepts को केवल इस उत्तर की वजह से एक तक सीमित नहीं करेंगे।

## AI से answer/solution की जाँच — तय

पहली release में faculty के कहने पर AI मौजूदा answer और उपलब्ध solution की correctness जाँच सकेगा। Solution न हो तो answer की जाँच भी की जा सकेगी। जाँच का नतीजा और उसकी वजह review में दिखेगी; अनिश्चितता या error साफ दिखेगा। इससे answer अपने-आप बदलेगा नहीं और question approve/publish या verified नहीं माना जाएगा। AI गलती flag करने के साथ सही answer/solution का सुझाव भी दिखाएगा। Faculty सीधे सुधार लागू करने का विकल्प चुने तो AI बदलाव लागू कर सकेगा और पहले/बाद का अंतर व वजह दिखेगी। Edit permission और मौजूदा revision की जाँच होगी; published content का नया editable version बनेगा और सामान्य review/approval/publish नियम लागू होंगे।

## Direct AI correction: एक question पर अलग विकल्प — तय

सीधे सुधार लागू करने का opt-in हर question के लिए अलग चुना जाएगा। एक selection से कई questions में सुधार या अगले question पर अपने-आप correction लागू नहीं होगा। Flag, सुझाव, पहले/बाद का अंतर और सामान्य permissions/version/review नियम बने रहेंगे। Bulk upload की सुविधा पर इस फैसले का असर नहीं है।

## Match the Column में unused right items — तय

दाईं तरफ के कुछ items सही matching में बिना match के रह सकते हैं; वे distractors हो सकते हैं। जैसे बाईं तरफ 3 और दाईं तरफ 5 items में 2 unused रहें। हर left item के एक या अधिक matches होंगे; सही mapping में एक right item अलग-अलग left items से साझा नहीं होगा। चार answer options और केवल एक सही combination वाला नियम बना रहेगा।

## Concepts के prerequisite links — पहली release में तय

AI यह संबंध बनाएगा कि कौन-सा concept सीखने से पहले कौन-सा concept समझना चाहिए। ये concept-to-concept links होंगे; question के primary/secondary tags और chapter/topic hierarchy अलग रहेंगे। Links की दिशा, AI का कारण और बदलाव का record रहेगा। छात्रों को personalized questions सुझाने और mastery analytics की सुविधा बाद के चरण में आएगी। AI validated links सीधे जोड़कर इस्तेमाल कर सकेगा; status में admin review pending दिखेगा और admin को सूचना मिलेगी। Admin बाद में approve, सुधार या revoke कर सकेगा। पुराने graph और बदलावों का record सुरक्षित रहेगा।

## Faculty के लिए knowledge graph और questions — तय

पहली release में faculty अपने coaching का knowledge tree graph के रूप में देख सकेगा। किसी concept पर click करने से वह concept primary या secondary रूप में जिन questions में लगा है, वे खुलेंगे। AI-added/review-pending status साफ दिखेगा। Graph देख सकना, उसे edit करने या questions approve/publish करने की permission नहीं देता। Students के personalized suggestions बाद के चरण में रहेंगे।

## Prerequisite links: subject की सीमा — तय

Prerequisite links सिर्फ एक ही subject के concepts के बीच बनेंगे। Maths से Physics जैसे अलग subjects के बीच links नहीं बनेंगे। यह नियम AI और admin दोनों के बदलावों पर लागू होगा। उसी subject में अलग classes के concepts के बीच links की अनुमति नीचे तय है; broader chapter constraints अलग review detail हैं; question के primary/secondary concepts के पहले तय नियम बने रहेंगे।

## उसी subject में अलग classes के links — तय

एक ही coaching और subject में अलग classes के concepts के बीच prerequisite links बन सकेंगे—जैसे Class 11 का concept, Class 12 के concept का prerequisite हो। Graph में ऐसे जुड़े concepts तक पहुँचा जा सकेगा। इससे questions की class/chapter/topic tagging अपने-आप नहीं बदलेगी और अलग subjects को जोड़ने की अनुमति नहीं मिलेगी।

## Numerical answer: एक value या एक range — तय

Numerical question में एक exact सही answer या एक inclusive सही range होगी। कई अलग-अलग सही ranges नहीं रखेंगे। अगर source या AI output में multiple ranges आएँ तो उन्हें सुरक्षित रखकर review के लिए flag करेंगे; अपने-आप एक range चुनना या बीच का gap जोड़कर बड़ी range बनाना नहीं होगा। 0.00–999.00, दो decimals और दोनों endpoints शामिल होने के नियम बने रहेंगे।

## Numerical answer के लिए अलग unit field नहीं — तय

Numerical answer के साथ `m/s`, `N` या `J` की अलग optional/required field नहीं होगी। Question, equation, diagram, source या solution में units लिखी हों तो वे सुरक्षित रहेंगी; numeric value अपने-आप convert या rescale नहीं होगी। एक exact answer या एक inclusive range वाले पहले के नियम बने रहेंगे।

## नया concept कौन जोड़ सकता है — तय

नए concepts सिर्फ coaching admin और AI जोड़ेंगे; faculty खुद नया concept नहीं बनाएगा। Faculty existing concepts चुन सकता है और question की tagging अपनी edit permissions के अनुसार सुधार सकता है। Faculty के काम की processing में AI को जरूरी concept न मिले तो AI पहले तय नियम से उसे जोड़कर काम जारी रखेगा; admin को सूचना और बाद में review की सुविधा मिलेगी। Class/subject/chapter/topic/subtopic बनाने का अधिकार भी नीचे admin और AI तक सीमित तय है।

## बाकी taxonomy entries कौन जोड़ेगा — तय

Class, subject, chapter, topic और subtopic भी सिर्फ admin और AI जोड़ सकेंगे। Faculty मौजूदा सूची से entries चुनेगा और question की tagging अपनी edit permissions के अनुसार बदल सकेगा। Question में नया नाम टाइप करने से catalogue में नई entry अपने-आप नहीं बनेगी। Subtopic optional रहेगा; concepts और prerequisite links के पहले तय नियम बने रहेंगे।

## एक coaching में कई admins — तय

एक coaching में एक से अधिक admins हो सकेंगे। हर admin की अपनी login identity और उसी coaching की membership होगी; उसके किए बदलाव उसके नाम से record होंगे। इससे किसी दूसरी coaching का access नहीं मिलेगा। हर coaching में एक मुख्य Owner/Admin होगा, जो बाकी admins को जोड़ और हटा सकेगा। सामान्य admin या faculty होने से यह अधिकार अपने-आप नहीं मिलेगा। Owner अपनी ownership उसी coaching के दूसरे admin को transfer कर सकेगा। Questions और coaching data उसी organization के रहेंगे और पुराने/नए Owner का record रहेगा। Transfer के बाद पुराना Owner सामान्य admin बना रहेगा; मुख्य Owner वाले अधिकार नए Owner के पास होंगे। पुराने Owner का account, पुराने बदलावों का record और coaching data सुरक्षित रहेंगे। शुरुआती setup/recovery और transfer का detailed flow अभी design करना है।

## Admin को faculty बनाना या app से हटाना — Owner का फैसला

Owner किसी दूसरे admin के लिए चुनेगा: सामान्य faculty बनाना, या coaching के app से उसका account/access हटाना। Faculty बनाने पर सामान्य faculty access रहेगा और admin अधिकार हटेंगे। App से हटाने पर coaching का कोई access नहीं बचेगा। दोनों में coaching के questions, जरूरी assets, पुराने creator/reviewer के record और उपयोग/cost history सुरक्षित रहेंगे। Ownership transfer के बाद पुराने Owner का admin बने रहना अलग नियम है; उसे बाद में हटाना नया स्पष्ट action होगा।

## Faculty को हटाने का अधिकार — सभी admins

Coaching के सभी admins सामान्य faculty को अपने coaching के app से हटा सकेंगे; उसके बाद उस coaching का access नहीं रहेगा। Faculty के बनाए questions, जरूरी assets, पुराना attribution, usage/cost और audit सुरक्षित रहेंगे। यह विकल्प किसी दूसरे admin या Owner को हटाने के लिए इस्तेमाल नहीं होगा; admins को faculty बनाना या हटाना सिर्फ Owner का अधिकार रहेगा।

## नई coaching और पहला Owner — platform admin बनाएगा

नई coaching और उसका पहला मुख्य Owner/Admin platform admin बनाएगा। Coaching खुद public signup नहीं करेगी। Coaching बन जाने के बाद उसका Owner बाकी admins manage करेगा। Platform admin की यह onboarding permission, coaching के questions/sources या API keys का पूरा access अपने-आप नहीं देती; tenant-data access अलग फैसला है। शुरुआती platform admin और Owner invitation/login activation का तरीका design करना बाकी है।

## Platform admin सभी question banks देख सकेगा — तय

Platform admin सभी coachings के question banks देख सकेगा; किस coaching का question है, यह साफ दिखेगा और access का record रहेगा। Coaching के सामान्य Owner/admin/faculty को दूसरी coaching का access नहीं मिलेगा। यह viewing permission अपने-आप edit, QC/approve/publish, delete, दूसरे coaching में copy/export, original ingestion files या API keys का अधिकार नहीं देती। इन अधिकारों का scope अलग है।

## Platform admin questions edit भी कर सकेगा — तय

Platform admin सभी coachings के questions edit कर सकेगा। Question किस coaching का है, उसका ownership और creator attribution नहीं बदलेगा; edit करने वाले platform admin और बदलाव का record रहेगा। Published question का सुधार नया editable version बनेगा; पुराना published version सुरक्षित रहेगा। Validation और सामान्य QC/approval नियम लागू होंगे। Edit permission से अपने-आप approve/publish, original files/API keys, delete या cross-coaching copy/export का अधिकार नहीं मिलेगा।

## Platform admin को full access — नया अंतिम नियम

Platform admin को सभी coachings और app की सभी supported सुविधाओं का पूरा अधिकार होगा: questions बनाना/edit/review/approve/publish, users/Owners/roles manage करना, originals/storage, taxonomy/languages, AI keys/settings/budgets/jobs और analytics। पहले वाली platform read/edit-only सीमाएँ इससे बदल गई हैं। Coaching Owner/admin/faculty के अधिकार उनके coaching तक रहेंगे। Published versions, content validation, coaching ownership, secret handling और बदलावों का audit सुरक्षित रहेगा। Test/student features पहले की तरह बाद के चरण में हैं।

## हर coaching का नाम और logo — तय

App में हर coaching का अपना नाम और logo दिख सकेगा। नाम/logo बदलने से organization की पहचान, question codes या पुराने records नहीं बदलेंगे। Platform admin full-access के अनुसार इन्हें manage कर सकेगा। Coaching के Owner/admin/faculty खुद नाम/logo नहीं बदल सकेंगे; सिर्फ platform admin बदलेगा। अलग domain, color theme या पूरी platform branding हटाना अभी इस फैसले में शामिल नहीं है।

## सभी coachings के लिए एक ही website/link — तय

सभी coachings एक ही website/app entry link से app खोलेंगी। अलग coaching domains/subdomains की जरूरत नहीं है। Login के बाद trusted membership से अपनी coaching का data, नाम और logo दिखेगा; faculty दूसरे coaching में switch नहीं करेगा। Platform admin full-access के अनुसार coaching चुन सकेगा। Shared link से data या branding mix नहीं होनी चाहिए। Actual domain और hosting अभी चुननी है।

## Subscription/payment बाद में — तय

Coachings से subscription/payment लेने की सुविधा बाद के चरण में जोड़ी जाएगी। पहली release में onboarding और question-bank काम के लिए subscription/payment setup की जरूरत नहीं होगी। AI usage/cost tracking, coaching की अपनी API keys और monthly budget के 80% warning/100% stop नियम पहली release में बने रहेंगे। भविष्य की pricing, plans और payment gateway अभी तय नहीं हैं।

## शुरुआत में faculty कम — तय

पहली coaching में शुरुआत में बहुत कम faculty app इस्तेमाल करेंगे। कोई exact संख्या, concurrent-user target या hard user limit तय नहीं हुई है। इससे पहले तय features, background jobs या आगे कई coachings/users के support में कटौती नहीं होगी। Question-bank size और वास्तविक workload के आधार पर आगे capacity तय करेंगे।

## Question bank लाखों में — तय

Faculty कम होंगे, लेकिन question bank में लाखों questions रखने का लक्ष्य है। Search/filter, concept से questions खोलना, duplicate checks और background import को इस आकार के हिसाब से design और evaluate करना होगा। Exact संख्या, storage या speed guarantee अभी तय नहीं है। शुरुआत में bulk import होगा या bank धीरे-धीरे बढ़ेगा, और source files/assets का volume, अलग workload details हैं।

## पुराने question-source files उपलब्ध — तय

Questions के source files पहले से उपलब्ध हैं—PDF/Word/images में। अभी पूरी corpus की files, exact count, text/scanned/handwritten mix या extraction quality की जाँच नहीं हुई है। Representative files से आगे ingestion/OCR को evaluate करेंगे; पहले तय formats, file limits, background jobs और review rules बने रहेंगे।

## Text और scanned sources दोनों — तय

Existing files में text/select/copy होने वाला material और scanned PDFs/photos दोनों हैं। इसलिए पहली release में text extraction और OCR दोनों paths रहेंगे; originals, equations/diagrams, source locations और review warnings सुरक्षित रहेंगे। उनका अनुपात, mixed pages/handwriting और extraction quality अभी sample inspection से जाँचनी है।

## Extraction patterns save/reuse — पहली release में तय

कई files एक layout की, कई दूसरे layout की होंगी। AI नए layout को पहले समझे/extract करे, versioned pattern save हो और मिलती files में अपने-आप reuse हो। लक्ष्य repeated layout analysis के tokens/time घटाना है। Patterns numbering/columns/options/key/solution placement जैसे rules हैं; पुराने answers नई files में copy नहीं होंगे। Layout बदले या extraction अधूरी हो तो AI fallback और visible warnings होंगे। Handwritten questions और solutions दोनों support होंगे; नई handwriting पढ़ने का काम रहेगा। Samples बाद में मिलेंगे; अभी documentation जारी रहेगी। Patterns अलग coachings के अपने हों या साझा, यह अगला फैसला है।

## Courses, live/recorded और personalized AI — बाद के phases

Faculty courses, live classes और recorded sessions दे सकेगा। AI students को सिखा सकेगा और उनकी जरूरत/current level के अनुसार concept videos generate कर सकेगा। ये अलग future modules हैं; पहली release का question bank और optional external video-solution link नहीं बदलते। Learner evidence, enrollment/media access, generation/review triggers, providers/cost और educational quality उस milestone से पहले detail में तय होंगे।

## अलग coaching libraries, platform admin से sharing - तय

हर coaching का data और extraction patterns अलग रहेंगे। Platform admin चाहें तो पूरा coaching dataset, patterns और संबंधित सामग्री दूसरी coaching से share कर सकेंगे। सामान्य coaching roles खुद cross-coaching sharing नहीं करेंगे। Questions/assets/sources/taxonomy/pattern versions का संबंध, attribution और audit सुरक्षित रहना चाहिए। एक बार independent copy बने या आगे के बदलाव भी sync हों, यह अगला फैसला है; codes/ownership/configuration और target conflicts का व्यवहार उसके अनुसार तय होगा। अभी कोई data share नहीं हुआ है।

## Sharing: एक बार की independent copy - तय

Platform admin शुरुआत के लिए independent copy बनाएगा। उसके बाद दूसरी coaching अपनी जरूरत और permissions के अनुसार questions/patterns इस्तेमाल और बदल सकेगी। Source coaching के आगे के बदलाव अपने-आप नहीं आएँगे और destination के बदलाव source को नहीं बदलेंगे। Copies के अपने IDs/new globally unique question codes होंगे, original source provenance रहेगा और जरूरी copied assets source cleanup से नहीं टूटेंगे। Users/API keys/configuration inclusion और imported publication/conflict rules का detail अभी तय करना है।

## Copy में content/patterns; users/API keys अलग - तय

नई coaching में questions, sources/assets, taxonomy और extraction patterns की independent copy जाएगी। उसके users और API keys अलग setup होंगे; source के login/session/membership permissions या secrets copy नहीं होंगे। पुराने creator/reviewer/AI records provenance के रूप में रहेंगे, access के रूप में नहीं। Destination अपना Owner/branding और अपनी keys/budgets इस्तेमाल करेगी। Imported published questions की status और existing target conflicts का rule अभी तय करना है।

## Published questions copy के बाद भी published - तय

Source के already published questions destination में भी published रहेंगे; केवल copy होने की वजह से दोबारा review जरूरी नहीं होगा। Original review/publication का provenance और platform copy का record रहेगा; source users/accounts नहीं बनेंगे। बाद में नई coaching content बदले तो अपने question code के अंतर्गत नया editable version बनेगा और सामान्य review/approve/publish rules लागू होंगे। पुरानी copied published version सुरक्षित रहेगी; source drafts अपने-आप published नहीं होंगे।

## Notifications अब सिर्फ app में - नया नियम

AI नए concepts या prerequisite links जोड़े तो उसी coaching के सभी active admins को, Owner सहित, सिर्फ app में सूचना मिलेगी। पहले वाला email notification फैसला वापस लिया गया है। Notifications के कारण जरूरी की गई अलग admin/Owner email-contact requirement भी हटती है; email/password, Google और mobile OTP के पहले तय login rules बने रहेंगे। Email digest/SMTP/outbox की जरूरत नहीं है। हर admin की read स्थिति अलग और review state साझा रहेगी; कोई असली notification/email नहीं भेजा गया।

## Login के तीन तरीके, account एक - तय

Google, email/password और mobile OTP एक ही user account से link हो सकेंगे। किसी configured तरीके से login करे तो वही coaching, permissions, history और AI usage/budget दिखेगा। तीनों तरीके हर बार इस्तेमाल करना जरूरी नहीं है। Link करने में पहचान verify होगी; सिर्फ email/phone match से accounts/roles अपने-आप merge नहीं होंगे। Notifications अभी भी सिर्फ app में हैं; अलग notification-email requirement वापस नहीं आई है।

## Mobile और laptop पर साथ login - तय

User mobile और laptop दोनों पर एक साथ login रह सकेगा। Linked Google/email-password/OTP में से configured तरीकों का इस्तेमाल हो सकेगा, account/permissions/history/notifications/AI budget एक ही रहेगा। दूसरे device पर login करने से पहला अपने-आप logout नहीं होगा। Exact device limit/session duration अभी तय नहीं हैं। Logged-in devices की list और दूसरे device को remotely logout करने की UI पहली release में नहीं होगी; current device से सामान्य logout और backend permission/session checks बने रहेंगे।
