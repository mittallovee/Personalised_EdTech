# AI Model Orchestration

## Operation and provenance contract — proposed detail

Initial provider support is confirmed for Google, Anthropic, OpenAI and OpenRouter, with later extension. Specific API products and model identifiers have not been selected or verified; no integration has been tested. D-13 governs catalogue, initial operations, budgets, diagram assistance and verification criteria. This document does not establish API availability or price.

### Request lifecycle

An operation identifies organization, authorized actor, input candidate/version, operation type, selected/default model, prompt-template version and output-schema version. Authorization, capability, size/rate and budget checks happen before provider dispatch. Strict output validation precedes any suggestion storage/acceptance. A failed provider call must not remove or downgrade existing human-reviewed content.

### Suggested operation policy

| Operation | Candidate output | Acceptance boundary |
| --- | --- | --- |
| Metadata tagging | Directly populate taxonomy/difficulty/format/language and other allowed metadata | Validate schema/IDs/ranges, retain provenance, permit later authorized correction; no per-field approval gate |
| Structured parsing help | Candidate structure with warnings/source references | Schema-valid output still needs content QC |
| Translation | Language content linked to source version | Qualified human review under D-15 |
| Duplicate search | Ranked related candidates and evidence | Human confirmation under D-14 |
| Diagram assistance | First-release generation/editing of reviewable question assets | Preserve input/output provenance and historical asset versions; scientific/content consistency requires QC; representation/providers remain open |

### Trust, privacy and usage

Document text and model output are untrusted content. They cannot grant permissions, execute database commands, select unapproved providers, or override tenant rules. Tenant-scoped retrieval must occur before any duplicate/semantic search result is exposed. Validate linked IDs against the active organization.

Maintain safe request/output references, model/provider identity, configuration where material, prompt/schema version, timestamps, outcome and usage/cost status when available. Do not invent costs when a provider does not report them. Record how accepted suggestions affected fields and who accepted them.

Rate/budget reservations must account for concurrent operations and retries; accounting policy is D-13. Retry only suitable failures with bounded attempts; preserve provenance for repeated calls. Review provider data retention and necessary data minimization before enabling it. Current model names, capabilities, pricing and licensing require official-provider verification at implementation time.

### Verification badge

An AI-verified indicator requires an explicitly approved definition, check procedure, evidence, model/prompt version, timestamp and invalidation rule when content changes. Until that policy exists, generation or a successful provider response cannot set the indicator.

## Product requirement
Users can select a model from a fixed, supported model catalogue. Provide sensible defaults for quick use, while allowing per-operation model selection when supported by the chosen provider and task.

## Architecture
- `model_catalogue`: model ID, provider, display name, capabilities, status, context limits where known, cost metadata where available, and last-verified date.
- `ai_orchestrator`: central interface for classification, tagging, translation, duplicate candidates, structured parsing assistance, and other approved operations.
- Provider adapters behind a stable interface; do not scatter provider-specific API calls across business modules.
- LiteLLM was proposed as a gateway option; validate provider support, operational needs, and licensing before committing.
- Admin-controlled defaults at platform/organization level, plus user choice where permitted.
- Feature flags and controlled model catalogue updates.
- Record provider/model, operation, prompt-template version, schema version, timestamps, status, and output provenance.

## Safety and quality
- Validate model output against strict JSON/schema.
- Treat model output as untrusted until validated. Validated metadata may populate editable records directly under the confirmed policy; other operations follow their specific QC rules.
- Human QC required for publication-critical fields as defined by policy.
- Do not let model output directly execute SQL or alter permissions.
- Redact secrets and minimize personal/student data in prompts.
- Add rate limits, retries, timeouts, budget controls, and per-tenant usage accounting.
- Benchmark models against a representative question set before changing defaults.
- Maintain regression tests when prompts/models change.

## Catalogue maintenance
- Model availability changes over time. Refresh provider catalogue and verify current API identifiers before implementation/deployment.
- Do not promise every provider/model is supported unless tested.

## Required taxonomy and tagging workflow

The user requires AI-created taxonomy and primary AI tagging from that catalogue. Existing matching concept IDs should be reused; missing concepts may extend the catalogue through the reviewed activation policy. Immediate provisional AI concept creation is confirmed: use for tagging immediately, notify admin, and allow later approve/edit/merge/revoke. See [taxonomy design](TAXONOMY_AND_KNOWLEDGE_GRAPH.md). Metadata tagging belongs to the first usable question-bank release; model/provider/budget configuration is still open.

## Language catalogue and metadata display review update

English, Hindi and Gujarati were explicitly requested, plus three or four widely used regional languages. Initial four regional defaults are Bengali, Marathi, Telugu and Tamil, selected under that criterion. Admin may add more languages. See [language support](LANGUAGE_SUPPORT.md) for source basis and capability verification. Display one language at a time; each translation has a new master/code linked to the source; detailed QC remains open and generation is faculty-requested after source review.

The normal question view shows final/current metadata. Internal audit and AI provenance remain required; a per-field change timeline is not a required normal-screen feature.

## Metadata output language

User-confirmed: populate user-facing metadata in the question language, without a mandatory English duplicate. Resolve taxonomy by stable IDs and render language-appropriate labels; validate language and schema without changing identity across translations.

## On-demand question translation — confirmed

Faculty requests generation in a supported target language only after the source question has completed review. Requests before review completion are not permitted. Review completion is the confirmed gate; do not silently replace it with a requirement for prior publication. Do not automatically translate every uploaded question into all languages. Keep the source-version link, output language and model/prompt provenance; translation generation does not itself publish the result. Translation gets a distinct master/new permanent code and its own versions; detailed permission/QC semantics remain under review.

## Independent source/translation updates — confirmed

The user confirmed that original and translated questions may be updated independently. Do not require simultaneous edits or automatically overwrite a translation when its source changes. Each master keeps its own stable code and version history; preserve the translation-of link and exact originating source version. Published corrections create a new version for the affected master. This does not authorize silent mutation of either published version.

## AI variants in first release — confirmed

User-confirmed: AI generation of practice variants is included in the first release. Generated variants receive separate masters/new global eight-character codes and variant-of/source-version provenance; they follow normal question QC and authorized approval/publication. Original content remains unchanged. Faculty request is the confirmed trigger; no automatic per-question generation. Source eligibility, generation count/controls and operation permissions remain open. See [AI variant generation](AI_VARIANT_GENERATION.md).

## Variant count, target type and difficulty — confirmed

User-confirmed: faculty chooses variant count, can change the target question type, and needs target difficulty selection (1–10). Preserve these controls in the generation plan and AI provenance. Validate output against the target format and reassess answer/options/concepts/difficulty rather than copying source fields. A target setting is not proof of achieved difficulty. Source review completion remains unnecessary. Mixed-target batches are confirmed; practical limits/defaults and operation permissions still need design.

## Variants preserve the primary concept — confirmed, 17 October 2026

User-confirmed: practice variants must keep the original primary concept. Question type, requested difficulty and values/conditions may change without changing that main concept. Preserve the stable concept ID and source-version provenance. Validate semantic fidelity rather than merely copying the concept label onto unrelated generated content. Source review is not required; if source primary metadata is missing, resolve it through the existing AI/candidate metadata workflow rather than introducing a new review prerequisite. Other concept/quality checks still apply.

## Additional faculty instructions for variants — confirmed, 17 October 2026

User-confirmed: faculty may enter additional instructions for AI variant generation, such as changing only numerical values or reducing calculation. Keep them with the requested count/type/difficulty plan and AI provenance. Interpret them within the confirmed same-primary-concept and target-format requirements; surface conflicts instead of silently changing requested targets. Instructions do not grant permissions, cross tenant boundaries or bypass QC/publication checks. Exact shared/per-item instruction controls and length limits remain design details.

## First-release AI diagram creation/editing — confirmed

User-confirmed: first release includes AI generation of question diagrams and modification of existing diagrams when needed. Keep reviewable asset output, provenance, same-tenant attachment, preserved originals and version-safe references. Human QC checks diagram/question/answer consistency; no automatic verification or publication. Invocation controls, supported representation/providers/models and evaluation remain open. See [AI diagram assistance](AI_DIAGRAM_ASSISTANCE.md).

## Faculty-requested diagram generation/editing — confirmed, 17 October 2026

User-confirmed: AI diagram generation and editing run only on faculty request. Do not automatically create or modify diagrams during every upload/ingestion/new-question workflow, and do not replace source figures without the requested editing action. Preserve input/output assets, provenance, tenant access, published snapshots and normal QC. Detailed operation permissions, input controls, providers and output representation remain design work.

## Default faculty upload, manual entry and AI access — confirmed

User-confirmed after clarification: upload, manual entry and AI tools are available to all faculty by default, without separate per-user admin enable permissions. Enforce active single-coaching membership, tenant scope, configured models/resource limits and existing operation-state rules. Approval, publication, editing another faculty's question and admin-only storage/deletion remain separately controlled. Default AI access does not authorize protected writes to another question. See [confirmed access matrix](PERMISSIONS_MATRIX.md).

## AI file pairing with faculty correction — confirmed

User-confirmed: AI identifies and directly links related paper/key/solution files; faculty may correct the pairing afterward. Do not require manual group selection or confirmation before AI pairing runs. Retain model/matching/source provenance, distinguish file grouping from answer alignment and re-evaluate affected candidate associations when pairing is corrected. Ambiguities remain visible for review; protected question edits and published history still follow existing permissions/version rules.

## Faculty-requested solving of missing answers — confirmed

User-confirmed: when an imported question has no answer, faculty can request AI to solve it and fill the answer. On-demand only; no automatic solving for every upload. Preserve model/prompt/source-revision provenance and distinguish AI output from an extracted key. Validate answer format and retain normal QC; generation alone grants neither verified status nor publication. Solutions remain optional. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## Faculty-wise AI usage/cost for admin — confirmed

User-confirmed: admin needs faculty-wise AI usage and cost reporting. Record tenant, faculty/requester, operation, model/provider and available usage/cost evidence. Separate provider-reported actual cost, calculated estimates and unavailable values; do not show unknown as zero. Dashboard visibility does not itself define budgets or per-user feature gates. See [AI usage/cost dashboard](AI_USAGE_AND_COST.md).

## Monthly per-faculty AI budgets — confirmed

User-confirmed: admin can configure a monthly AI spending limit for each faculty member. Keep tenant/faculty attribution, budget amount/currency/period and auditable admin changes. This is spending control, not a reversal of default faculty AI tool access. Whether exceeding the limit only warns or blocks new AI work, exact monthly reset semantics, concurrency reservations and cost-reconciliation policy remain open; do not assume a numerical default or threshold behavior.

## Budget thresholds — 80% warning, 100% stop

User-confirmed: issue a warning when a faculty member reaches 80% of their configured monthly AI budget, and stop new AI work at 100%. Enforce the stop at provider dispatch/service boundaries, not only a disabled UI button. Preserve completed results, saved questions and non-AI work. Do not assume in-flight requests are cancelled or final provider bills can never exceed a cap when usage arrives late; define reservation, reconciliation and in-flight handling explicitly. Warning delivery/deduplication and exact monthly reset semantics remain design work.

## Coaching-owned AI API keys — confirmed

User-confirmed: each coaching supplies its own AI provider API keys instead of using centrally shared platform keys. Resolve secrets per organization for all API/worker operations, preserve credential-reference provenance without secret exposure, and never fall back to another coaching's/shared key. Provider billing belongs to the configured coaching account; application usage/budgets cover recorded app calls. Provider catalogue, secret manager, rotation/validation UX and fallback ordering/attempt limits remain design work; automatic fallback uses only the same coaching's configured keys. See [coaching-owned credentials](TENANT_AI_CREDENTIALS.md).

## Coaching-admin enabled models and default — confirmed

User-confirmed: each coaching admin can enable/select which models from the platform-supported catalogue are available in that coaching and set its default model. Faculty choose from that coaching's enabled, supported, operation-compatible models; default is available for quick use. Resolve only that coaching's provider keys. Tenant configuration cannot introduce arbitrary untested models or bypass capabilities/resource budgets. Automatic fallback with a visible error is confirmed; per-operation default details, fallback order/attempt limits, catalogue updates and UI remain design work.

## Automatic model fallback with visible error — confirmed

User-confirmed: when the selected AI model fails, show a safe, understandable error/failure status and automatically try another enabled, operation-compatible model for the same coaching. Record original selection, failure, fallback attempt and actual model/provider used; do not hide the failure because fallback succeeds. Use only that coaching's configured credentials. Respect supported capabilities, bounded retry/fallback policy and budget reservations; never bypass missing authorization, tenant checks or the 100% budget stop. Preserve successful partial outputs and idempotency. If alternatives fail/unavailable, show an actionable terminal error without fabricating output. Exact fallback order, attempt limits and detailed UI remain design work.

## Automatic own-coaching duplicate checks — confirmed

User-confirmed: every new question is automatically checked against its own coaching's existing question bank for duplicates. Shared downstream rules cover manual/import/generated candidates. Preserve tenant-safe candidate evidence and sources; human QC confirms duplicate/variant/translation disposition before canonical/merge decisions. Do not silently reject/delete uncertain candidates or collapse distinct variants/translations. Exact matching policy/thresholds and final confirmed-duplicate treatment remain open. See [duplicate policy](DUPLICATE_AND_VARIANT_POLICY.md).

## Handwritten question photos/scans — first release

User-confirmed: handwritten question photos/scans are included in the first release. Use shared extraction/staging/QC with original/source preservation; flag uncertain text, equations, units and diagrams instead of inventing or silently dropping content. OCR/vision engines, per-language quality, corpus and targets must be evaluated; no accuracy is claimed. Source-figure extraction is distinct from faculty-requested diagram generation/editing. See [OCR and handwriting](OCR_AND_HANDWRITING.md).

## Faculty-requested AI correctness checking — confirmed

User-confirmed: the first release includes faculty-requested AI checking of an existing answer and available solution. Keep reviewable findings, reasons/uncertainty and exact input-revision/model provenance; answer-only questions remain eligible because solutions are optional. Checking does not silently replace content or grant QC, approval, publication or an AI-verified badge. Use the existing tenant credentials, enabled-model, budget and background-job policies. Flagging, correction suggestions and explicit opt-in direct correction with visible before/after changes are confirmed; verification-badge criteria remain design/review work. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## First-release AI prerequisite relationships — confirmed

AI creates concept-to-concept prerequisite links in release one: which concept should be understood before another. Keep directed stable concept IDs, same-coaching/same-subject endpoints, relationship provenance and graph change history, separate from question tags and taxonomy hierarchy. Cross-subject prerequisite links are not allowed, including AI creation and admin corrections. Cross-class links within the same subject/coaching are allowed, including Class 11 prerequisite → Class 12 dependent; different classes alone must not block such links. Personalized student suggestions/mastery analytics remain later. AI links are immediately usable with AI-added/admin-review-pending status and admin notification; admin can later approve, correct or revoke them. Detailed cycle disposition and educational validation remain design work. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Pattern discovery/reuse and later teaching

First-release AI operations include understanding/extracting unfamiliar layouts and producing validated reusable pattern configuration. Later compatible files use saved rules and reduced calls/context where feasible; drift triggers traceable fallback. Account recognition/structure separately from metadata/other AI work, using coaching keys, enabled capabilities and existing budget limits. No fine-tuning or persistent model memory is assumed. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md).

AI teaching and student-need/level-personalized concept-video production are confirmed later operations. Models/media capabilities, triggers/review and educational evaluation remain future work. See [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).


## Initial AI provider scope - confirmed 18 October 2026

User-confirmed (18 October 2026): first-release AI provider support includes Google, Anthropic, OpenAI and OpenRouter, with an extensible adapter/catalogue design for adding more providers later. Each coaching configures its own credentials; existing enabled-model/default selection, compatible automatic fallback with visible failure, usage provenance and budget controls continue. Provider selection does not mean credentials are available or integrations tested. Specific API products, model identifiers, operation capabilities, data handling, prices and routing/attribution details require current official-source verification during design. Adding a provider later requires an implemented and validated adapter/catalogue entry; it is not arbitrary endpoint execution.
