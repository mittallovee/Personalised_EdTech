# User Workflows and Permission Design

Status: proposed workflow detail derived from the handover. Role names are agreed concepts; exact permissions and separation of duties are open under D-03. No endpoint or authorization implementation exists.

**User-confirmed permissions:** admin controls each user's approval and publication permissions independently. Creating/uploading grants neither. Own-content approval/publication is allowed only with the corresponding grants; human QC, valid states and audit remain required. Permission UI/custom roles remain open.

## Organization and identity

A faculty account belongs to one coaching organization and has no organization switcher. The server verifies its active membership on every operation, derives the trusted tenant context from that allowed organization and applies action permissions. Merely supplying another organization identifier grants no access. Request/connection/cache reuse across accounts must not leak prior tenant context.

Faculty onboarding is admin invite/create only, and each faculty account belongs to one coaching. Recovery, owner transfer, membership removal and detailed invitation/permission UX still need design under D-02/D-03. Removing a creator does not change question ownership; retention of attribution is covered by D-19.

## File ingestion

1. Authorized faculty chooses PDF/DOCX and sees supported limits.
2. Upload validation either returns a specific error or records the private original and job.
3. Job view shows stage, progress, warnings and partial/terminal failure.
4. Extracted candidates appear with original source references and parser warnings.
5. Faculty corrects content, options, answers, solutions, equations/assets and metadata.
6. Reviewer confirms content and candidate disposition: new master, link to existing master, variant/translation/duplicate, or excluded with recorded reason. Exclusion UX and permissions remain proposed.
7. Authorized approval/publication creates an eligible immutable version.

An extraction job being complete means processing completed, not review or publication completed. A failed job can be retried without losing the original; completed stages/candidates must not be silently duplicated.

## Manual entry

Faculty selects a supported question format, enters structured content and source metadata, and saves a candidate. The candidate uses the same validation, QC, relationship, publication and audit rules as imported content. File/page references are optional for manual content; origin and actor remain traceable. Required fields at draft and publication are separate decisions under D-07/D-09.

## Review and correction

Known forward flow: draft → content QC → approved → published. Reviewers inspect source/content/answer/solution, metadata and relationships. Invalid or incomplete content remains recoverable for correction. Changes-requested/rejected transitions and edit invalidation of approval must be resolved before implementation.

Published content corrections create another version with reason and actor. Historical tests continue to reference the prior version. Whether a correction requires the full review sequence is a policy choice under D-05; immutability is mandatory regardless.

## Question bank and test assembly

Users filter by taxonomy, format, difficulty, exam/PYQ, language, source, video availability and permitted status. Counts agree with visible eligible results. Selection stores version identities and applies the configured duplicate policy. Saving a test preserves selection criteria and history; publishing/export details and marks/sections are D-16.

## AI suggestions

An authorized user selects an allowed operation/model or uses the default. Validated AI metadata fills editable question fields directly, with provenance and later authorized correction; each field does not need separate human acceptance. Other outputs, question QC and publishing follow their own rules. Missing concepts are immediately usable with AI-added/admin-review-pending status, admin notification and later approve/edit/merge/revoke. Failures/budget exhaustion preserve existing content; AI verification requires evidence, not generation alone.

## Proposed action-permission matrix

These are capability candidates for review, **not grants attached to role names**. Every action also requires active organization membership and tenant-safe resource access.

| Capability | Proposed role candidates | Unresolved policy |
| --- | --- | --- |
| Manage organization/memberships | Owner/admin | Owner transfer, delegated administration, custom roles |
| Upload and manual candidate entry | All active faculty by default; no per-user enable flag | Tenant/resource limits still apply; bulk UX remains design work |
| Edit drafts/candidates | Creator/reviewer where permitted; admin grants cross-author edit capability | Editing another faculty's question requires admin-granted permission; own-draft defaults/concurrency remain design work |
| Review content | User with separate admin-granted review/QC permission, including creator if granted | Bank/source viewing and AI access grant no formal QC authority; queue assignment remains open |
| Approve | User granted approval permission by admin, including creator if granted | Approval permission does not imply publication permission |
| Publish | User granted publication permission by admin, including creator if granted | Publication permission does not imply approval permission; prior-state checks remain |
| Create correction versions | Authorized editor | Who can start correction and required reapproval |
| Confirm duplicate/translation links | Reviewer with explicit capability | Merge/canonical choice and translation qualification |
| Assemble/export tests | Faculty/test-author capability | Eligible states, override policy, export rights |
| Configure AI models/budgets | Organization/platform administrator | Scope of user overrides and platform restrictions |
| Read audit/export/delete data | Explicit admin capabilities | Retention, sensitive access, tenant-owner powers |

Default authorization should deny unspecified actions. Runtime enforcement must be checked in services and APIs; hiding UI controls alone does not enforce permission.

## Release and taxonomy review updates

First release covers entry/upload/review and database saving; test assembly/export are later. PDF/Word/images join the shared candidate workflow. Metadata is primarily AI-tagged from the AI-managed catalogue, with detailed hierarchy and primary/multiple secondary concepts. Immediate provisional AI activation with admin notification and later approve/edit/merge/revoke is confirmed; see [taxonomy design](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Confirmed AI and original-source lifecycle update

AI directly fills validated editable metadata without a per-field approval gate. New concepts may be added and used immediately with AI-added/admin-review-pending status. Notify admin for later approve/edit/merge/revoke; revocation stops new automatic use and preserves published snapshots. This supersedes the earlier approval-first rule; question approve/publish permissions remain separate.

Retain original source files until admin chooses deletion. Only admin can see storage analytics and delete originals; faculty can view their organization's originals. Original deletion must preserve saved questions and independently retained required diagrams/assets, show source-unavailable status honestly and record the deletion. No automatic expiry has been selected. See [source lifecycle](SOURCE_STORAGE_AND_RETENTION.md).

## Language catalogue and metadata display review update

English, Hindi and Gujarati were explicitly requested, plus three or four widely used regional languages. Initial four regional defaults are Bengali, Marathi, Telugu and Tamil, selected under that criterion. Admin may add more languages. See [language support](LANGUAGE_SUPPORT.md) for source basis and capability verification. Display one language at a time; each translation has a new master/code linked to the source; detailed QC remains open and generation is faculty-requested after source review.

The normal question view shows final/current metadata. Internal audit and AI provenance remain required; a per-field change timeline is not a required normal-screen feature.

## On-demand question translation — confirmed

Faculty requests generation in a supported target language only after the source question has completed review. Requests before review completion are not permitted. Review completion is the confirmed gate; do not silently replace it with a requirement for prior publication. Do not automatically translate every uploaded question into all languages. Keep the source-version link, output language and model/prompt provenance; translation generation does not itself publish the result. Translation gets a distinct master/new permanent code and its own versions; detailed permission/QC semantics remain under review.

## Return for correction and resubmit — confirmed

User-confirmed: when review finds an issue, the question can be returned to its creator for correction and submitted for review again. Preserve content/source identity and review history; returning work is not deletion or automatic creation of a new master. Represent a changes-requested correction loop alongside the existing draft/content-QC/approved/published flow. Authorize return/edit/resubmit actions and bind review decisions to the reviewed revision; published versions remain immutable. Exact role grants, reason/comment requirements, reassignment and separate rejection/withdrawal policies remain open.

## Variant generation before source review — confirmed, 17 October 2026

User-confirmed: original-question review completion is not required to generate a variant. Faculty may request a variant from an accessible draft/unreviewed source. Preserve the exact source content/version and its review status; source approval is not inherited. Generated variants still enter normal candidate/draft QC and require valid publication fields and admin-granted approve/publish permissions. Translation retains its separate post-review gate; do not apply that gate to variants.

## Faculty-requested diagram generation/editing — confirmed, 17 October 2026

User-confirmed: AI diagram generation and editing run only on faculty request. Do not automatically create or modify diagrams during every upload/ingestion/new-question workflow, and do not replace source figures without the requested editing action. Preserve input/output assets, provenance, tenant access, published snapshots and normal QC. Detailed operation permissions, input controls, providers and output representation remain design work.

## First-release login methods — confirmed

User-confirmed: Google login, email/password and mobile OTP are all required in the first release as alternative sign-in methods. Identity provider/session implementation, account linking, OTP delivery and onboarding remain open. Authentication does not grant organization membership or action permissions. See [identity and access](IDENTITY_AND_ACCESS.md).

## Admin-only faculty onboarding — confirmed

User-confirmed: faculty accounts are created/invited only by admin; public self-signup is not the faculty onboarding route. Authentication alone cannot enroll an uninvited user or grant organization permissions. Preserve organization-scoped invitation/membership and audit. Owner/platform bootstrap, invitation delivery and verified account linking remain separate design questions.

## Faculty sees the complete coaching question bank — confirmed

User-confirmed: faculty can view the complete question bank of their own coaching organization, not only questions they created or uploaded. Do not apply a creator-only filter to ordinary faculty question-bank visibility. Organization ownership, single-coaching account scope and cross-tenant denial remain unchanged. Viewing the full bank does not itself grant editing, approval/publication, original-file deletion or storage-dashboard rights. Detailed staging/review-state access and edit permissions remain separate policy questions.

## Admin controls cross-author editing — confirmed

User-confirmed: admin decides whether a user may edit questions created/uploaded by other faculty in the same coaching. Complete bank visibility does not grant cross-author edit permission. Enforce this independently from approval/publication grants and tenant scope. Published content is never overwritten: authorized corrections create a new version under the existing question code and retain audit/source history. Own-draft editing, exact default grants and edit/approval invalidation details remain governed by the final permission/lifecycle design.

## Default faculty upload, manual entry and AI access — confirmed

User-confirmed after clarification: upload, manual entry and AI tools are available to all faculty by default, without separate per-user admin enable permissions. Enforce active single-coaching membership, tenant scope, configured models/resource limits and existing operation-state rules. Approval, publication, editing another faculty's question and admin-only storage/deletion remain separately controlled. Default AI access does not authorize protected writes to another question. See [confirmed access matrix](PERMISSIONS_MATRIX.md).

## Admin-granted review/QC permission — confirmed

User-confirmed: formal question review/QC requires a separate permission granted by admin. Default faculty bank/source viewing, upload/manual entry and AI access do not grant formal review authority. Review, approval and publication are independent grants. A user may perform their own review/approval/publication only when holding the corresponding permissions; no different person is universally mandated. Review permission authorizes reviewed-state decisions/correction-return within the workflow, not protected content edits without the required edit permission. Preserve actor/revision-bound QC evidence and deny unauthorized review transitions.

## Shared pending-review access — confirmed

User-confirmed: any faculty member with review/QC permission may review pending questions in their own coaching. Mandatory per-question reviewer assignment is not required. Present a shared pending-review queue scoped to that organization and enforce the independent review grant. Preserve revision-bound decisions, actor/history and correction-return/resubmission. Concurrent decisions need transactional conflict handling rather than silently overwriting each other. Optional assignment is not a required feature by this answer; default faculty without the review grant cannot complete formal QC.

## Faculty-wise AI usage/cost for admin — confirmed

User-confirmed: admin needs faculty-wise AI usage and cost reporting. Record tenant, faculty/requester, operation, model/provider and available usage/cost evidence. Separate provider-reported actual cost, calculated estimates and unavailable values; do not show unknown as zero. Dashboard visibility does not itself define budgets or per-user feature gates. See [AI usage/cost dashboard](AI_USAGE_AND_COST.md).

## Coaching-admin enabled models and default — confirmed

User-confirmed: each coaching admin can enable/select which models from the platform-supported catalogue are available in that coaching and set its default model. Faculty choose from that coaching's enabled, supported, operation-compatible models; default is available for quick use. Resolve only that coaching's provider keys. Tenant configuration cannot introduce arbitrary untested models or bypass capabilities/resource budgets. Automatic fallback with a visible error is confirmed; per-operation default details, fallback order/attempt limits, catalogue updates and UI remain design work.

## Background jobs, concurrent app use and own-job cancel — confirmed

User-confirmed: faculty may cancel their own running file-processing job. Jobs run in the background; faculty can upload new files and perform other app work while earlier processing continues. Use durable independently traceable job/stage state with resource/budget limits, not a blocking UI request. Cancellation is not source deletion or silent removal of published/reviewed content. Partial-output retention, in-flight acknowledgement and completion races need detailed semantics. See [background jobs/cancellation](BACKGROUND_JOBS_AND_CANCELLATION.md).

## Cancelled jobs retain extracted drafts — confirmed

User-confirmed: cancelling a processing job keeps questions already extracted as draft work. Preserve source/candidate identity, progress, warnings and audit; do not discard completed output or alter already reviewed/published states. Cancellation stops further work according to the acknowledged stage contract, not deletion of originals or saved questions. Retry/resume behavior must not duplicate retained candidates/masters; exact cancelled-job restart UX remains open.

## Admin and creator question archival — confirmed

User-confirmed: archive removes a question from the active bank while retaining content/history. Admin may archive questions in their own coaching, and creator faculty may archive their own question. Complete-bank view or cross-author edit permission alone does not grant archive authority over other creators' questions. Preserve code, immutable published versions, assets, sources/audit and historical references; archival is not physical deletion or admin-only original-file deletion. Restore behavior remains open. See [question archival](QUESTION_ARCHIVAL.md).

## Admin and creator may restore archived questions — confirmed

User-confirmed: both admin and creator may restore archived questions. Admin acts within their coaching; creator acts on their own question. Keep the existing code, content/versions/provenance and archive/restore audit. Restoring availability is not automatic approval/publication of an unreviewed draft or authority to overwrite published content. Detailed state/eligibility and concurrency handling remain design work.

## Opt-in AI corrections with visible changes — confirmed

AI must flag suspected errors and show corrected answer/solution suggestions. Faculty may opt in to direct application, and the interface must still show the old/new values and reason. Without opt-in, the operation leaves existing answers/solutions unchanged. Enforce current same-tenant edit permissions and revision conflict/type-validation checks on actual writes, including background completion; never silently overwrite a concurrent edit. Keep source values and actor/model/input/application provenance. Correcting published content creates an editable new version under the same master/code, retaining the existing published snapshot and normal revision-bound QC/approval/publication controls. Direct-correction opt-in applies to one question at a time, selected separately for that question; no batch-wide or carried-over opt-in. See [AI answer assistance](AI_ANSWER_ASSISTANCE.md).

## AI prerequisite link review — confirmed

AI may directly add validated same-coaching prerequisite links with provisional usable/admin-review-pending status. Notify admin; admin may approve, correct or revoke later. Preserve graph revisions, AI evidence and actor/change history; remove revoked links from active use without deleting concepts/questions or earlier evidence. This is distinct from question QC/approval/publication and confers no extra faculty graph-write permission. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Faculty knowledge graph navigation in release one — confirmed

Faculty can view their coaching's knowledge tree as a graph and click a concept to open linked questions. Query by stable concept ID against primary/secondary question assignments, preserving existing bank access and tenant scope for graph nodes, edges, counts and question navigation. Viewing grants no graph-write, question-edit or QC/approve/publish authority. Show provisional AI/admin-review-pending status and current active links accurately. This is faculty bank navigation; student recommendations/mastery analytics remain later. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Subject boundary for prerequisite edits — confirmed

AI additions and admin prerequisite corrections must stay within one coaching and one subject. Admin graph-management authority does not override the no-cross-subject rule. Graph history is preserved; cross-class links within the same subject/coaching are allowed; broader chapter details and question-concept assignment policy are separate. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Concept creation authority — confirmed

Only admin and the authorized AI taxonomy workflow can add new concepts. Faculty cannot manually create concept identities, including through question-tag inputs; they may select existing concepts and correct question assignments within existing edit permissions. AI may add missing concepts during faculty processing under the immediate provisional/admin-notification policy. Enforce trusted actor/tenant checks in the API/service/worker, not a user-supplied AI flag; retain initiating user and actual AI/admin creation provenance. Creation of class, subject, chapter, topic and subtopic entries is also restricted to admin and the authorized AI taxonomy workflow; faculty selects existing entries and cannot create them through free-text tagging or a direct API call. See [taxonomy and knowledge graph](TAXONOMY_AND_KNOWLEDGE_GRAPH.md).

## Multiple admins per coaching — confirmed

A coaching organization may have more than one admin. Represent administration through individual authenticated identities and organization-scoped memberships/authority; do not impose a one-admin-per-organization constraint or require a shared login. Attribute every administrative action to the actual actor and preserve organization ownership of questions and audit history.

Multiple admins do not imply access to other coaching organizations. Each coaching has a principal Owner/Admin who can appoint and remove its other admins. Ordinary admin status does not itself grant admin-appointment/removal authority. The current Owner may transfer principal ownership to another admin in the same coaching. After transfer, the former Owner remains a regular admin in that coaching and loses principal-owner authority. When removing another admin, Owner chooses either conversion to normal faculty or removal from the coaching app with no remaining coaching access. Platform admin creates the coaching and first Owner; onboarding delivery/identity mechanics, owner recovery and exact transfer/removal mechanics remain design work. Existing independent question QC/approve/publish grants and admin-only catalogue/storage/AI configuration policies remain; do not infer that the numeric admin count changes their semantics.

## All admins may remove ordinary faculty — confirmed

Any active coaching admin (including Owner) may remove an ordinary faculty member from that same coaching's app, revoking coaching access while preserving organization questions/assets, attribution, usage and audit history. Check actor and target current membership/role at commit. Ordinary admins cannot use this action on another admin or Owner; admin demotion/removal remains Owner-only. Session/job/asset-access revocation and identity-cleanup mechanics remain design work. See [identity and access](IDENTITY_AND_ACCESS.md).

## Platform-admin onboarding of coaching and first Owner — confirmed

Platform admin creates each coaching organization and its first principal Owner/Admin. Coaching public self-signup is not available. Coaching Owner/admin and faculty membership do not confer platform-level onboarding authority, and a normal Google/password/OTP login cannot self-assign it. After onboarding, the coaching's Owner controls its other admins under the confirmed policy.

Design direction: keep platform authority separate from tenant membership, validate the intended first-owner identity and record platform actor, organization, owner and outcome. Provision the organization/initial-owner relationship consistently, with safe partial-failure/retry handling and no duplicate organizations or extra principal owners from replay. Invitation delivery/acceptance, verified identity linking and initial platform-admin provisioning remain implementation design.

Platform admin now has full cross-coaching application authority, including all question and tenant-administration capabilities, as defined in [platform access](PLATFORM_ADMIN_ACCESS.md). Earlier limited onboarding/read scope is superseded; preserve workflow, version, tenant-reference, secret-handling and audit rules. No organization or real account has been created.

## Explicit platform question-bank read scope — confirmed

Platform admin can view all coaching question banks using explicit platform-read authorization. Ordinary coaching users retain own-coaching isolation; show coaching ownership/context and audit platform reads. Server-side API/RLS/storage/cache rules must distinguish authorized question reads (including retained content assets needed to display them) from unrestricted tenant-data access. No owner/migration-credential or global RLS bypass is implied. The later full-access decision includes originals/storage, credential administration, edits/QC/approve/publish and supported AI/other application actions; this read-path description is not a limit on the platform role. See [identity and access](IDENTITY_AND_ACCESS.md).

## Explicit platform question editing — confirmed

Platform admin may edit questions in all coaching organizations through explicit platform-edit authorization and target-coaching context. Enforce type/content validation, current revision and tenant-consistent references, and record platform actor plus before/after evidence without transferring coaching ownership/creator attribution. Published corrections create an editable new version under the same master/code; preserve the existing published version and revision-bound QC/approval rules. The later full-access decision also grants QC/approve/publish, supported archive/delete, original-source/credential administration and supported AI/other app actions; the edit-path description is not a limit on platform authority. Use a reviewed restricted API/RLS write policy rather than unrestricted database bypass. See [identity and access](IDENTITY_AND_ACCESS.md).

## Current platform authority — full access

Platform admin has full application access across all coachings, including question QC/approve/publish, originals/storage, users/Owners/roles, taxonomy, AI credentials/configuration/budgets/jobs and analytics. Earlier limited platform read/edit exclusions are superseded. Coaching roles retain their own-coaching boundaries. Validation, published-version preservation, current authority checks, coaching data ownership, secret handling and audit remain required. Full authority covers supported features and does not move deferred test/student features into release one. See [the platform access specification](PLATFORM_ADMIN_ACCESS.md).

## Coaching name and logo in the app — confirmed

Each coaching may display its own name and logo in the application. Include per-coaching branding in the first-release tenant configuration and show it consistently in that coaching's app context. This is display branding, separate from internal organization identity, question ownership and the globally unique question-code scheme. Renaming or replacing a logo does not move data, change question codes or rewrite historical attribution.

Design direction: store a display name and a coaching-owned logo asset reference; validate name/content and image assets through the supported upload/rendering policy. Avoid cross-coaching asset links or cached branding leakage. A missing/unavailable logo should have a clear usable fallback, not prevent question-bank work. Use accessible labeling and preserve the selected coaching context in platform-admin views.

Only platform admin may create/change coaching display name/logo settings. Coaching Owner/admin/faculty cannot change these branding settings; there is no tenant-side branding edit grant. Exact image formats/dimensions/limits, settings UI and public/pre-login placement remain implementation design. Custom domains, color themes, hiding platform identity and later export branding are not established by this name/logo confirmation. No app UI or logo asset has been created.

## One shared app website/link for all coachings — confirmed

All coaching organizations use the same app website/entry link. Do not require a separate domain, subdomain or coaching-specific entry link for each organization in the first release. Ordinary question/detail links may still exist within the shared application; this decision is about a common entry point, not eliminating resource routes.

After sign-in, resolve a coaching user's organization and branding from their trusted identity/membership. Faculty remains bound to one coaching with no cross-coaching switcher. Never use the shared URL or a client-supplied tenant value as business-access authority. Platform admin may select an explicit coaching context under the full platform role, retaining actor/target audit.

Use tenant-safe API, private-asset, session and cache context so the shared entry cannot mix coaching names/logos, questions or sources. Platform admin alone changes coaching branding. Missing/unavailable logo behavior remains usable; exact anonymous/pre-login branding and routes are UI design. The chosen common domain, hosting, physical database/deployment arrangement and commercial billing remain separate decisions. Shared website does not weaken data ownership/isolation or create public coaching signup. No website or domain has been created.

## Repeated layouts and future teaching workflows

Faculty uploads can span recurring layouts. Background processing learns unknown layouts with AI and saves/reuses compatible patterns automatically, while new source content/candidates/warnings and normal QC remain distinct. Samples are deferred; patterns are coaching-specific with platform-only complete-dataset sharing; sharing is an independent initial copy, editable/usable by the receiving coaching under its own permissions, without synchronization. See [patterns](ADAPTIVE_EXTRACTION_PATTERNS.md).

Faculty course creation, live classes, recorded sessions and AI student teaching/personalized concept videos are confirmed later scope. Enrollment, publishing, generation/review triggers and faculty/student grants require later contracts. See [future learning](FUTURE_LEARNING_AND_AI_TEACHING.md).

## Coaching-specific patterns and platform dataset sharing - confirmed

Each coaching keeps its data/pattern library separate. Platform admin may explicitly share the complete dataset, patterns and associated material with another coaching. Ordinary coaching roles cannot initiate cross-coaching sharing. Preserve an explicit source/target manifest, complete dependency mapping, question-code/version integrity and platform actor history. Sharing creates a one-time independent initial copy with no ongoing updates in either direction; destination may use/change its own copy. Preserve mapped independent identities/new globally unique codes for new question masters and source provenance. Destination users and API keys are set up separately, not copied; keep source actor/model evidence as provenance, not active memberships/secrets. Source-published questions retain published status without mandatory local re-review on copy; preserve imported QC evidence and immutable snapshots, with later edits using normal new-version review. Destination conflict/failure and operational-reference details remain design work. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## Published status in independent coaching copies - confirmed

When platform admin copies an existing coaching dataset, source-published question snapshots remain published in the destination without mandatory re-review merely for copying. Preserve source QC/publication provenance, the platform copy actor and exact version/dependency mapping; do not invent destination reviewer identities. New destination question masters still receive new globally unique codes. Validate complete snapshot/reference integrity; do not promote source drafts/unreviewed content. Later destination edits create a new editable version under the destination code and follow normal QC/approval/publication; copied published snapshots stay immutable. See [dataset sharing](CROSS_COACHING_DATA_SHARING.md).

## AI concept/prerequisite alerts: in-app only - current rule

AI-added concepts and prerequisite links notify all active admins in the originating coaching, including Owner, inside the app only. Email notifications are cancelled for the current release. There is no notification-email provider, delivery queue, email digest or separate mandatory admin email-contact requirement for these alerts. Existing Google/email-password/mobile-OTP login choices and their identity requirements remain unchanged.

Preserve immediate provisional use: alerts/review do not add a prior approval gate or block valid AI tagging. Store tenant/entity/version-correct events and per-recipient notification/read state, with AI provenance and authenticated review links. Deduplicate event/recipient records on retry; read/dismiss and shared concept/link review outcomes are distinct. Recheck active admin membership on notification access so removed/demoted users cannot rely on stale recipient records. No other-coaching broadcast is introduced.

Notification persistence/recovery must not duplicate taxonomy additions or falsely report completed review. Detailed in-app presentation, retention and newly appointed admin access to old alerts remain implementation design. No message or application notification has been sent.

## AI taxonomy alert recipients - confirmed

Notify every active admin in the originating coaching, including Owner, in the app only. The later user correction cancels email delivery and its separate required admin contact field. Do not reduce recipients to Owner-only or broadcast to other coachings. Platform full administrative access remains.

Keep per-recipient read/notification state separate from shared review state; one admin reading/reviewing must not mark another's alert read. Recheck current roles and deduplicate event/recipient records. Retention and new-admin historical visibility remain design work. No notification has been sent.

## One user account across linked login methods - confirmed

Google, email/password and mobile OTP can be linked to the same canonical application user account. After linking, any configured method opens the same account with the same coaching membership, grants, creator/reviewer attribution, usage/budget identity and history. Do not create a separate app account or independent permissions merely because the sign-in method changes.

This is support for alternative linked methods, not a requirement to complete all three on every login or force every user to configure every method. Email/password credentials are needed only when that method is configured; the separate notification-email requirement remains withdrawn and alerts remain in-app only.

Design direction: verify control of the existing identity and added sign-in method using the chosen provider. Matching email/phone labels alone cannot merge accounts, expand membership, recover another user's account or grant admin/platform authority. Existing identity/link collisions require an explicit safe resolution, not silent data/role union. Current membership/role checks remain server-side for every method; revoked membership stays revoked. Exact provider, contact change/unlink/recovery and multi-device/session policy remain design work. No identities/accounts have been linked.

## Simultaneous mobile and laptop sessions - confirmed

A user may stay signed in on mobile and laptop at the same time. Signing in through another configured linked method/device does not automatically replace the first valid session. Both resolve to the same canonical account/coaching grants, history, notification state and AI usage/budget identity.

Design direction: maintain distinct session/device identifiers and current server-side identity/role checks. Role/membership revocation must take effect across devices, and no session may retain former Owner/platform authority solely from stale login state. Shared job/idempotency and revision-conflict rules still apply to simultaneous uploads/actions/edits; two sessions cannot create separate AI budgets or duplicate a charged operation by replay.

The user has not selected an exact device cap, session duration or an unlimited-session guarantee. No user-facing logged-in-device list or remote per-device logout manager is required in this release. Normal sign-out on the current device remains; simultaneous mobile/laptop sessions and server-side authorization/revocation checks remain. Exact cookie/token/provider/session implementation remains design work. No sessions/accounts have been created.
